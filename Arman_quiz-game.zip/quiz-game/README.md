# 🎮 Ultimate Multimedia Quiz Game — QuizVerse

A fully-featured, **dark cyberpunk** quiz platform built with **PHP + MySQL** for XAMPP.  
Game modes, animated UI, achievements, leaderboards, admin panel, and more.

---

## 📁 Project Structure

```
quiz-game/
├── index.php                  ← Animated homepage (categories + game modes)
├── login.php                  ← User login
├── register.php               ← User registration
├── play.php                   ← Pre-quiz screen (difficulty selector)
├── quiz.php                   ← Live quiz game screen
├── result.php                 ← End-of-quiz results + confetti
├── dashboard.php              ← User profile, stats, history, achievements
├── leaderboard.php            ← Global & per-category leaderboard
├── logout.php                 ← Session termination
├── setup.php                  ← 🔧 ONE-TIME setup (delete after use)
├── database.sql               ← Full MySQL schema + sample data
│
├── admin/
│   ├── admin_dashboard.php    ← Admin overview stats
│   ├── add_question.php       ← Add questions with media upload
│   ├── edit_question.php      ← Edit existing questions
│   ├── manage_questions.php   ← Paginated question list with filters
│   ├── manage_categories.php  ← Add/edit/toggle categories
│   ├── manage_users.php       ← View users, toggle admin, reset scores
│   └── manage_scores.php      ← Score history with stats
│
├── ajax/
│   ├── answer.php             ← AJAX answer submission handler
│   └── question.php           ← AJAX next-question loader
│
├── includes/
│   ├── db.php                 ← PDO database connection
│   └── functions.php          ← All core PHP logic
│
└── assets/
    ├── css/style.css          ← Full cyberpunk dark theme
    ├── js/main.js             ← Particles, sounds, quiz engine, animations
    ├── uploads/               ← Question media uploads
    │   ├── images/
    │   ├── audio/
    │   └── video/
    └── sounds/                ← (optional static sound files)
```

---

## ⚡ Quick Setup (XAMPP)

### Step 1 — Copy files
Place the `quiz-game` folder inside `C:\xampp\htdocs\`  
so the path is: `C:\xampp\htdocs\quiz-game\`

### Step 2 — Start XAMPP
Start **Apache** and **MySQL** from the XAMPP Control Panel.

### Step 3 — Run Setup
Open your browser and go to:
```
http://localhost/quiz-game/setup.php
```
This will:
- Create the `quiz_game` database
- Run all SQL schema
- Insert 14 categories and sample questions
- Create the default admin account

### Step 4 — Delete setup.php
After setup completes, **delete `setup.php`** for security!

### Step 5 — Login as Admin
```
URL:      http://localhost/quiz-game/login.php
Username: admin
Password: admin123
```

---

## 🎮 Game Modes

| Mode         | Description                                    |
|--------------|------------------------------------------------|
| ⚡ Quick Quiz | 10 questions, 30 sec per question              |
| ⏱ Time Attack | 60 seconds total, answer as many as possible  |
| 💀 Survival  | 3 lives — wrong answer = lose a life           |
| 🔁 Endless   | Unlimited questions, keep going forever        |

---

## 📚 Categories (14)

⚽ Football · 🏏 Cricket · 🎌 Anime · 🎬 Movies · 🎵 Music  
🎮 Gaming · 📜 History · 🔬 Science · 🌍 World Knowledge  
💻 Technology · 🚗 Cars · 🗺️ Geography · 🚀 Space · 📱 Internet Culture

---

## 🏅 Achievements System

| Badge | Name         | Condition                    |
|-------|--------------|------------------------------|
| 🎯    | First Steps  | Complete first quiz          |
| 🔥    | On Fire      | Complete 10 quizzes          |
| ⚔️    | Quiz Veteran | Complete 50 quizzes          |
| 👑    | Quiz Legend  | Complete 100 quizzes         |
| 🧠    | Sharp Mind   | Reach 1,000 total score      |
| ⭐    | High Scorer  | Reach 5,000 total score      |
| 💎    | Perfect Round| Get 100% on any quiz         |
| ⚡    | Speed Demon  | Win a Time Attack quiz       |
| 💀    | Survivor     | Complete a Survival quiz     |
| 🔁    | Endless Runner| Answer 50 in Endless Mode   |

---

## 📊 Question Types

- **Multiple Choice** — 4 options
- **True / False** — 2 options
- **Image Guess** — question with an image
- **Audio Guess** — question with audio clip
- **Video Scene** — question with video clip

---

## 🔒 Security Features

- `password_hash()` / `password_verify()` for passwords
- PDO prepared statements (no SQL injection)
- Session protection with HttpOnly cookies
- Admin panel requires `is_admin = 1`
- File upload validation (type + size checks)
- XSS protection via `htmlspecialchars()`

---

## 🎨 UI Design

- **Dark cyberpunk** neon aesthetic
- **Orbitron** display font + **Rajdhani** body font
- **Floating particle** canvas animation
- **CSS grid overlay** background
- **Neon glow** buttons with shimmer effect
- **Card tilt** effect on category hover
- **Timer circle** SVG with color change
- **Confetti** on quiz win
- **Web Audio API** for sound effects (no external files needed)
- Fully **mobile responsive**

---

## 🛠 Adding Questions via Admin

1. Log in as admin → `http://localhost/quiz-game/admin/admin_dashboard.php`
2. Click **"➕ Add Question"**
3. Select category, difficulty, question type
4. Fill in question text and up to 4 options
5. Select the correct option
6. Optionally upload image / audio / video
7. Submit

**Bulk import via SQL:**
```sql
INSERT INTO questions (category_id, question_text, difficulty, option1, option2, option3, option4, correct_option, points)
VALUES (1, 'Who won the 2022 World Cup?', 'medium', 'Brazil', 'Argentina', 'France', 'England', 2, 15);
```

---

## 🔧 Configuration

Edit `includes/db.php` for database settings:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');       // set your MySQL password here
define('DB_NAME', 'quiz_game');
```

---

## 📈 Scaling Tips

- Add `INDEX` on `questions.category_id` and `questions.difficulty` for speed
- Use `LIMIT` + `OFFSET` for pagination (already implemented in admin)
- Store uploaded media on a CDN or separate server for production
- Enable PHP OPcache for better performance

---

## 🎯 Grading System

| Accuracy | Grade |
|----------|-------|
| 90–100%  | S     |
| 75–89%   | A     |
| 60–74%   | B     |
| 40–59%   | C     |
| 0–39%    | D     |

---

*Built with PHP 8+, MySQL, vanilla JS, and CSS animations.*  
*No external JS frameworks required — runs entirely on XAMPP.*
