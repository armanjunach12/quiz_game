<?php
// play.php — Pre-quiz screen: select difficulty then start
require_once 'includes/functions.php';
startSecureSession();
requireLogin();

$categoryId = (int)($_GET['category'] ?? 0);
$mode       = preg_replace('/[^a-z_]/', '', $_GET['mode'] ?? 'quick');

$category = getCategoryById($categoryId);
if (!$category) { redirect(BASE.'/index.php'); }

// Count available questions (total + by type)
$db = getDB();
$stmt = $db->prepare("SELECT COUNT(*) FROM questions WHERE category_id = ? AND is_active = 1");
$stmt->execute([$categoryId]);
$totalQ = $stmt->fetchColumn();

if ($totalQ === 0) {
    redirect(BASE.'/index.php?error=no_questions');
}

// Count multimedia question types
$mmStats = $db->prepare("SELECT
    SUM(image_path IS NOT NULL AND image_path != '') as photo_count,
    SUM(audio_path IS NOT NULL AND audio_path != '') as audio_count,
    SUM(video_path IS NOT NULL AND video_path != '') as video_count
    FROM questions WHERE category_id = ? AND is_active = 1");
$mmStats->execute([$categoryId]);
$mm = $mmStats->fetch();
$photoCount = (int)($mm['photo_count'] ?? 0);
$audioCount = (int)($mm['audio_count'] ?? 0);
$videoCount = (int)($mm['video_count'] ?? 0);

// Handle form submission — create session
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $difficulty = $_POST['difficulty'] ?? 'mixed';
    // Set limits per mode; never exceed available questions
    $limit = match($mode) {
        'time_attack' => 50,
        'endless'     => min(999, $totalQ),
        'survival'    => min(50, $totalQ),
        default       => 10,
    };
    $questions = getQuestions($categoryId, min($limit, $totalQ), $difficulty, $mode);

    if (empty($questions)) {
        $error = 'No questions found for selected difficulty. Try "Mixed".';
    } else {
        $sessionId = createGameSession($_SESSION['user_id'], $categoryId, $mode, $difficulty, $questions);
        redirect(BASE.'/quiz.php?session=' . $sessionId);
    }
}

$modeInfo = [
    'quick'       => ['name' => 'Quick Quiz',    'icon' => '⚡', 'desc' => '10 questions, no time pressure',       'color' => 'var(--neon-cyan)'],
    'time_attack' => ['name' => 'Time Attack',   'icon' => '⏱', 'desc' => 'Answer as many as possible in 60s',   'color' => 'var(--neon-gold)'],
    'survival'    => ['name' => 'Survival Mode', 'icon' => '💀', 'desc' => '3 lives — wrong answer = lose a life', 'color' => 'var(--neon-pink)'],
    'endless'     => ['name' => 'Endless Mode',  'icon' => '🔁', 'desc' => 'Unlimited questions, keep going!',     'color' => 'var(--neon-green)'],
];
$info = $modeInfo[$mode] ?? $modeInfo['quick'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Play <?= h($category['name']) ?> — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>
  <canvas id="particles-canvas"></canvas>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span></a>
    <div class="nav-user">
      <a href="<?=BASE?>/index.php" class="btn btn-ghost btn-sm">← Back</a>
    </div>
  </nav>

  <div class="auth-container" style="min-height:100vh;padding-top:80px">
    <div class="auth-card" style="max-width:560px">
      <!-- Category Header -->
      <div style="text-align:center;margin-bottom:2rem">
        <div style="font-size:4rem;margin-bottom:0.5rem;filter:drop-shadow(0 0 20px <?= h($category['color']) ?>)">
          <?= $category['icon'] ?>
        </div>
        <h2 style="font-family:'Orbitron',monospace;font-size:1.5rem;color:<?= h($category['color']) ?>;margin-bottom:0.5rem">
          <?= h($category['name']) ?>
        </h2>
        <p style="color:var(--text-dim)"><?= $totalQ ?> questions available</p>
        <?php if ($photoCount || $audioCount || $videoCount): ?>
        <div style="display:flex;gap:0.75rem;justify-content:center;flex-wrap:wrap;margin-top:0.75rem">
          <?php if ($photoCount): ?>
          <span style="padding:4px 12px;border-radius:20px;background:rgba(0,245,255,0.1);border:1px solid rgba(0,245,255,0.3);font-size:0.8rem;color:var(--neon-cyan)">
            📸 <?= $photoCount ?> Photo
          </span>
          <?php endif; ?>
          <?php if ($audioCount): ?>
          <span style="padding:4px 12px;border-radius:20px;background:rgba(191,0,255,0.1);border:1px solid rgba(191,0,255,0.3);font-size:0.8rem;color:var(--neon-purple)">
            🎵 <?= $audioCount ?> Audio
          </span>
          <?php endif; ?>
          <?php if ($videoCount): ?>
          <span style="padding:4px 12px;border-radius:20px;background:rgba(255,0,170,0.1);border:1px solid rgba(255,0,170,0.3);font-size:0.8rem;color:var(--neon-pink)">
            🎬 <?= $videoCount ?> Video
          </span>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Mode Badge -->
      <div style="text-align:center;margin-bottom:2rem">
        <div style="display:inline-flex;align-items:center;gap:0.75rem;padding:12px 24px;border:1px solid <?= $info['color'] ?>;border-radius:30px;background:<?= $info['color'] ?>11">
          <span style="font-size:1.5rem"><?= $info['icon'] ?></span>
          <div style="text-align:left">
            <div style="font-family:'Orbitron',monospace;font-size:0.9rem;color:<?= $info['color'] ?>;font-weight:700"><?= $info['name'] ?></div>
            <div style="font-size:0.8rem;color:var(--text-dim)"><?= $info['desc'] ?></div>
          </div>
        </div>
      </div>

      <?php if (!empty($error)): ?>
        <div class="form-error">⚠ <?= h($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <!-- Difficulty Selector -->
        <div class="form-group">
          <label class="form-label">Select Difficulty</label>
          <input type="hidden" name="difficulty" id="selected_difficulty" value="mixed">
          <div class="difficulty-btns" style="justify-content:center">
            <button type="button" class="diff-btn selected" data-diff="mixed">⚡ Mixed</button>
            <button type="button" class="diff-btn" data-diff="easy">🟢 Easy</button>
            <button type="button" class="diff-btn" data-diff="medium">🟡 Medium</button>
            <button type="button" class="diff-btn" data-diff="hard">🔴 Hard</button>
          </div>
        </div>

        <button type="submit" class="btn btn-primary btn-lg btn-start" style="width:100%;margin-top:1rem">
          ▶ START QUIZ
        </button>
      </form>

      <div style="text-align:center;margin-top:1.5rem">
        <a href="<?=BASE?>/index.php#categories" style="color:var(--text-dim);font-size:0.9rem">Change Category →</a>
      </div>
    </div>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
