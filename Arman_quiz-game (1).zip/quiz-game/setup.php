<?php
// setup.php — One-click database installer
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'quiz_game');

$errors   = [];
$messages = [];

try {
    // Connect without database first
    $pdo = new PDO("mysql:host=".DB_HOST.";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `".DB_NAME."` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `".DB_NAME."`");
    $messages[] = "✅ Database '".DB_NAME."' ready.";

    // ---------- TABLES ----------
    $tables = <<<SQL
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    total_score INT DEFAULT 0,
    quizzes_played INT DEFAULT 0,
    correct_answers INT DEFAULT 0,
    total_answers INT DEFAULT 0,
    is_admin TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(10) DEFAULT '🎯',
    color VARCHAR(7) DEFAULT '#6c63ff',
    color2 VARCHAR(7) DEFAULT '#48cfad',
    description TEXT,
    question_count INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('multiple_choice','true_false','image_guess','audio_guess','video_scene') DEFAULT 'multiple_choice',
    difficulty ENUM('easy','medium','hard') DEFAULT 'medium',
    image_path VARCHAR(500) DEFAULT NULL,
    audio_path VARCHAR(500) DEFAULT NULL,
    video_path VARCHAR(500) DEFAULT NULL,
    option1 VARCHAR(500) NOT NULL,
    option2 VARCHAR(500) NOT NULL,
    option3 VARCHAR(500) DEFAULT NULL,
    option4 VARCHAR(500) DEFAULT NULL,
    correct_option TINYINT NOT NULL,
    explanation TEXT DEFAULT NULL,
    points INT DEFAULT 10,
    times_played INT DEFAULT 0,
    times_correct INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    game_mode ENUM('quick','time_attack','survival','endless') DEFAULT 'quick',
    difficulty ENUM('easy','medium','hard','mixed') DEFAULT 'mixed',
    score INT NOT NULL DEFAULT 0,
    correct_answers INT DEFAULT 0,
    total_questions INT DEFAULT 0,
    time_taken INT DEFAULT 0,
    date_played TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    badge_icon VARCHAR(10) DEFAULT '🏅',
    badge_color VARCHAR(7) DEFAULT '#FFD700',
    condition_type VARCHAR(50) NOT NULL,
    condition_value INT DEFAULT 1,
    condition_category INT DEFAULT NULL,
    xp_reward INT DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    achievement_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_achievement (user_id, achievement_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS game_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    game_mode VARCHAR(20) DEFAULT 'quick',
    difficulty VARCHAR(10) DEFAULT 'mixed',
    question_ids TEXT NOT NULL,
    current_index INT DEFAULT 0,
    score INT DEFAULT 0,
    correct INT DEFAULT 0,
    lives INT DEFAULT 3,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL 1 HOUR),
    is_complete TINYINT(1) DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;
SQL;

    foreach (array_filter(array_map('trim', explode(';', $tables))) as $sql) {
        if($sql) $pdo->exec($sql);
    }
    $messages[] = "✅ All tables created / verified.";

    // ---------- CATEGORIES ----------
    $catCount = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
    if ($catCount == 0) {
        $pdo->exec("INSERT INTO categories (name, slug, icon, color, color2, description) VALUES
('Football', 'football', '⚽', '#00c853', '#69f0ae', 'Test your football knowledge'),
('Cricket', 'cricket', '🏏', '#ff6d00', '#ffab40', 'All about cricket'),
('Anime', 'anime', '🎌', '#e91e63', '#f48fb1', 'Anime characters, shows and lore'),
('Movies', 'movies', '🎬', '#9c27b0', '#ce93d8', 'Blockbusters, classics and trivia'),
('Music', 'music', '🎵', '#3949ab', '#7986cb', 'Artists, lyrics and beats'),
('Gaming', 'gaming', '🎮', '#00bcd4', '#80deea', 'Video games history and trivia'),
('History', 'history', '📜', '#795548', '#bcaaa4', 'World history from ancient to modern'),
('Science', 'science', '🔬', '#00acc1', '#80deea', 'Physics, chemistry, biology'),
('World Knowledge', 'world-knowledge', '🌍', '#43a047', '#a5d6a7', 'General world facts'),
('Technology', 'technology', '💻', '#1e88e5', '#90caf9', 'Tech, gadgets, and innovation'),
('Cars', 'cars', '🚗', '#e53935', '#ef9a9a', 'Automobiles and motorsport'),
('Geography', 'geography', '🗺️', '#26a69a', '#80cbc4', 'Countries, capitals, maps'),
('Space', 'space', '🚀', '#5e35b1', '#b39ddb', 'Universe, planets and astronomy'),
('Internet Culture', 'internet-culture', '📱', '#f57c00', '#ffcc02', 'Memes, viral trends, social media'),
('Multimedia Mix', 'multimedia-mix', '🎪', '#ff1744', '#ff6e40', 'Photo, audio & video questions from every topic')");
        $messages[] = "✅ 15 categories inserted.";
    } else {
        $messages[] = "ℹ️ Categories already exist ($catCount found).";
        // Always ensure Multimedia Mix category exists
        $pdo->exec("INSERT IGNORE INTO categories (name, slug, icon, color, color2, description) VALUES
('Multimedia Mix', 'multimedia-mix', '🎪', '#ff1744', '#ff6e40', 'Photo, audio & video questions from every topic')");
    }

    // ---------- ACHIEVEMENTS ----------
    $achCount = $pdo->query("SELECT COUNT(*) FROM achievements")->fetchColumn();
    if ($achCount == 0) {
        $pdo->exec("INSERT INTO achievements (name, description, badge_icon, badge_color, condition_type, condition_value, xp_reward) VALUES
('First Steps', 'Complete your first quiz', '🎯', '#FFD700', 'quizzes_played', 1, 50),
('On Fire', 'Complete 10 quizzes', '🔥', '#FF6B35', 'quizzes_played', 10, 150),
('Quiz Veteran', 'Complete 50 quizzes', '⚔️', '#C0C0C0', 'quizzes_played', 50, 500),
('Quiz Legend', 'Complete 100 quizzes', '👑', '#FFD700', 'quizzes_played', 100, 1000),
('Sharp Mind', 'Reach a total score of 1000', '🧠', '#9C27B0', 'score_total', 1000, 200),
('High Scorer', 'Reach a total score of 5000', '⭐', '#FF5722', 'score_total', 5000, 500),
('Perfect Round', 'Get 100% on any quiz', '💎', '#00BCD4', 'perfect_score', 1, 300),
('Speed Demon', 'Win a Time Attack quiz', '⚡', '#FFC107', 'mode_time_attack', 1, 250),
('Survivor', 'Complete a Survival Mode quiz', '💀', '#607D8B', 'mode_survival', 1, 350),
('Endless Runner', 'Answer 50 questions in Endless Mode', '🔁', '#4CAF50', 'endless_questions', 50, 400)");
        $messages[] = "✅ Achievements inserted.";
    } else {
        $messages[] = "ℹ️ Achievements already exist.";
    }

    // ---------- ADMIN USER ----------
    $adminExists = $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = 1")->fetchColumn();
    if (!$adminExists) {
        $hash = password_hash('admin123', PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO users (username, email, password, is_admin) VALUES (?, ?, ?, 1)")
            ->execute(['admin', 'admin@quizverse.com', $hash]);
        $messages[] = "✅ Admin user created: <strong>admin</strong> / <strong>admin123</strong>";
    } else {
        $messages[] = "ℹ️ Admin user already exists.";
    }

    // ---------- LOAD QUESTIONS SQL ----------
    $sqlFile = __DIR__ . '/database_questions.sql';
    if (file_exists($sqlFile)) {
        $sql = file_get_contents($sqlFile);
        
        // Check existing question count
        $beforeCount = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
        
        // Execute each statement
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        $imported = 0;
        foreach ($statements as $stmt) {
            if ($stmt && stripos($stmt, 'INSERT') !== false) {
                try {
                    $pdo->exec($stmt);
                    $imported++;
                } catch (Exception $e) {
                    // Skip duplicates
                }
            }
        }
        
        $afterCount = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
        $new = $afterCount - $beforeCount;
        
        // Update question counts
        $pdo->exec("UPDATE categories c SET question_count = (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id AND q.is_active = 1)");
        $messages[] = "✅ Questions imported: $new new questions. Total: $afterCount questions.";
    } else {
        $messages[] = "⚠️ database_questions.sql not found — run the game to auto-generate questions.";
    }

    // Update counts
    $pdo->exec("UPDATE categories c SET question_count = (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id AND q.is_active = 1)");

    // ---------- LOAD MULTIMEDIA QUESTIONS SQL ----------
    $mmFile = __DIR__ . '/database_multimedia.sql';
    if (file_exists($mmFile)) {
        $sql2 = file_get_contents($mmFile);
        $beforeMM = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
        $stmts2 = array_filter(array_map('trim', explode(';', $sql2)));
        foreach ($stmts2 as $s) {
            if ($s && stripos($s, 'INSERT') !== false) {
                try { $pdo->exec($s); } catch (Exception $e) { /* skip dupes */ }
            }
        }
        $afterMM = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
        $newMM = $afterMM - $beforeMM;
        $pdo->exec("UPDATE categories c SET question_count = (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id AND q.is_active = 1)");
        $messages[] = "✅ Multimedia questions imported: $newMM new (photo/video/audio). Total: $afterMM questions.";
    } else {
        $messages[] = "ℹ️ database_multimedia.sql not found — skipping multimedia questions.";
    }

    $messages[] = "✅ Question counts updated.";

    $success = true;

} catch (PDOException $e) {
    $errors[] = "Database error: " . $e->getMessage();
    $success = false;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>QuizVerse Setup</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #060a18; color: #e8f4fd; font-family: 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
  .box { background: #0d1426; border: 1px solid #00f5ff33; border-radius: 20px; padding: 2.5rem; max-width: 640px; width: 90%; }
  h1 { font-size: 1.8rem; background: linear-gradient(90deg,#00f5ff,#ff00aa); -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin-bottom: 1.5rem; }
  .msg { padding: 10px 16px; border-radius: 10px; margin-bottom: 10px; background: rgba(0,245,255,0.08); border-left: 3px solid #00f5ff; font-size: 0.95rem; line-height: 1.6; }
  .error { background: rgba(255,0,100,0.1); border-left-color: #ff006e; }
  .actions { margin-top: 2rem; display: flex; gap: 1rem; flex-wrap: wrap; }
  a.btn { display: inline-block; padding: 12px 28px; border-radius: 30px; text-decoration: none; font-weight: 700; font-size: 0.95rem; transition: all 0.3s; }
  .btn-primary { background: linear-gradient(135deg,#00f5ff,#0080ff); color: #000; }
  .btn-secondary { border: 1px solid #00f5ff; color: #00f5ff; }
  .btn:hover { transform: translateY(-2px); opacity: 0.9; }
  .status { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; margin-bottom: 1rem; }
  .status-ok { background: rgba(0,255,136,0.15); color: #00ff88; border: 1px solid #00ff88; }
  .status-err { background: rgba(255,0,100,0.15); color: #ff006e; border: 1px solid #ff006e; }
</style>
</head>
<body>
<div class="box">
  <h1>🎮 QuizVerse Setup</h1>
  <?php if ($success): ?>
    <div class="status status-ok">✓ Setup Complete</div>
  <?php else: ?>
    <div class="status status-err">✗ Setup Failed</div>
  <?php endif; ?>

  <?php foreach ($messages as $m): ?>
    <div class="msg"><?= $m ?></div>
  <?php endforeach; ?>
  <?php foreach ($errors as $e): ?>
    <div class="msg error">❌ <?= htmlspecialchars($e) ?></div>
  <?php endforeach; ?>

  <div class="actions">
    <a href="/php/quiz-game/index.php" class="btn btn-primary">▶ Go to QuizVerse</a>
    <a href="/php/quiz-game/setup.php" class="btn btn-secondary">🔄 Re-run Setup</a>
    <a href="/php/quiz-game/admin/admin_dashboard.php" class="btn btn-secondary">⚙️ Admin Panel</a>
  </div>
</div>
</body>
</html>
