<?php
// includes/functions.php

require_once __DIR__ . '/db.php';

// ============================================================
// SESSION & AUTH
// ============================================================
function startSecureSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => false,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        session_start();
    }
}

function isLoggedIn() {
    startSecureSession();
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: '.BASE.'/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI'] ?? '/'));
        exit();
    }
}

function requireAdmin() {
    requireLogin();
    if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
        header('Location: '.BASE.'/index.php');
        exit();
    }
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

// ============================================================
// USER MANAGEMENT
// ============================================================
function registerUser($username, $email, $password) {
    $db = getDB();
    $username = trim($username);
    $email    = trim(strtolower($email));

    if (strlen($username) < 3 || strlen($username) > 50) return ['error' => 'Username must be 3-50 characters'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))        return ['error' => 'Invalid email address'];
    if (strlen($password) < 6)                            return ['error' => 'Password must be at least 6 characters'];

    $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) return ['error' => 'Username or email already exists'];

    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->execute([$username, $email, $hashed]);
    $userId = $db->lastInsertId();

    $_SESSION['user_id']  = $userId;
    $_SESSION['username'] = $username;
    $_SESSION['is_admin'] = 0;
    return ['success' => true, 'user_id' => $userId];
}

function loginUser($usernameOrEmail, $password) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        return ['error' => 'Invalid username/email or password'];
    }

    $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);

    $_SESSION['user_id']  = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['is_admin'] = $user['is_admin'];
    return ['success' => true, 'user' => $user];
}

function logoutUser() {
    startSecureSession();
    session_destroy();
    header('Location: '.BASE.'/index.php');
    exit();
}

// ============================================================
// CATEGORIES
// ============================================================
function getCategories($activeOnly = true) {
    $db = getDB();
    $sql = "SELECT c.*, 
            (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id AND q.is_active = 1) as question_count
            FROM categories c";
    if ($activeOnly) $sql .= " WHERE c.is_active = 1";
    $sql .= " ORDER BY c.name";
    return $db->query($sql)->fetchAll();
}

function getCategoryById($id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getCategoryBySlug($slug) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM categories WHERE slug = ?");
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

// ============================================================
// QUESTIONS & QUIZ ENGINE
// ============================================================
function getQuestions($categoryId, $limit = 10, $difficulty = 'mixed', $mode = 'quick') {
    $db = getDB();
    $diffFilter = '';
    $diffParams = [];
    if ($difficulty !== 'mixed') {
        $diffFilter = " AND difficulty = ?";
        $diffParams = [$difficulty];
    }

    // First, grab multimedia questions (image/audio/video) to guarantee they appear
    $mmSql = "SELECT * FROM questions WHERE category_id = ? AND is_active = 1
              AND (image_path IS NOT NULL AND image_path != '' 
                   OR audio_path IS NOT NULL AND audio_path != ''
                   OR video_path IS NOT NULL AND video_path != '')" . $diffFilter . " ORDER BY RAND() LIMIT ?";
    $mmLimit = min(5, (int)$limit);  // up to 5 multimedia questions
    $stmt = $db->prepare($mmSql);
    $stmt->execute(array_merge([$categoryId], $diffParams, [$mmLimit]));
    $mmQuestions = $stmt->fetchAll();

    $remaining = (int)$limit - count($mmQuestions);
    $usedIds = array_column($mmQuestions, 'id');

    if ($remaining > 0) {
        // Fill remaining slots with other random questions (excluding already-picked multimedia)
        $excludePlaceholders = '';
        $excludeParams = [];
        if (!empty($usedIds)) {
            $excludePlaceholders = " AND id NOT IN (" . implode(',', array_fill(0, count($usedIds), '?')) . ")";
            $excludeParams = $usedIds;
        }
        $fillSql = "SELECT * FROM questions WHERE category_id = ? AND is_active = 1" . $diffFilter . $excludePlaceholders . " ORDER BY RAND() LIMIT ?";
        $stmt2 = $db->prepare($fillSql);
        $stmt2->execute(array_merge([$categoryId], $diffParams, $excludeParams, [$remaining]));
        $fillQuestions = $stmt2->fetchAll();
        $allQuestions = array_merge($mmQuestions, $fillQuestions);
    } else {
        $allQuestions = $mmQuestions;
    }

    // Shuffle to mix multimedia with regular questions
    shuffle($allQuestions);
    return $allQuestions;
}

function createGameSession($userId, $categoryId, $mode, $difficulty, $questions) {
    $db = getDB();
    $questionIds = json_encode(array_column($questions, 'id'));
    $lives = ($mode === 'survival') ? 3 : 99;

    $stmt = $db->prepare("INSERT INTO game_sessions (user_id, category_id, game_mode, difficulty, question_ids, lives) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$userId, $categoryId, $mode, $difficulty, $questionIds, $lives]);
    return $db->lastInsertId();
}

function getGameSession($sessionId, $userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM game_sessions WHERE id = ? AND user_id = ? AND is_complete = 0 AND expires_at > NOW()");
    $stmt->execute([$sessionId, $userId]);
    return $stmt->fetch();
}

function getSessionQuestion($session) {
    $db = getDB();
    $questionIds = json_decode($session['question_ids'], true);
    $idx = $session['current_index'];

    if ($idx >= count($questionIds)) return null;

    $stmt = $db->prepare("SELECT * FROM questions WHERE id = ?");
    $stmt->execute([$questionIds[$idx]]);
    return $stmt->fetch();
}

function submitAnswer($sessionId, $userId, $selectedOption) {
    $db = getDB();
    $session = getGameSession($sessionId, $userId);
    if (!$session) return ['error' => 'Invalid session'];

    $question = getSessionQuestion($session);
    if (!$question) return ['error' => 'No question found'];

    $isCorrect = (int)$selectedOption === (int)$question['correct_option'];
    $points    = $isCorrect ? $question['points'] : 0;

    // Update question stats
    $db->prepare("UPDATE questions SET times_played = times_played + 1, times_correct = times_correct + ? WHERE id = ?")->execute([$isCorrect ? 1 : 0, $question['id']]);

    // Update session
    $newScore   = $session['score'] + $points;
    $newCorrect = $session['correct'] + ($isCorrect ? 1 : 0);
    $newIndex   = $session['current_index'] + 1;
    $newLives   = $session['lives'] - ($isCorrect ? 0 : 1);

    $questionIds = json_decode($session['question_ids'], true);
    $totalQ = count($questionIds);
    $isComplete = ($newIndex >= $totalQ) || ($session['game_mode'] === 'survival' && $newLives <= 0);

    $db->prepare("UPDATE game_sessions SET score = ?, correct = ?, current_index = ?, lives = ?, is_complete = ? WHERE id = ?")
       ->execute([$newScore, $newCorrect, $newIndex, $newLives, $isComplete ? 1 : 0, $sessionId]);

    if ($isComplete) {
        saveScore($userId, $session['category_id'], $session['game_mode'], $session['difficulty'], $newScore, $newCorrect, $totalQ);
        checkAchievements($userId);
    }

    return [
        'correct'       => $isCorrect,
        'correct_option'=> (int)$question['correct_option'],
        'points'        => $points,
        'explanation'   => $question['explanation'],
        'session_score' => $newScore,
        'is_complete'   => $isComplete,
        'lives'         => $newLives,
        'next_index'    => $newIndex,
        'total'         => $totalQ
    ];
}

// ============================================================
// SCORES & LEADERBOARD
// ============================================================
function saveScore($userId, $categoryId, $mode, $difficulty, $score, $correct, $total) {
    $db = getDB();
    $db->prepare("INSERT INTO scores (user_id, category_id, game_mode, difficulty, score, correct_answers, total_questions) VALUES (?, ?, ?, ?, ?, ?, ?)")
       ->execute([$userId, $categoryId, $mode, $difficulty, $score, $correct, $total]);

    $db->prepare("UPDATE users SET total_score = total_score + ?, quizzes_played = quizzes_played + 1, correct_answers = correct_answers + ?, total_answers = total_answers + ? WHERE id = ?")
       ->execute([$score, $correct, $total, $userId]);
}

function getLeaderboard($limit = 20, $categoryId = null) {
    $db = getDB();
    if ($categoryId) {
        $stmt = $db->prepare("SELECT u.username, u.avatar, SUM(s.score) as total, COUNT(s.id) as games, MAX(s.score) as best FROM scores s JOIN users u ON u.id = s.user_id WHERE s.category_id = ? GROUP BY u.id ORDER BY total DESC LIMIT ?");
        $stmt->execute([$categoryId, $limit]);
    } else {
        $stmt = $db->prepare("SELECT username, avatar, total_score, quizzes_played, CASE WHEN total_answers > 0 THEN ROUND((correct_answers/total_answers)*100) ELSE 0 END as accuracy FROM users WHERE total_score > 0 ORDER BY total_score DESC LIMIT ?");
        $stmt->execute([$limit]);
    }
    return $stmt->fetchAll();
}

function getUserStats($userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT u.*, 
        CASE WHEN u.total_answers > 0 THEN ROUND((u.correct_answers/u.total_answers)*100) ELSE 0 END as accuracy,
        (SELECT c.name FROM scores s JOIN categories c ON c.id = s.category_id WHERE s.user_id = u.id GROUP BY s.category_id ORDER BY COUNT(*) DESC LIMIT 1) as fav_category,
        (SELECT MAX(score) FROM scores WHERE user_id = u.id) as best_score
        FROM users u WHERE u.id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

function getUserScoreHistory($userId, $limit = 10) {
    $db = getDB();
    $stmt = $db->prepare("SELECT s.*, c.name as category_name, c.icon FROM scores s JOIN categories c ON c.id = s.category_id WHERE s.user_id = ? ORDER BY s.date_played DESC LIMIT ?");
    $stmt->execute([$userId, $limit]);
    return $stmt->fetchAll();
}

// ============================================================
// ACHIEVEMENTS
// ============================================================
function checkAchievements($userId) {
    $db   = getDB();
    $user = getCurrentUser();
    if (!$user) return;

    $allAch = $db->query("SELECT * FROM achievements")->fetchAll();
    foreach ($allAch as $ach) {
        $earned = false;
        switch ($ach['condition_type']) {
            case 'quizzes_played':   $earned = $user['quizzes_played'] >= $ach['condition_value']; break;
            case 'score_total':      $earned = $user['total_score']    >= $ach['condition_value']; break;
            case 'perfect_score':
                $stmt = $db->prepare("SELECT COUNT(*) FROM scores WHERE user_id = ? AND correct_answers = total_questions AND total_questions > 0");
                $stmt->execute([$userId]); $earned = $stmt->fetchColumn() > 0; break;
            case 'mode_time_attack':
                $stmt = $db->prepare("SELECT COUNT(*) FROM scores WHERE user_id = ? AND game_mode = 'time_attack'");
                $stmt->execute([$userId]); $earned = $stmt->fetchColumn() >= $ach['condition_value']; break;
            case 'mode_survival':
                $stmt = $db->prepare("SELECT COUNT(*) FROM scores WHERE user_id = ? AND game_mode = 'survival'");
                $stmt->execute([$userId]); $earned = $stmt->fetchColumn() >= $ach['condition_value']; break;
        }
        if ($earned) {
            $db->prepare("INSERT IGNORE INTO user_achievements (user_id, achievement_id) VALUES (?, ?)")->execute([$userId, $ach['id']]);
        }
    }
}

function getUserAchievements($userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT a.*, ua.earned_at FROM user_achievements ua JOIN achievements a ON a.id = ua.achievement_id WHERE ua.user_id = ? ORDER BY ua.earned_at DESC");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

// ============================================================
// ADMIN FUNCTIONS
// ============================================================
function addCategory($name, $icon, $color, $color2, $desc) {
    $db = getDB();
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name));
    $stmt = $db->prepare("INSERT INTO categories (name, slug, icon, color, color2, description) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $slug, $icon, $color, $color2, $desc]);
    return $db->lastInsertId();
}

function addQuestion($data) {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO questions (category_id, question_text, question_type, difficulty, image_path, audio_path, video_path, option1, option2, option3, option4, correct_option, explanation, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $data['category_id'], $data['question_text'], $data['question_type'] ?? 'multiple_choice',
        $data['difficulty'] ?? 'medium', $data['image_path'] ?? null, $data['audio_path'] ?? null,
        $data['video_path'] ?? null, $data['option1'], $data['option2'], $data['option3'] ?? null,
        $data['option4'] ?? null, $data['correct_option'], $data['explanation'] ?? null,
        $data['points'] ?? 10
    ]);
    $id = $db->lastInsertId();
    $db->prepare("UPDATE categories SET question_count = (SELECT COUNT(*) FROM questions WHERE category_id = ? AND is_active = 1) WHERE id = ?")->execute([$data['category_id'], $data['category_id']]);
    return $id;
}

function handleFileUpload($file, $type = 'images') {
    $allowedTypes = [
        'images' => ['image/jpeg','image/png','image/gif','image/webp'],
        'audio'  => ['audio/mpeg','audio/wav','audio/ogg','audio/mp3'],
        'video'  => ['video/mp4','video/webm','video/ogg'],
    ];
    $allowed = $allowedTypes[$type] ?? $allowedTypes['images'];

    if (!in_array($file['type'], $allowed)) return ['error' => 'Invalid file type'];
    if ($file['size'] > 50 * 1024 * 1024)  return ['error' => 'File too large (max 50MB)'];

    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . $ext;
    $dir      = __DIR__ . '/../assets/uploads/' . $type . '/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    if (move_uploaded_file($file['tmp_name'], $dir . $filename)) {
        return ['path' => BASE.'/assets/uploads/' . $type . '/' . $filename];
    }
    return ['error' => 'Upload failed'];
}

// ============================================================
// UTILITIES
// ============================================================
function h($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
function redirect($url) { header("Location: $url"); exit(); }
function jsonResponse($data) { header('Content-Type: application/json'); echo json_encode($data); exit(); }

function getTimeLimitForMode($mode) {
    return match($mode) {
        'time_attack' => 60,
        'quick'       => 300,
        'survival'    => 180,
        'endless'     => 0,
        default       => 300
    };
}
