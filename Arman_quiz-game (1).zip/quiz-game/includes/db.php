<?php
// includes/db.php

// ── BASE URL CONFIG ──────────────────────────────────────
// Match this to your folder path inside htdocs:
// htdocs/php/quiz-game/     → '/php/quiz-game'
// htdocs/quiz-game/         → '/quiz-game'
define('BASE', '/php/quiz-game');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');        // leave blank for default XAMPP
define('DB_NAME', 'quiz_game');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            // First try connecting without selecting a DB, to give a better error
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            $msg = $e->getMessage();

            // Detect common causes and give helpful message
            if (strpos($msg, 'Connection refused') !== false || strpos($msg, "Can't connect") !== false) {
                $reason = "MySQL is not running. Open XAMPP Control Panel and click <b>Start</b> next to MySQL.";
            } elseif (strpos($msg, 'Unknown database') !== false) {
                $reason = "Database '<b>" . DB_NAME . "</b>' does not exist yet. <a href='" . BASE . "/setup.php'>Click here to run setup.php</a>.";
            } elseif (strpos($msg, 'Access denied') !== false) {
                $reason = "Wrong MySQL username or password in <b>includes/db.php</b>. Default XAMPP is user=<b>root</b>, password=<b>empty</b>.";
            } else {
                $reason = htmlspecialchars($msg);
            }

            die("<!DOCTYPE html>
<html><head><meta charset='UTF-8'>
<title>Database Error</title>
<style>
  body { background:#060a18; color:#e8f4fd; font-family:sans-serif; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
  .box { background:#0d1426; border:1px solid #ff00aa; border-radius:16px; padding:3rem; max-width:600px; text-align:center; }
  h2 { color:#ff00aa; font-size:1.5rem; margin-bottom:1rem; }
  p  { color:#6b8aad; line-height:1.8; }
  a  { color:#00f5ff; }
  code { background:rgba(255,255,255,0.05); padding:4px 10px; border-radius:6px; font-size:0.9rem; }
</style>
</head><body>
<div class='box'>
  <h2>⚠️ Database Connection Error</h2>
  <p>$reason</p>
  <hr style='border-color:rgba(255,255,255,0.08);margin:1.5rem 0'>
  <p><small>Error detail: <code>" . htmlspecialchars($msg) . "</code></small></p>
</div>
</body></html>");
        }
    }
    return $pdo;
}
