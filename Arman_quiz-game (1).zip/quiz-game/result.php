<?php
// result.php — End of quiz results screen
require_once 'includes/functions.php';
startSecureSession();
requireLogin();

$sessionId = (int)($_GET['session'] ?? 0);
$db = getDB();

// Get completed session
$stmt = $db->prepare("SELECT gs.*, c.name as cat_name, c.icon as cat_icon, c.color as cat_color 
                      FROM game_sessions gs 
                      JOIN categories c ON c.id = gs.category_id 
                      WHERE gs.id = ? AND gs.user_id = ?");
$stmt->execute([$sessionId, $_SESSION['user_id']]);
$session = $stmt->fetch();

if (!$session) { redirect(BASE.'/index.php'); }

// Force complete if needed
if (!$session['is_complete']) {
    $db->prepare("UPDATE game_sessions SET is_complete = 1 WHERE id = ?")->execute([$sessionId]);
    saveScore(
        $_SESSION['user_id'], $session['category_id'],
        $session['game_mode'], $session['difficulty'],
        $session['score'], $session['correct'], count(json_decode($session['question_ids'], true))
    );
    checkAchievements($_SESSION['user_id']);
}

$total     = count(json_decode($session['question_ids'], true));
$correct   = $session['correct'];
$score     = $session['score'];
$accuracy  = $total > 0 ? round(($correct / $total) * 100) : 0;
$isPerfect = $accuracy === 100;
$grade     = $accuracy >= 90 ? 'S' : ($accuracy >= 75 ? 'A' : ($accuracy >= 60 ? 'B' : ($accuracy >= 40 ? 'C' : 'D')));

$gradeColors = ['S' => 'var(--neon-gold)', 'A' => 'var(--neon-green)', 'B' => 'var(--neon-cyan)', 'C' => 'var(--neon-gold)', 'D' => 'var(--neon-pink)'];
$gradeColor  = $gradeColors[$grade];

$newAchievements = getUserAchievements($_SESSION['user_id']);
$userStats       = getUserStats($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quiz Result — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>
  <canvas id="particles-canvas"></canvas>
  <div id="music-player-placeholder"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span></a>
    <div class="nav-user">
      <span class="score-badge">Total: ⭐ <?= number_format($userStats['total_score'] ?? 0) ?></span>
    </div>
  </nav>

  <div class="result-container">
    <!-- Category & Mode -->
    <div style="margin-bottom:1rem;color:var(--text-dim);font-size:1rem">
      <?= $session['cat_icon'] ?> <?= h($session['cat_name']) ?>
      &nbsp;·&nbsp;
      <span style="text-transform:uppercase;font-weight:700"><?= str_replace('_',' ', $session['game_mode']) ?></span>
    </div>

    <!-- Grade & Title -->
    <h1 style="font-size:3rem;margin-bottom:0.5rem;color:<?= $gradeColor ?>;text-shadow:0 0 30px <?= $gradeColor ?>">
      <?= $isPerfect ? '🎉 PERFECT!' : ($accuracy >= 75 ? '🔥 Excellent!' : ($accuracy >= 50 ? '👍 Good Job!' : '💪 Keep Going!')) ?>
    </h1>

    <!-- Score Circle -->
    <div class="result-score-circle" style="border-color:<?= $gradeColor ?>;box-shadow:0 0 40px <?= $gradeColor ?>55, inset 0 0 40px <?= $gradeColor ?>15">
      <span class="result-points glow-gold" id="score-counter">0</span>
      <span class="result-label">POINTS</span>
    </div>

    <!-- Grade Badge -->
    <div style="font-family:'Orbitron',monospace;font-size:4rem;font-weight:900;color:<?= $gradeColor ?>;
                text-shadow:0 0 30px <?= $gradeColor ?>;margin-bottom:2rem;line-height:1">
      <?= $grade ?>
    </div>

    <!-- Stats -->
    <div class="result-stats">
      <div class="result-stat">
        <span class="result-stat-value" style="color:var(--neon-green)"><?= $correct ?>/<?= $total ?></span>
        <span class="result-stat-key">Correct</span>
      </div>
      <div class="result-stat">
        <span class="result-stat-value" style="color:var(--neon-cyan)"><?= $accuracy ?>%</span>
        <span class="result-stat-key">Accuracy</span>
      </div>
      <div class="result-stat">
        <span class="result-stat-value" style="color:var(--neon-gold)"><?= $score ?></span>
        <span class="result-stat-key">Points Earned</span>
      </div>
    </div>

    <!-- New Achievements (last 2) -->
    <?php
    $recentAch = array_slice($newAchievements, 0, 2);
    if (!empty($recentAch)):
    ?>
    <div style="width:100%;max-width:600px;margin-bottom:2rem">
      <h3 style="font-family:'Orbitron',monospace;font-size:1rem;color:var(--neon-gold);margin-bottom:1rem;text-align:center">
        🏅 Achievement Unlocked
      </h3>
      <div style="display:flex;flex-direction:column;gap:0.75rem">
        <?php foreach ($recentAch as $ach): ?>
        <div class="achievement-card">
          <span class="achievement-icon"><?= $ach['badge_icon'] ?></span>
          <div>
            <div class="achievement-name"><?= h($ach['name']) ?></div>
            <div class="achievement-desc"><?= h($ach['description']) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Action Buttons -->
    <div style="display:flex;gap:1rem;flex-wrap:wrap;justify-content:center">
      <a href="<?=BASE?>/play.php?category=<?= $session['category_id'] ?>&mode=<?= $session['game_mode'] ?>"
         class="btn btn-primary btn-lg">🔁 Play Again</a>
      <a href="<?=BASE?>/index.php#categories"
         class="btn btn-ghost btn-lg">🎯 New Category</a>
      <a href="<?=BASE?>/leaderboard.php"
         class="btn btn-gold btn-lg">🏆 Leaderboard</a>
      <a href="<?=BASE?>/dashboard.php"
         class="btn btn-ghost btn-lg">📊 My Stats</a>
    </div>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
  <script>
    document.addEventListener('click', () => {
      MusicPlayer.autoStart();
      <?php if ($isPerfect || $accuracy >= 75): ?>
      setTimeout(() => { MusicPlayer.sfx('win'); Confetti.fire(); }, 400);
      <?php elseif ($accuracy < 40): ?>
      setTimeout(() => MusicPlayer.sfx('wrong'), 400);
      <?php endif; ?>
    }, { once: true });

    <?php if ($isPerfect || $accuracy >= 75): ?>
    // Auto-fire confetti after load
    window.addEventListener('DOMContentLoaded', () => {
      setTimeout(() => Confetti.fire(), 800);
    });
    <?php endif; ?>

    // Animate score counter
    window.addEventListener('DOMContentLoaded', () => {
      setTimeout(() => {
        const el = document.getElementById('score-counter');
        if (el) animateCounter(el, <?= $score ?>, 1500);
      }, 600);
    });
  </script>
</body>
</html>
