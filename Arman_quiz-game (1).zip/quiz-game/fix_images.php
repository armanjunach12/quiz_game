<?php
// fix_images.php — Updates football question images to reliable URLs
require_once 'includes/db.php';

$db = getDB();

// Better image URLs using Wikipedia's actual CDN (no redirect)
$updates = [
    // Messi question
    ['like' => '%Lionel-Messi%', 'url' => 'https://upload.wikimedia.org/wikipedia/commons/b/b4/Lionel-Messi-Argentina-2022-FIFA-World-Cup_%28cropped%29.jpg'],
    // Ronaldo question
    ['like' => '%Cristiano_Ronaldo_2018%', 'url' => 'https://upload.wikimedia.org/wikipedia/commons/8/8c/Cristiano_Ronaldo_2018.jpg'],
    // Mbappe question
    ['like' => '%Sandro_Halank%', 'url' => 'https://upload.wikimedia.org/wikipedia/commons/5/57/2019-07-17_SG_Dynamo_Dresden_vs_Paris_Saint-Germain_by_Sandro_Halank%E2%80%931.jpg'],
];

foreach ($updates as $u) {
    $stmt = $db->prepare("UPDATE questions SET image_path = ? WHERE image_path LIKE ? AND category_id = 1");
    $stmt->execute([$u['url'], $u['like']]);
    echo "Updated " . $stmt->rowCount() . " row(s) for: " . $u['url'] . "<br>";
}

// Check what we have
$rows = $db->query("SELECT id, LEFT(question_text, 60) as qt, image_path FROM questions WHERE category_id=1 AND image_path IS NOT NULL")->fetchAll();
echo "<h3>Football image questions:</h3>";
foreach ($rows as $r) {
    echo "<div style='margin:10px;padding:10px;background:#111;color:#0f9'>";
    echo "<b>#{$r['id']}</b>: {$r['qt']}<br>";
    echo "URL: <a href='{$r['image_path']}' target='_blank' style='color:#0ff'>{$r['image_path']}</a>";
    echo "</div>";
}

echo "<br><a href='/php/quiz-game/index.php' style='color:#0ff'>→ Back to QuizVerse</a>";
