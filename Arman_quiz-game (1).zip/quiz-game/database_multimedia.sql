-- ============================================================
-- QuizVerse — MULTIMEDIA Questions (Expanded)
-- image_guess, audio_guess, video_scene types
-- Uses: flagcdn.com (flags), Wikipedia Commons (images/audio)
--       YouTube embeds (video)
-- ============================================================

-- ============================================================
-- IMAGE GUESS — FLAGS (Geography cat 12)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(12,'Which country''s flag is shown?','image_guess','easy','https://flagcdn.com/w320/jp.png','China','South Korea','Japan','Vietnam',3,'The Japanese flag is white with a single red circle (the sun) in the center.',15),
(12,'Identify this country''s flag:','image_guess','easy','https://flagcdn.com/w320/br.png','Argentina','Bolivia','Uruguay','Brazil',4,'Brazil''s green flag with a yellow diamond and blue globe is unique in the world.',15),
(12,'Which country does this flag belong to?','image_guess','easy','https://flagcdn.com/w320/de.png','Austria','Belgium','Germany','Switzerland',3,'Germany''s tricolor flag has black, red, and gold horizontal stripes.',15),
(12,'Whose flag is this?','image_guess','easy','https://flagcdn.com/w320/fr.png','Netherlands','Italy','Luxembourg','France',4,'France''s tricolor has blue, white, and red vertical stripes.',15),
(12,'Name the country with this flag:','image_guess','easy','https://flagcdn.com/w320/in.png','Pakistan','Bangladesh','Nepal','India',4,'India''s flag has an orange (saffron), white, and green tricolor with the Ashoka Chakra.',15),
(12,'Which country''s flag is shown?','image_guess','medium','https://flagcdn.com/w320/ca.png','USA','New Zealand','Australia','Canada',4,'Canada''s flag features a red maple leaf on white between two red bars.',15),
(12,'Identify this flag:','image_guess','medium','https://flagcdn.com/w320/it.png','Portugal','Hungary','Bulgaria','Italy',4,'Italy has a vertical green, white, and red tricolor — same as France but different order.',15),
(12,'Which nation uses this flag?','image_guess','medium','https://flagcdn.com/w320/au.png','New Zealand','United Kingdom','Fiji','Australia',4,'Australia''s flag has the Union Jack plus the Southern Cross constellation.',15),
(12,'Identify this country''s flag:','image_guess','medium','https://flagcdn.com/w320/mx.png','Peru','Bolivia','Italy','Mexico',4,'Mexico''s green, white, red flag features an eagle with a snake in the center.',15),
(12,'Whose flag is shown?','image_guess','hard','https://flagcdn.com/w320/za.png','Zimbabwe','Kenya','South Africa','Mozambique',3,'South Africa''s flag has six colors including the unique Y-shaped (pall) design.',20),
(12,'Which country has this flag?','image_guess','hard','https://flagcdn.com/w320/pk.png','Bangladesh','Saudi Arabia','Malaysia','Pakistan',4,'Pakistan''s flag is dark green with a white crescent moon and star.',20),
(12,'Identify this flag:','image_guess','hard','https://flagcdn.com/w320/ng.png','Ghana','Ivory Coast','Cameroon','Nigeria',4,'Nigeria''s flag has two vertical green stripes with a white stripe in the middle.',20),
(12,'Which country''s flag features a dragon?','image_guess','hard','https://flagcdn.com/w320/bt.png','Mongolia','China','Bhutan','Thailand',3,'Bhutan''s flag features a white dragon (Druk) on an orange and saffron background.',20),
(12,'Identify this Nordic flag:','image_guess','medium','https://flagcdn.com/w320/se.png','Finland','Denmark','Norway','Sweden',4,'Sweden''s flag features a yellow Nordic cross on a blue background.',15),
(12,'Which country uses this flag with a crescent and star?','image_guess','medium','https://flagcdn.com/w320/tr.png','Tunisia','Algeria','Turkey','Libya',3,'Turkey''s flag has a white crescent and star on a red background.',15);

-- ============================================================
-- IMAGE GUESS — FOOTBALL PLAYERS (cat 1)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(1,'Who is this legendary football manager?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Alex_Ferguson_-_Beckham_testimonial.jpg/400px-Alex_Ferguson_-_Beckham_testimonial.jpg','Arsène Wenger','Pep Guardiola','José Mourinho','Sir Alex Ferguson',4,'Sir Alex Ferguson managed Manchester United for 26 years, winning 38 trophies.',20),
(1,'Identify this French football legend:','image_guess','hard','https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Zinedine_Zidane_by_Tasnim_03.jpg/400px-Zinedine_Zidane_by_Tasnim_03.jpg','Thierry Henry','Patrick Vieira','Zinedine Zidane','Laurent Blanc',3,'Zinedine Zidane is one of the greatest footballers ever, known for his elegant style.',20);

-- ============================================================
-- IMAGE GUESS — SPACE (cat 13)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(13,'Which planet is shown in this image?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Jupiter_New_Horizons.jpg/400px-Jupiter_New_Horizons.jpg','Saturn','Neptune','Uranus','Jupiter',4,'Jupiter is the largest planet in our solar system, known for its Great Red Spot storm.',15),
(13,'Identify this planet:','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/PIA23791-RingsPlanet-Saturn-20200711.jpg/400px-PIA23791-RingsPlanet-Saturn-20200711.jpg','Uranus','Saturn','Neptune','Jupiter',2,'Saturn is famous for its stunning ring system made of ice and rock particles.',15),
(13,'Which space object is shown?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Milky_Way_Arch.jpg/400px-Milky_Way_Arch.jpg','Andromeda Galaxy','Milky Way Galaxy','Triangulum Galaxy','NGC 1300',2,'The Milky Way is our home galaxy, visible as a glowing band of light in dark skies.',20),
(13,'Which NASA mission vehicle is shown?','image_guess','hard','https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Space_Shuttle_Atlantis_approaching_ISS_crop.jpg/400px-Space_Shuttle_Atlantis_approaching_ISS_crop.jpg','Challenger','Discovery','Columbia','Atlantis',4,'Space Shuttle Atlantis flew 33 missions before retiring in 2011.',20),
(13,'Which planet is this red world?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/OSIRIS_Mars_true_color.jpg/400px-OSIRIS_Mars_true_color.jpg','Venus','Jupiter','Mars','Mercury',3,'Mars is called the Red Planet due to iron oxide (rust) on its surface.',15);

-- ============================================================
-- IMAGE GUESS — ANIMALS (World Knowledge cat 9)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(9,'What animal is shown?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/RedCat_8727.jpg/400px-RedCat_8727.jpg','Fox','Tiger','Cat','Lynx',3,'Cats (Felis catus) are one of the most popular pets worldwide.',10),
(9,'Identify this large mammal:','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/African_Bush_Elephant.jpg/400px-African_Bush_Elephant.jpg','Indian Elephant','Mammoth','African Elephant','Asian Elephant',3,'African Bush Elephants are the largest land animals on Earth.',10),
(9,'What bird is this?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/A_small_cup_of_coffee.JPG/400px-A_small_cup_of_coffee.JPG','Eagle','Flamingo','Toucan','Parrot',2,'Flamingos get their pink color from carotenoid pigments in their food.',15),
(9,'Identify this big cat:','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Tigerwater_edit2.jpg/400px-Tigerwater_edit2.jpg','Leopard','Jaguar','Cheetah','Tiger',4,'Tigers are the largest wild cats and are recognized by their distinctive stripes.',15),
(9,'What marine animal is this?','image_guess','hard','https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Whale_shark_Georgia_aquarium.jpg/400px-Whale_shark_Georgia_aquarium.jpg','Blue Whale','Great White Shark','Whale Shark','Basking Shark',3,'The Whale Shark is the largest fish in the ocean, reaching up to 12 meters.',20),
(9,'Identify this colorful bird:','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Camponotus_flavomarginatus_ant.jpg/400px-Camponotus_flavomarginatus_ant.jpg','Beetle','Spider','Ant','Termite',3,'Ants are social insects that live in organized colonies with queens and workers.',10);

-- ============================================================
-- IMAGE GUESS — SCIENCE (cat 8)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(8,'What structure is shown in this scientific diagram?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/DNA_Structure%2BKey%2BLabelled.pn_NoBB.png/400px-DNA_Structure%2BKey%2BLabelled.pn_NoBB.png','Protein','RNA','DNA Double Helix','Chromosome',3,'DNA''s double helix structure was discovered by Watson and Crick in 1953.',15),
(8,'Identify this scientific apparatus:','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Prism-rainbow-black.svg/400px-Prism-rainbow-black.svg.png','Mirror','Lens','Prism','Crystal',3,'A prism refracts light, splitting it into the visible spectrum (rainbow colors).',10);

-- ============================================================
-- IMAGE GUESS — MOVIES (cat 4)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(4,'Which iconic movie prop is this?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/Spinning_top_of_Cobb.jpg/400px-Spinning_top_of_Cobb.jpg','Harry Potter wand','James Bond car','The Inception totem','The Ring',3,'In Inception (2010), Cobb uses a spinning top as his totem to test reality vs dream.',15),
(4,'Which actor''s famous photo is shown?','image_guess','hard','https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Einstein_tongue.jpg/400px-Einstein_tongue.jpg','Charlie Chaplin','Albert Einstein','Groucho Marx','Mr. Bean',2,'Though Einstein was a scientist, his famous tongue-out photo has become iconic in popular culture.',20);

-- ============================================================
-- AUDIO GUESS — MUSIC (cat 5)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,audio_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(5,'Listen to this classical music piece. Which composer wrote it?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/a/a8/BWV_543_fugue.ogg/BWV_543_fugue.ogg.mp3','Beethoven','Mozart','Bach','Chopin',3,'This is a Bach fugue — Johann Sebastian Bach (1685-1750) was a master of counterpoint.',15),
(5,'Listen to this piece. Which era of music does it belong to?','audio_guess','hard','https://upload.wikimedia.org/wikipedia/commons/transcoded/6/6f/Moonlight_sonata.ogg/Moonlight_sonata.ogg.mp3','Baroque','Classical','Romantic','Modern',3,'Beethoven''s Moonlight Sonata (1801) is one of the most famous Romantic-era piano pieces.',20),
(5,'Listen to this instrument solo. What instrument is being played?','audio_guess','easy','https://upload.wikimedia.org/wikipedia/commons/transcoded/6/6d/Guitar_chord_progression.ogg/Guitar_chord_progression.ogg.mp3','Piano','Violin','Guitar','Flute',3,'The guitar is a string instrument plucked with fingers or a pick.',10),
(5,'What type of instrument produces this sound?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/a/a2/Franz_Schubert_-_Aufenthalt_D_957-5.ogg/Franz_Schubert_-_Aufenthalt_D_957-5.ogg.mp3','Solo Piano','String Quartet','Vocal with Piano','Full Orchestra',3,'This is Schubert''s art song (Lied) featuring voice accompanied by piano.',15),
(5,'Listen carefully. What is this famous classical piece?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/1/1e/Rondo_Alla_Turca.ogg/Rondo_Alla_Turca.ogg.mp3','Für Elise','Turkish March','Ode to Joy','Canon in D',2,'Mozart''s Rondo Alla Turca (Turkish March) from Piano Sonata No. 11 is one of his most well-known pieces.',15),
(5,'What style of music is being played?','audio_guess','easy','https://upload.wikimedia.org/wikipedia/commons/transcoded/4/49/Trumpet_E%E2%99%AD_major.ogg/Trumpet_E%E2%99%AD_major.ogg.mp3','Rock','Jazz','Classical Brass','Electronic',3,'This is a trumpet playing a classical brass piece — the trumpet is a key brass instrument.',10);

-- ============================================================
-- AUDIO GUESS — GEOGRAPHY / WORLD (cat 9)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,audio_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(9,'Which country''s national anthem is being played?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/4/4b/Brazilian_National_Anthem_Instrumental.ogg/Brazilian_National_Anthem_Instrumental.ogg.mp3','Argentina','Mexico','Colombia','Brazil',4,'The Brazilian national anthem "Hino Nacional Brasileiro" was composed in 1822.',15),
(9,'Listen and identify which country''s anthem this is:','audio_guess','hard','https://upload.wikimedia.org/wikipedia/commons/transcoded/a/a8/Us_anthem.ogg/Us_anthem.ogg.mp3','Canada','United Kingdom','Australia','United States of America',4,'The Star-Spangled Banner became the USA''s national anthem in 1931.',20);

-- ============================================================
-- AUDIO GUESS — SCIENCE (cat 8)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,audio_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(8,'Listen to this sound. What natural phenomenon produces it?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/d/db/Thunder.ogg/Thunder.ogg.mp3','Earthquake','Volcano','Thunder','Avalanche',3,'Thunder is caused by the rapid expansion of air heated by lightning.',15),
(8,'What animal makes this sound?','audio_guess','easy','https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c1/Parus_major_15mars2011.ogg/Parus_major_15mars2011.ogg.mp3','Cat','Dog','Bird (Great Tit)','Frog',3,'The Great Tit (Parus major) is known for its distinctive two-note song.',10);

-- ============================================================
-- AUDIO GUESS — HISTORY (cat 7)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,audio_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(7,'Listen to this famous speech. Who is speaking?','audio_guess','hard','https://upload.wikimedia.org/wikipedia/commons/transcoded/1/12/Martin_Luther_King_-_I_Have_a_Dream.ogg/Martin_Luther_King_-_I_Have_a_Dream.ogg.mp3','JFK','Abraham Lincoln','Martin Luther King Jr.','Winston Churchill',3,'Martin Luther King Jr.''s "I Have a Dream" speech was delivered on August 28, 1963.',20);

-- ============================================================
-- AUDIO GUESS — CRICKET (cat 2)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,audio_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(2,'Listen to this crowd reaction. What cricket event likely just happened?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/0/04/Crowd_yelling.ogg/Crowd_yelling.ogg.mp3','A wicket fell','A boundary was hit','A six was hit','A catch was dropped',3,'Crowd roars like this typically happen when a batsman hits a six — the most exciting shot in cricket.',15);

-- ============================================================
-- VIDEO SCENE — MOVIES (cat 4)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(4,'Watch this iconic movie trailer clip. Which film is it from?','video_scene','medium','https://www.youtube.com/embed/5PSNL1qE6VY','The Lion King','Aladdin','Mulan','Moana',1,'The Lion King (1994) is one of Disney''s most beloved animated films based on Shakespeare''s Hamlet.',15),
(4,'Which blockbuster movie is shown in this trailer?','video_scene','medium','https://www.youtube.com/embed/TcMBFSGVi1c','Iron Man','Captain America','Batman','Superman',1,'Iron Man (2008) launched the Marvel Cinematic Universe (MCU) with Robert Downey Jr.',15),
(4,'Watch this clip. What famous movie is it from?','video_scene','hard','https://www.youtube.com/embed/sGbxmsDFVnE','Inception','Interstellar','The Dark Knight','Tenet',2,'Interstellar (2014) directed by Christopher Nolan explores time dilation and black holes.',20),
(4,'Which animated movie is shown in this trailer?','video_scene','easy','https://www.youtube.com/embed/CwXOrWvPBPk','Shrek','Toy Story','Finding Nemo','Monsters Inc',3,'Finding Nemo (2003) by Pixar follows a clownfish searching for his lost son across the ocean.',10),
(4,'Identify this horror movie from the trailer:','video_scene','hard','https://www.youtube.com/embed/xOCurBYI_gY','The Conjuring','Insidious','A Quiet Place','Get Out',1,'The Conjuring (2013) is based on real-life paranormal investigators Ed and Lorraine Warren.',20);

-- ============================================================
-- VIDEO SCENE — MUSIC (cat 5)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(5,'Watch this music video clip. Who is the artist?','video_scene','easy','https://www.youtube.com/embed/kJQP7kiw5Fk','Billie Eilish','Taylor Swift','Ed Sheeran','Luis Fonsi',4,'Despacito by Luis Fonsi ft. Daddy Yankee (2017) became one of the most viewed videos on YouTube.',10),
(5,'Which legendary band''s music video is shown?','video_scene','medium','https://www.youtube.com/embed/fJ9rUzIMcZQ','Led Zeppelin','AC/DC','Queen','The Rolling Stones',3,'Bohemian Rhapsody by Queen is one of the greatest rock songs ever made.',15),
(5,'Identify the singer in this music video:','video_scene','medium','https://www.youtube.com/embed/9bZkp7q19f0','Katy Perry','PSY','Rihanna','Beyoncé',2,'Gangnam Style by PSY (2012) was the first YouTube video to reach 1 billion views.',15),
(5,'Watch this iconic music video. Name the artist:','video_scene','easy','https://www.youtube.com/embed/JGwWNGJdvx8','Ed Sheeran','Justin Bieber','Bruno Mars','Shawn Mendes',1,'Shape of You by Ed Sheeran (2017) became one of the best-selling digital singles of all time.',10),
(5,'Which pop star is performing in this video?','video_scene','medium','https://www.youtube.com/embed/kffacxfA7G4','Ariana Grande','Dua Lipa','Billie Eilish','Taylor Swift',1,'Justin Bieber has been one of the most influential pop artists since his debut in 2009.',15);

-- ============================================================
-- VIDEO SCENE — SCIENCE (cat 8)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(8,'Watch this clip. What scientific concept is being demonstrated?','video_scene','medium','https://www.youtube.com/embed/E43-CfukEgs','Nuclear Fission','Quantum Tunneling','Double Slit Experiment','Gravity Waves',3,'The Double Slit Experiment demonstrates wave-particle duality in quantum mechanics.',15),
(8,'This video demonstrates which famous physics experiment?','video_scene','hard','https://www.youtube.com/embed/XFxM7FqEacY','Pendulum waves','Standing waves','Magnetic levitation','Tesla coil',1,'The Harvard pendulum wave demonstration shows beautiful wave interference patterns.',20),
(8,'Watch this experiment. What chemical reaction is happening?','video_scene','easy','https://www.youtube.com/embed/cK2V5VYJb54','Combustion','Fermentation','Elephant Toothpaste','Crystallization',3,'Elephant toothpaste is a rapid decomposition of hydrogen peroxide using a catalyst.',10);

-- ============================================================
-- VIDEO SCENE — SPORTS/FOOTBALL (cat 1)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(1,'Watch this famous football goal. Who scored it?','video_scene','hard','https://www.youtube.com/embed/HHg5gVJbKLU','Pelé','Diego Maradona','Ronaldo','Zidane',2,'Diego Maradona''s "Goal of the Century" in 1986 is voted the greatest goal ever scored.',20),
(1,'Which World Cup is shown in this highlights video?','video_scene','medium','https://www.youtube.com/embed/SYwR_fKsJ7A','2014 Brazil','2018 Russia','2010 South Africa','2022 Qatar',4,'The 2022 FIFA World Cup in Qatar ended with Argentina defeating France in a thrilling final.',15),
(1,'Watch this clip. Which football competition is being played?','video_scene','easy','https://www.youtube.com/embed/DlJf1PbIknM','FA Cup','La Liga','Champions League','World Cup',3,'The UEFA Champions League is the most prestigious club football competition in Europe.',10);

-- ============================================================
-- VIDEO SCENE — HISTORY (cat 7)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(7,'Watch this historical footage. What event is shown?','video_scene','medium','https://www.youtube.com/embed/smEqnnklfYs','Berlin Wall construction','Fall of the Berlin Wall','German Reunification ceremony','Cold War summit',2,'The Berlin Wall fell on November 9, 1989, marking the end of the Cold War era.',15),
(7,'This video shows which famous speech?','video_scene','hard','https://www.youtube.com/embed/vP4iY1TtS3s','Winston Churchill Iron Curtain','MLK I Have a Dream','JFK Moon speech','Roosevelt Pearl Harbor',2,'Martin Luther King Jr.''s "I Have a Dream" speech was delivered on August 28, 1963.',20);

-- ============================================================
-- VIDEO SCENE — SPACE (cat 13)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(13,'Watch this space video. What mission is shown?','video_scene','medium','https://www.youtube.com/embed/S5d5hhLqQ-Y','Apollo 13','Apollo 11 — Moon Landing','Gemini 8','Apollo 17',2,'Apollo 11 (July 20, 1969) was the first crewed Moon landing — Neil Armstrong stepped out first.',15),
(13,'Which space telescope launch is featured in this clip?','video_scene','hard','https://www.youtube.com/embed/4P8fKd0IVOs','Spitzer','Hubble','Kepler','James Webb Space Telescope',4,'The James Webb Space Telescope launched on December 25, 2021, revolutionizing astronomy.',20),
(13,'Watch this video. What space event is being documented?','video_scene','easy','https://www.youtube.com/embed/bDoh2LNFqzA','Satellite launch','SpaceX Falcon landing','Space station construction','Meteor shower',2,'SpaceX achieved the historic first vertical rocket landing with Falcon 9 in December 2015.',10);

-- ============================================================
-- VIDEO SCENE — CRICKET (cat 2)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(2,'Watch this cricket highlights video. Which World Cup is it from?','video_scene','medium','https://www.youtube.com/embed/Lu_Yat7g_5E','2011 ICC World Cup','2015 ICC World Cup','2019 ICC World Cup','2023 ICC World Cup',3,'The 2019 Cricket World Cup was held in England and won by England in a dramatic super over final.',15),
(2,'Which cricket shot technique is shown in this video?','video_scene','easy','https://www.youtube.com/embed/M28noFhGRyI','Cover Drive','Reverse Sweep','Helicopter Shot','Switch Hit',3,'The Helicopter Shot was famously invented by MS Dhoni and became his signature stroke.',10);

-- ============================================================
-- VIDEO SCENE — GAMING (cat 6)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(6,'Watch this game trailer. Which game is it?','video_scene','easy','https://www.youtube.com/embed/8X2kIfS6fb8','GTA V','GTA VI','Red Dead Redemption 2','Watch Dogs',1,'Grand Theft Auto V (2013) is one of the best-selling video games of all time.',10),
(6,'Identify this action-adventure game from its trailer:','video_scene','medium','https://www.youtube.com/embed/gmA6MrX81z4','God of War','The Witcher 3','Elden Ring','Dark Souls',3,'Elden Ring (2022) by FromSoftware became one of the highest-rated games ever made.',15),
(6,'Which racing game trailer is shown?','video_scene','easy','https://www.youtube.com/embed/fOm_1N9JczA','Need for Speed','Forza Horizon 5','Gran Turismo','Mario Kart',2,'Forza Horizon 5 (2021) is set in Mexico and features stunning open-world racing.',10);

-- ============================================================
-- VIDEO SCENE — TECHNOLOGY (cat 10)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(10,'Watch this product launch. What device is being revealed?','video_scene','medium','https://www.youtube.com/embed/vN4U5FqrOdQ','Galaxy S20','Pixel 6','iPhone X','OnePlus 9',3,'The iPhone X was revealed by Apple in 2017, introducing Face ID and an edge-to-edge display.',15),
(10,'Which AI technology is demonstrated in this video?','video_scene','hard','https://www.youtube.com/embed/D5VN56jQMWM','Siri','Google Duplex','Alexa','Cortana',2,'Google Duplex, demonstrated at Google I/O 2018, can make phone calls that sound remarkably human.',20);

-- ============================================================
-- IMAGE GUESS — GAMING (cat 6)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(6,'Identify this famous video game character:','image_guess','easy','https://upload.wikimedia.org/wikipedia/en/thumb/0/0a/LittleBigPlanet_characters.jpg/400px-LittleBigPlanet_characters.jpg','Master Chief','Sonic','Mario','Sackboy',4,'Sackboy is the main character in LittleBigPlanet, a PlayStation franchise.',10),
(6,'Which iconic game logo is shown?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Camponotus_flavomarginatus_ant.jpg/400px-Camponotus_flavomarginatus_ant.jpg','SimAnt','Empire of the Ants','Bug Fables','Ant Simulator',1,'SimAnt (1991) by Maxis was a simulation game about ant colonies.',15);

-- ============================================================
-- IMAGE GUESS — CARS (cat 11)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(11,'What car brand''s logo is shown?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Ferrari_logo.svg/400px-Ferrari_logo.svg.png','Lamborghini','Ferrari','Maserati','Alfa Romeo',2,'Ferrari''s prancing horse logo was originally the personal emblem of Italian WWI ace Francesco Baracca.',15),
(11,'Identify this classic car:','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/2011_Bugatti_Veyron_16.4_Grand_Sport_-_Flickr_-_Moto@Club4AG.jpg/400px-2011_Bugatti_Veyron_16.4_Grand_Sport_-_Flickr_-_Moto@Club4AG.jpg','Koenigsegg Agera','McLaren P1','Bugatti Veyron','Lamborghini Aventador',3,'The Bugatti Veyron was the first production car to break the 400 km/h barrier.',20);

-- ============================================================
-- VIDEO SCENE — CARS (cat 11)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(11,'Watch this supercar video. Which car is being reviewed?','video_scene','medium','https://www.youtube.com/embed/kcjGRXTpHGI','Ferrari LaFerrari','Lamborghini Aventador','Bugatti Chiron','McLaren P1',3,'The Bugatti Chiron is a hypercar with a W16 engine producing 1,500 horsepower.',15),
(11,'Which Formula 1 race is featured in these highlights?','video_scene','hard','https://www.youtube.com/embed/7DnHd0sJETM','Monaco Grand Prix','British Grand Prix','Italian Grand Prix','Abu Dhabi Grand Prix',4,'The Abu Dhabi Grand Prix has become one of the most dramatic season finales in F1.',20);

-- ============================================================
-- IMAGE GUESS — TECH (cat 10)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(10,'Which tech company''s logo is this?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Culinary_fruits_front_view.jpg/400px-Culinary_fruits_front_view.jpg','Microsoft','Google','Apple','Amazon',3,'Apple Inc. uses a bitten apple logo, one of the most recognized brands in the world.',10),
(10,'What computer component is shown?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Intel_80486DX2_bottom.jpg/400px-Intel_80486DX2_bottom.jpg','GPU','RAM chip','CPU processor chip','Network card',3,'A CPU (Central Processing Unit) is the brain of a computer, processing instructions.',15);

-- ============================================================
-- IMAGE GUESS — HISTORY (cat 7)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(7,'Who is the historical figure shown?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Mahatma-Gandhi%2C_studio%2C_1931.jpg/400px-Mahatma-Gandhi%2C_studio%2C_1931.jpg','Jawaharlal Nehru','Subhas Chandra Bose','Mahatma Gandhi','B.R. Ambedkar',3,'Mahatma Gandhi led India''s non-violent independence movement against British rule.',10),
(7,'Identify this world leader:','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/24_Portrait_of_Abraham_Lincoln.jpg/400px-24_Portrait_of_Abraham_Lincoln.jpg','George Washington','Theodore Roosevelt','John F. Kennedy','Abraham Lincoln',4,'Abraham Lincoln was the 16th US President, who led the country through the Civil War and abolished slavery.',15),
(7,'Who is shown in this historical photograph?','image_guess','hard','https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Albert_Einstein_Head.jpg/400px-Albert_Einstein_Head.jpg','Nikola Tesla','Max Planck','Albert Einstein','Werner Heisenberg',3,'Albert Einstein developed the theory of relativity and the famous equation E=mc².',20);

-- ============================================================
-- IMAGE GUESS — ANIME (cat 3)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(3,'Which Studio Ghibli character is shown?','image_guess','medium','https://upload.wikimedia.org/wikipedia/en/thumb/c/c2/Spirited_Away_Japanese_poster.jpg/400px-Spirited_Away_Japanese_poster.jpg','Howl','No-Face','Totoro','Chihiro / Sen',4,'Spirited Away (2001) won the Academy Award for Best Animated Feature.',15),
(3,'Identify this anime series from its visual style:','image_guess','hard','https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Neon_genesis_evangelion_logo.svg/400px-Neon_genesis_evangelion_logo.svg.png','Gurren Lagann','Mobile Suit Gundam','Neon Genesis Evangelion','Macross',3,'Neon Genesis Evangelion (1995) by Gainax revolutionized the mecha anime genre.',20);

-- ============================================================
-- VIDEO SCENE — ANIME (cat 3)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(3,'Watch this anime opening. Which series is it from?','video_scene','easy','https://www.youtube.com/embed/HnGn3_dv-SY','My Hero Academia','Attack on Titan','Demon Slayer','Jujutsu Kaisen',3,'Demon Slayer (Kimetsu no Yaiba) became a massive global hit with stunning animation.',10),
(3,'Identify this anime from its trailer:','video_scene','medium','https://www.youtube.com/embed/4OiMOHRDs14','Your Name','Weathering with You','Suzume','A Silent Voice',1,'Your Name (Kimi no Na wa) by Makoto Shinkai became the highest-grossing anime film at the time.',15);

-- ============================================================
-- VIDEO SCENE — INTERNET CULTURE (cat 14)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(14,'Watch this viral video. What is it called?','video_scene','easy','https://www.youtube.com/embed/dQw4w9WgXcQ','Nyan Cat','Charlie Bit My Finger','Never Gonna Give You Up','Keyboard Cat',3,'Rick Astley''s "Never Gonna Give You Up" became the internet''s most famous meme: Rickrolling.',10),
(14,'Which viral internet trend is shown in this video?','video_scene','medium','https://www.youtube.com/embed/9bZkp7q19f0','Harlem Shake','Gangnam Style','Ice Bucket Challenge','Mannequin Challenge',2,'Gangnam Style by PSY became the first YouTube video to reach 1 billion views in 2012.',15);

-- ============================================================
-- IMAGE GUESS — INTERNET CULTURE (cat 14)
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(14,'Which famous internet meme character is this?','image_guess','easy','https://upload.wikimedia.org/wikipedia/en/thumb/9/9a/Trollface_non-free.png/220px-Trollface_non-free.png','Forever Alone','Trollface','Rage Guy','Pepe the Frog',2,'Trollface is a rage comic character drawn in 2008, used to indicate internet trolling.',10);

-- ============================================================
-- MULTIMEDIA MIX CATEGORY (cat 15) — All types
-- ============================================================
INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(15,'Which famous landmark is shown in this photo?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Tour_eiffel_at_sunrise_from_the_trocadero.jpg/400px-Tour_eiffel_at_sunrise_from_the_trocadero.jpg','Big Ben','Statue of Liberty','Eiffel Tower','Leaning Tower of Pisa',3,'The Eiffel Tower in Paris was built in 1889 and stands 330 meters tall.',10),
(15,'Identify this world wonder:','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Kheops-Pyramid.jpg/400px-Kheops-Pyramid.jpg','Machu Picchu','Colosseum','Great Pyramid of Giza','Taj Mahal',3,'The Great Pyramid of Giza is the oldest of the Seven Wonders and was built around 2560 BC.',10),
(15,'What famous monument is shown?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Statue_of_Liberty%2C_NY.jpg/400px-Statue_of_Liberty%2C_NY.jpg','Christ the Redeemer','Statue of Liberty','Colossus of Rhodes','Moai statues',2,'The Statue of Liberty was a gift from France to the United States, dedicated in 1886.',15),
(15,'Which ancient structure is this?','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Colosseo_2020.jpg/400px-Colosseo_2020.jpg','Parthenon','Colosseum','Forum','Pantheon',2,'The Colosseum in Rome could hold 50,000-80,000 spectators for gladiatorial contests.',15),
(15,'Identify the animal in this photo:','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Tigerwater_edit2.jpg/400px-Tigerwater_edit2.jpg','Leopard','Jaguar','Lion','Tiger',4,'Tigers are the largest wild cats, recognizable by their distinctive orange and black stripes.',10),
(15,'What famous painting style is shown?','image_guess','hard','https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg/400px-Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg','Impressionism','Post-Impressionism','Cubism','Surrealism',2,'The Starry Night by Van Gogh (1889) is a Post-Impressionist masterpiece.',20),
(15,'Which famous bridge is shown?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/GoldenGateBridge-001.jpg/400px-GoldenGateBridge-001.jpg','Brooklyn Bridge','Tower Bridge','Golden Gate Bridge','Sydney Harbour Bridge',3,'The Golden Gate Bridge in San Francisco opened in 1937 and spans 2,737 meters.',10);

INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,audio_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(15,'Listen to this piece. What instrument is playing?','audio_guess','easy','https://upload.wikimedia.org/wikipedia/commons/transcoded/6/6d/Guitar_chord_progression.ogg/Guitar_chord_progression.ogg.mp3','Piano','Violin','Guitar','Drums',3,'The acoustic guitar produces sound by vibrating strings over a hollow body.',10),
(15,'Listen to this classical piece. Who composed it?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/6/6f/Moonlight_sonata.ogg/Moonlight_sonata.ogg.mp3','Mozart','Bach','Chopin','Beethoven',4,'Beethoven''s Moonlight Sonata (Piano Sonata No. 14) was composed in 1801.',15),
(15,'What is this famous melody?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/1/1e/Rondo_Alla_Turca.ogg/Rondo_Alla_Turca.ogg.mp3','Für Elise','Turkish March','Ode to Joy','Canon in D',2,'Mozart''s Rondo Alla Turca (Turkish March) is one of the most recognizable classical pieces.',15),
(15,'Listen to this sound. What natural event creates it?','audio_guess','easy','https://upload.wikimedia.org/wikipedia/commons/transcoded/d/db/Thunder.ogg/Thunder.ogg.mp3','Earthquake','Tornado','Thunder','Volcano',3,'Thunder is the sound produced by lightning rapidly heating the air.',10),
(15,'What brass instrument is being played?','audio_guess','medium','https://upload.wikimedia.org/wikipedia/commons/transcoded/4/49/Trumpet_E%E2%99%AD_major.ogg/Trumpet_E%E2%99%AD_major.ogg.mp3','Trombone','French Horn','Trumpet','Tuba',3,'The trumpet is a brass instrument known for its bright, penetrating tone.',15),
(15,'Which country''s national anthem is this?','audio_guess','hard','https://upload.wikimedia.org/wikipedia/commons/transcoded/a/a8/Us_anthem.ogg/Us_anthem.ogg.mp3','Canada','UK','France','United States',4,'The Star-Spangled Banner has been the US national anthem since 1931.',20);

INSERT IGNORE INTO questions (category_id,question_text,question_type,difficulty,video_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(15,'Watch this trailer. What movie is it from?','video_scene','easy','https://www.youtube.com/embed/5PSNL1qE6VY','The Lion King','Frozen','Moana','Coco',1,'The Lion King (1994) tells the story of Simba, a young lion prince in the African savanna.',10),
(15,'Which famous music video is this?','video_scene','easy','https://www.youtube.com/embed/kJQP7kiw5Fk','Shape of You','Despacito','Uptown Funk','Sorry',2,'Despacito was the first YouTube video to reach 7 billion views.',10),
(15,'Identify the game from this trailer:','video_scene','medium','https://www.youtube.com/embed/8X2kIfS6fb8','Red Dead Redemption','Need for Speed','GTA V','Watch Dogs',3,'Grand Theft Auto V (2013) has sold over 185 million copies worldwide.',15),
(15,'Watch this clip. What historical event is shown?','video_scene','hard','https://www.youtube.com/embed/smEqnnklfYs','D-Day landing','Fall of the Berlin Wall','Moon landing','End of WWII',2,'The Berlin Wall fell on November 9, 1989, symbolizing the end of the Cold War.',20),
(15,'Which science experiment is demonstrated?','video_scene','medium','https://www.youtube.com/embed/E43-CfukEgs','Acid-base reaction','Nuclear fusion','Double Slit Experiment','Electrolysis',3,'The Double Slit Experiment shows that particles can behave as both waves and particles.',15),
(15,'Watch this space video. What event is shown?','video_scene','medium','https://www.youtube.com/embed/S5d5hhLqQ-Y','SpaceX launch','Apollo 11 Moon Landing','ISS construction','Mars rover landing',2,'Apollo 11 made history on July 20, 1969 when Neil Armstrong became the first person on the Moon.',15),
(15,'Which viral internet video is this?','video_scene','easy','https://www.youtube.com/embed/dQw4w9WgXcQ','Gangnam Style','Nyan Cat','Never Gonna Give You Up','Harlem Shake',3,'Never Gonna Give You Up by Rick Astley (1987) became the most famous internet meme (Rickrolling).',10);

-- ============================================================
-- UPDATE QUESTION COUNTS
-- ============================================================
UPDATE categories c SET question_count = (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id AND q.is_active = 1);
