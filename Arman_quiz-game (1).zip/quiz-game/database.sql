-- ============================================================
-- Ultimate Multimedia Quiz Game - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS quiz_game CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE quiz_game;

-- ============================================================
-- USERS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    total_score INT DEFAULT 0,
    quizzes_played INT DEFAULT 0,
    correct_answers INT DEFAULT 0,
    total_answers INT DEFAULT 0,
    is_admin TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB;

-- ============================================================
-- CATEGORIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(10) DEFAULT '🎯',
    color VARCHAR(7) DEFAULT '#6c63ff',
    color2 VARCHAR(7) DEFAULT '#48cfad',
    description TEXT,
    question_count INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- QUESTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('multiple_choice','true_false','image_guess','audio_guess','video_scene') DEFAULT 'multiple_choice',
    difficulty ENUM('easy','medium','hard') DEFAULT 'medium',
    image_path VARCHAR(500) DEFAULT NULL,
    audio_path VARCHAR(500) DEFAULT NULL,
    video_path VARCHAR(500) DEFAULT NULL,
    option1 VARCHAR(500) NOT NULL,
    option2 VARCHAR(500) NOT NULL,
    option3 VARCHAR(500) DEFAULT NULL,
    option4 VARCHAR(500) DEFAULT NULL,
    correct_option TINYINT NOT NULL COMMENT '1=option1, 2=option2, 3=option3, 4=option4',
    explanation TEXT DEFAULT NULL,
    points INT DEFAULT 10,
    times_played INT DEFAULT 0,
    times_correct INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- SCORES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    game_mode ENUM('quick','time_attack','survival','endless') DEFAULT 'quick',
    difficulty ENUM('easy','medium','hard','mixed') DEFAULT 'mixed',
    score INT NOT NULL DEFAULT 0,
    correct_answers INT DEFAULT 0,
    total_questions INT DEFAULT 0,
    time_taken INT DEFAULT 0 COMMENT 'seconds',
    date_played TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- ACHIEVEMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    badge_icon VARCHAR(10) DEFAULT '🏅',
    badge_color VARCHAR(7) DEFAULT '#FFD700',
    condition_type VARCHAR(50) NOT NULL COMMENT 'score_total, quizzes_played, category_master, perfect_score, etc.',
    condition_value INT DEFAULT 1,
    condition_category INT DEFAULT NULL,
    xp_reward INT DEFAULT 50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- USER ACHIEVEMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS user_achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    achievement_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_achievement (user_id, achievement_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- GAME SESSIONS TABLE (for active quizzes)
-- ============================================================
CREATE TABLE IF NOT EXISTS game_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    game_mode VARCHAR(20) DEFAULT 'quick',
    difficulty VARCHAR(10) DEFAULT 'mixed',
    question_ids TEXT NOT NULL COMMENT 'JSON array of question IDs',
    current_index INT DEFAULT 0,
    score INT DEFAULT 0,
    correct INT DEFAULT 0,
    lives INT DEFAULT 3 COMMENT 'for survival mode',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL 1 HOUR),
    is_complete TINYINT(1) DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- DEFAULT CATEGORIES
-- ============================================================
INSERT INTO categories (name, slug, icon, color, color2, description) VALUES
('Football', 'football', '⚽', '#00c853', '#69f0ae', 'Test your football knowledge'),
('Cricket', 'cricket', '🏏', '#ff6d00', '#ffab40', 'All about cricket'),
('Anime', 'anime', '🎌', '#e91e63', '#f48fb1', 'Anime characters, shows and lore'),
('Movies', 'movies', '🎬', '#9c27b0', '#ce93d8', 'Blockbusters, classics and trivia'),
('Music', 'music', '🎵', '#3949ab', '#7986cb', 'Artists, lyrics and beats'),
('Gaming', 'gaming', '🎮', '#00bcd4', '#80deea', 'Video games history and trivia'),
('History', 'history', '📜', '#795548', '#bcaaa4', 'World history from ancient to modern'),
('Science', 'science', '🔬', '#00acc1', '#80deea', 'Physics, chemistry, biology'),
('World Knowledge', 'world-knowledge', '🌍', '#43a047', '#a5d6a7', 'General world facts'),
('Technology', 'technology', '💻', '#1e88e5', '#90caf9', 'Tech, gadgets, and innovation'),
('Cars', 'cars', '🚗', '#e53935', '#ef9a9a', 'Automobiles and motorsport'),
('Geography', 'geography', '🗺️', '#26a69a', '#80cbc4', 'Countries, capitals, maps'),
('Space', 'space', '🚀', '#5e35b1', '#b39ddb', 'Universe, planets and astronomy'),
('Internet Culture', 'internet-culture', '📱', '#f57c00', '#ffcc02', 'Memes, viral trends, social media');

-- ============================================================
-- DEFAULT ACHIEVEMENTS
-- ============================================================
INSERT INTO achievements (name, description, badge_icon, badge_color, condition_type, condition_value, xp_reward) VALUES
('First Steps', 'Complete your first quiz', '🎯', '#FFD700', 'quizzes_played', 1, 50),
('On Fire', 'Complete 10 quizzes', '🔥', '#FF6B35', 'quizzes_played', 10, 150),
('Quiz Veteran', 'Complete 50 quizzes', '⚔️', '#C0C0C0', 'quizzes_played', 50, 500),
('Quiz Legend', 'Complete 100 quizzes', '👑', '#FFD700', 'quizzes_played', 100, 1000),
('Sharp Mind', 'Reach a total score of 1000', '🧠', '#9C27B0', 'score_total', 1000, 200),
('High Scorer', 'Reach a total score of 5000', '⭐', '#FF5722', 'score_total', 5000, 500),
('Perfect Round', 'Get 100% on any quiz', '💎', '#00BCD4', 'perfect_score', 1, 300),
('Speed Demon', 'Win a Time Attack quiz', '⚡', '#FFC107', 'mode_time_attack', 1, 250),
('Survivor', 'Complete a Survival Mode quiz', '💀', '#607D8B', 'mode_survival', 1, 350),
('Endless Runner', 'Answer 50 questions in Endless Mode', '🔁', '#4CAF50', 'endless_questions', 50, 400);

-- ============================================================
-- SAMPLE QUESTIONS - Science
-- ============================================================
INSERT INTO questions (category_id, question_text, difficulty, option1, option2, option3, option4, correct_option, points) VALUES
(8, 'What is the chemical symbol for Gold?', 'easy', 'Go', 'Au', 'Ag', 'Gd', 2, 10),
(8, 'How many bones are in the adult human body?', 'medium', '196', '206', '216', '226', 2, 15),
(8, 'What planet is known as the Red Planet?', 'easy', 'Venus', 'Jupiter', 'Mars', 'Saturn', 3, 10),
(8, 'What is the speed of light (approx)?', 'medium', '300,000 km/s', '150,000 km/s', '450,000 km/s', '3,000 km/s', 1, 15),
(8, 'What gas do plants absorb from the atmosphere?', 'easy', 'Oxygen', 'Nitrogen', 'Carbon Dioxide', 'Hydrogen', 3, 10),
(8, 'Who developed the theory of general relativity?', 'medium', 'Isaac Newton', 'Nikola Tesla', 'Albert Einstein', 'Stephen Hawking', 3, 15),
(8, 'What is the powerhouse of the cell?', 'easy', 'Nucleus', 'Mitochondria', 'Ribosome', 'Golgi Body', 2, 10),
(8, 'What is the atomic number of carbon?', 'medium', '6', '8', '12', '14', 1, 15),
(8, 'Which element has the symbol Fe?', 'easy', 'Fluorine', 'Iron', 'Francium', 'Fermium', 2, 10),
(8, 'What is the half-life concept related to?', 'hard', 'Evolution', 'Radioactive decay', 'Cell division', 'Photosynthesis', 2, 20);

-- ============================================================
-- SAMPLE QUESTIONS - Technology
-- ============================================================
INSERT INTO questions (category_id, question_text, difficulty, option1, option2, option3, option4, correct_option, points) VALUES
(10, 'What does HTML stand for?', 'easy', 'HyperText Machine Language', 'HyperText Markup Language', 'HighText Markup Language', 'HyperTransfer Markup Language', 2, 10),
(10, 'Who founded Apple Inc.?', 'easy', 'Bill Gates', 'Steve Jobs', 'Elon Musk', 'Mark Zuckerberg', 2, 10),
(10, 'What does CPU stand for?', 'easy', 'Central Processing Unit', 'Computer Processing Unit', 'Core Processing Unit', 'Central Program Unit', 1, 10),
(10, 'Which language is primarily used for styling web pages?', 'easy', 'JavaScript', 'Python', 'CSS', 'PHP', 3, 10),
(10, 'What is the full form of AI?', 'easy', 'Automated Intelligence', 'Artificial Intelligence', 'Advanced Interface', 'Actual Intelligence', 2, 10),
(10, 'What does GPU stand for?', 'medium', 'Global Processing Unit', 'Graphical Programming Unit', 'Graphics Processing Unit', 'General Purpose Unit', 3, 15),
(10, 'Which company created the Android OS?', 'medium', 'Apple', 'Microsoft', 'Google', 'Samsung', 3, 15),
(10, 'What is the binary representation of the number 10?', 'medium', '1010', '1100', '1001', '0110', 1, 15),
(10, 'Which protocol is used for secure web browsing?', 'medium', 'HTTP', 'FTP', 'HTTPS', 'SMTP', 3, 15),
(10, 'What does RAM stand for?', 'easy', 'Read Access Memory', 'Random Access Memory', 'Rapid Access Memory', 'Remote Access Memory', 2, 10);

-- ============================================================
-- SAMPLE QUESTIONS - Geography
-- ============================================================
INSERT INTO questions (category_id, question_text, difficulty, option1, option2, option3, option4, correct_option, points) VALUES
(12, 'What is the capital of France?', 'easy', 'London', 'Berlin', 'Paris', 'Rome', 3, 10),
(12, 'Which is the largest country by area?', 'easy', 'China', 'USA', 'Canada', 'Russia', 4, 10),
(12, 'What is the longest river in the world?', 'medium', 'Amazon', 'Nile', 'Yangtze', 'Mississippi', 2, 15),
(12, 'Which continent is the Sahara Desert in?', 'easy', 'Asia', 'Australia', 'Africa', 'South America', 3, 10),
(12, 'What is the capital of Japan?', 'easy', 'Seoul', 'Beijing', 'Tokyo', 'Bangkok', 3, 10),
(12, 'Which ocean is the largest?', 'easy', 'Atlantic', 'Indian', 'Arctic', 'Pacific', 4, 10),
(12, 'Mount Everest is in which country?', 'medium', 'India', 'China', 'Nepal', 'Bhutan', 3, 15),
(12, 'What is the smallest country in the world?', 'medium', 'Monaco', 'San Marino', 'Vatican City', 'Liechtenstein', 3, 15),
(12, 'Which country has the most natural lakes?', 'hard', 'USA', 'Canada', 'Russia', 'Finland', 2, 20),
(12, 'What is the capital of Australia?', 'medium', 'Sydney', 'Melbourne', 'Brisbane', 'Canberra', 4, 15);

-- ============================================================
-- SAMPLE QUESTIONS - Space
-- ============================================================
INSERT INTO questions (category_id, question_text, difficulty, option1, option2, option3, option4, correct_option, points) VALUES
(13, 'What is the closest star to Earth?', 'easy', 'Sirius', 'Alpha Centauri', 'The Sun', 'Betelgeuse', 3, 10),
(13, 'How many planets are in our solar system?', 'easy', '7', '8', '9', '10', 2, 10),
(13, 'Which planet is the largest?', 'easy', 'Saturn', 'Neptune', 'Uranus', 'Jupiter', 4, 10),
(13, 'What galaxy do we live in?', 'easy', 'Andromeda', 'Milky Way', 'Triangulum', 'Whirlpool', 2, 10),
(13, 'Who was the first human to walk on the Moon?', 'medium', 'Buzz Aldrin', 'Yuri Gagarin', 'Neil Armstrong', 'Michael Collins', 3, 15),
(13, 'What is a light year?', 'medium', 'Time light takes to travel 1 year', 'Distance light travels in 1 year', 'Speed of light per year', 'Mass of light per year', 2, 15),
(13, 'Which planet has the most moons?', 'hard', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 2, 20),
(13, 'What is the name of the first artificial satellite?', 'medium', 'Explorer 1', 'Sputnik 1', 'Vostok 1', 'Apollo 1', 2, 15),
(13, 'What is the Great Red Spot on Jupiter?', 'medium', 'A volcano', 'A storm', 'A crater', 'A sea', 2, 15),
(13, 'How long does light from the Sun take to reach Earth?', 'hard', '2 minutes', '8 minutes', '20 minutes', '1 hour', 2, 20);

-- Update question counts for categories
UPDATE categories c SET question_count = (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id);
