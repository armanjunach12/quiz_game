-- ============================================================
-- QuizVerse — Questions for all 14 categories
-- category_id: 1=Football, 2=Cricket, 3=Anime, 4=Movies
--              5=Music, 6=Gaming, 7=History, 8=Science
--              9=World Knowledge, 10=Technology, 11=Cars
--              12=Geography, 13=Space, 14=Internet Culture
-- ============================================================

-- ============================================================
-- FOOTBALL (cat 1) — with player photo image_path
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(1,'Which player is shown in this photo holding the Ballon d''Or trophy?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Lionel-Messi-Argentina-2022-FIFA-World-Cup_%28cropped%29.jpg/440px-Lionel-Messi-Argentina-2022-FIFA-World-Cup_%28cropped%29.jpg','Cristiano Ronaldo','Lionel Messi','Neymar','Kylian Mbappé',2,'Lionel Messi has won the Ballon d''Or a record 8 times.',15),
(1,'Who is this Portuguese superstar?','image_guess','easy','https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Cristiano_Ronaldo_2018.jpg/440px-Cristiano_Ronaldo_2018.jpg','Lionel Messi','Luis Figo','Cristiano Ronaldo','João Félix',3,'Cristiano Ronaldo is one of the greatest footballers ever, known for his athleticism.',15),
(1,'Identify this French forward:','image_guess','medium','https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/2019-07-17_SG_Dynamo_Dresden_vs_Paris_Saint-Germain_by_Sandro_Halank%E2%80%931.jpg/440px-2019-07-17_SG_Dynamo_Dresden_vs_Paris_Saint-Germain_by_Sandro_Halank%E2%80%931.jpg','Antoine Griezmann','Marcus Rashford','Kylian Mbappé','Karim Benzema',3,'Kylian Mbappé became the second youngest World Cup final scorer in history.',20),
(1,'Which country has won the most FIFA World Cups?','multiple_choice','easy',NULL,'Germany','Argentina','Brazil','Italy',3,'Brazil has won the FIFA World Cup 5 times.',10),
(1,'How many players are on a standard football team on the field?','multiple_choice','easy',NULL,'9','10','11','12',3,'Each team fields 11 players including the goalkeeper.',10),
(1,'Which club has won the most UEFA Champions League titles?','multiple_choice','medium',NULL,'Bayern Munich','Barcelona','AC Milan','Real Madrid',4,'Real Madrid has won the Champions League 14 times.',15),
(1,'Pelé played for which national team?','multiple_choice','easy',NULL,'Argentina','Portugal','Brazil','Spain',3,'Pelé represented Brazil and won 3 World Cups with the team.',10),
(1,'Who scored the "Hand of God" goal?','multiple_choice','medium',NULL,'Pelé','Diego Maradona','Ronaldo','Zidane',2,'Diego Maradona scored the infamous "Hand of God" goal against England in 1986.',15),
(1,'The FIFA World Cup trophy is made of what material?','multiple_choice','medium',NULL,'Silver','Gold-plated bronze','Pure gold','Platinum',2,'The trophy is made of 18-carat gold-plated bronze.',15),
(1,'Which player has scored the most goals in Premier League history?','multiple_choice','hard',NULL,'Alan Shearer','Wayne Rooney','Andrew Cole','Frank Lampard',1,'Alan Shearer scored 260 Premier League goals.',20),
(1,'Where was the 2022 FIFA World Cup held?','multiple_choice','easy',NULL,'Russia','Brazil','Qatar','UAE',3,'The 2022 FIFA World Cup was held in Qatar.',10),
(1,'Which goalkeeper is known as "The Black Spider"?','multiple_choice','hard',NULL,'Peter Schmeichel','Oliver Kahn','Lev Yashin','Gianluigi Buffon',3,'Lev Yashin, nicknamed the Black Spider, is considered the greatest goalkeeper ever.',20),
(1,'Ronaldo''s famous free-kick wall jump technique is from which era?','multiple_choice','hard',NULL,'1960s','1990s','2000s','2010s',3,'Ronaldo''s unique running-up free kick style became iconic in the early 2000s.',20),
(1,'Which stadium has the largest capacity in football?','multiple_choice','hard',NULL,'Camp Nou','Wembley','Rungrado 1st of May','Maracanã',3,'Rungrado 1st of May Stadium in North Korea can hold 114,000 spectators.',20),
(1,'Zinedine Zidane is from which country?','multiple_choice','easy',NULL,'Morocco','Tunisia','Algeria','France',4,'Zinedine Zidane was born in France to Algerian parents.',10);

-- ============================================================
-- CRICKET (cat 2) — with player photo image_path
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(2,'Who is the highest run-scorer in international cricket?','multiple_choice','easy',NULL,'Ricky Ponting','Brian Lara','Sachin Tendulkar','Jacques Kallis',3,'Sachin Tendulkar has scored over 34,000 international runs.',10),
(2,'In cricket, how many balls are in a standard over?','multiple_choice','easy',NULL,'4','5','6','8',3,'A standard over in cricket consists of 6 legal deliveries.',10),
(2,'Which country won the first-ever Cricket World Cup in 1975?','multiple_choice','medium',NULL,'Australia','England','West Indies','India',3,'The West Indies won the inaugural Cricket World Cup in 1975.',15),
(2,'What does LBW stand for in cricket?','multiple_choice','easy',NULL,'Left Before Wicket','Leg Before Wicket','Line Behind Wicket','Leg Beyond Wicket',2,'LBW means Leg Before Wicket — out if the ball would have hit the stumps.',10),
(2,'Who scored 400* (not out) in a single Test innings?','multiple_choice','hard',NULL,'Don Bradman','Brian Lara','Sachin Tendulkar','Virender Sehwag',2,'Brian Lara scored 400* against England in 2004.',20),
(2,'Don Bradman''s Test batting average is closest to which number?','multiple_choice','hard',NULL,'70','80','90','99.94',4,'Don Bradman''s average of 99.94 is considered the greatest in Test cricket.',20),
(2,'Which format of cricket lasts only 20 overs per side?','multiple_choice','easy',NULL,'Test Match','One Day International','T20','T10',3,'T20 cricket consists of 20 overs per team.',10),
(2,'Which country invented cricket?','multiple_choice','medium',NULL,'Australia','India','Pakistan','England',4,'Cricket originated in England in the 16th century.',15),
(2,'Jasprit Bumrah plays for which national team?','multiple_choice','easy',NULL,'Pakistan','Sri Lanka','India','Bangladesh',3,'Jasprit Bumrah is the ace fast bowler for Team India.',10),
(2,'Which bowler has taken the most wickets in Test cricket?','multiple_choice','hard',NULL,'Glenn McGrath','Shane Warne','Muttiah Muralitharan','James Anderson',3,'Muttiah Muralitharan has taken 800 Test wickets.',20),
(2,'The Ashes series is played between which two countries?','multiple_choice','easy',NULL,'India and Pakistan','England and Australia','South Africa and New Zealand','West Indies and England',2,'The Ashes is the famous rivalry between England and Australia.',10),
(2,'A "hat-trick" in cricket means a bowler gets wickets on how many consecutive balls?','multiple_choice','easy',NULL,'2','3','4','5',2,'A hat-trick means 3 wickets on 3 consecutive deliveries.',10),
(2,'Which ground is known as the "Home of Cricket"?','multiple_choice','medium',NULL,'Eden Gardens','MCG','Lords','The Oval',3,'Lord''s Cricket Ground in London is known as the Home of Cricket.',15),
(2,'MS Dhoni''s famous World Cup 2011 winning shot was a?','multiple_choice','medium',NULL,'Pull shot','Cut shot','Six over long-on','Sweep shot',3,'Dhoni hit a massive six over long-on to win India the 2011 World Cup.',15),
(2,'Which team wears yellow in the IPL known as "Men in Yellow"?','multiple_choice','easy',NULL,'Mumbai Indians','Delhi Capitals','Chennai Super Kings','Kolkata Knight Riders',3,'Chennai Super Kings wear yellow and are called "Men in Yellow".',10);

-- ============================================================
-- ANIME (cat 3)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(3,'In Naruto, what is the name of the nine-tailed fox sealed inside Naruto?','multiple_choice','easy',NULL,'Hachibi','Kurama','Shukaku','Matatabi',2,'Kurama is the Nine-Tails, sealed inside Naruto by his father Minato.',10),
(3,'Who created the manga "Dragon Ball"?','multiple_choice','easy',NULL,'Eiichiro Oda','Masashi Kishimoto','Akira Toriyama','Hajime Isayama',3,'Akira Toriyama created Dragon Ball, which debuted in 1984.',10),
(3,'In Attack on Titan, what is the goal of the Survey Corps?','multiple_choice','medium',NULL,'Protect the king','Explore beyond the walls','Defeat the Titans inside Wall Maria','Build bigger walls',2,'The Survey Corps ventures outside the walls to explore and fight Titans.',15),
(3,'What is the name of the all-powerful technique Goku uses?','multiple_choice','easy',NULL,'Rasengan','Kamehameha','Chidori','Getsuga Tensho',2,'The Kamehameha is Goku''s signature energy blast in Dragon Ball.',10),
(3,'In One Piece, what is Luffy''s first mate''s name?','multiple_choice','easy',NULL,'Sanji','Usopp','Zoro','Nami',3,'Roronoa Zoro is Luffy''s first mate and a master swordsman.',10),
(3,'Which anime features the "Scouting Legion" and colossal humanoid monsters?','multiple_choice','easy',NULL,'Naruto','Bleach','Attack on Titan','My Hero Academia',3,'Attack on Titan (Shingeki no Kyojin) features Titans and the Survey Corps.',10),
(3,'What quirk does Izuku Midoriya inherit in My Hero Academia?','multiple_choice','easy',NULL,'Explosion','Half-Cold Half-Hot','One For All','Zero Gravity',3,'Izuku inherits One For All from All Might.',10),
(3,'In Death Note, what must Light Yagami write in the Death Note?','multiple_choice','easy',NULL,'The person''s address','The person''s name','The person''s crime','The person''s age',2,'Writing a person''s name in the Death Note causes their death.',10),
(3,'Which studio produced Spirited Away?','multiple_choice','medium',NULL,'Toei Animation','Sunrise','Madhouse','Studio Ghibli',4,'Studio Ghibli directed by Hayao Miyazaki produced Spirited Away.',15),
(3,'Spike Spiegel is the protagonist of which anime?','multiple_choice','hard',NULL,'Trigun','Cowboy Bebop','Outlaw Star','Samurai Champloo',2,'Spike Spiegel is the bounty hunter lead in Cowboy Bebop.',20),
(3,'In Sword Art Online, the game traps players using what device?','multiple_choice','medium',NULL,'VR Gloves','NerveGear helmet','Brain chip','Contact lenses',2,'The NerveGear creates full-dive VR and traps players inside SAO.',15),
(3,'Tanjiro Kamado''s sister Nezuko was turned into what?','multiple_choice','easy',NULL,'A zombie','A demon','A spirit','A wolf',2,'Nezuko was turned into a demon but retained her humanity.',10),
(3,'Which anime is set in the world of "Titans" and "Eldians"?','multiple_choice','medium',NULL,'Tokyo Ghoul','Fullmetal Alchemist','Attack on Titan','Vinland Saga',3,'Attack on Titan''s lore centers on Eldians and their Titan powers.',15),
(3,'What is the name of Sasuke''s older brother in Naruto?','multiple_choice','easy',NULL,'Madara','Obito','Itachi','Nagato',3,'Itachi Uchiha is Sasuke''s older brother who massacred the Uchiha clan.',10),
(3,'In Fullmetal Alchemist, what is the one thing alchemy cannot create?','multiple_choice','medium',NULL,'Gold','Life from nothing','Weapons','Stones',2,'The First Law of Alchemy is that you cannot create life without an equivalent exchange.',15);

-- ============================================================
-- MOVIES (cat 4)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(4,'Who directed Titanic (1997)?','multiple_choice','easy',NULL,'Steven Spielberg','Christopher Nolan','James Cameron','Ridley Scott',3,'James Cameron directed and wrote Titanic, which won 11 Academy Awards.',10),
(4,'Which actor played Iron Man in the MCU?','multiple_choice','easy',NULL,'Chris Evans','Chris Hemsworth','Robert Downey Jr.','Mark Ruffalo',3,'Robert Downey Jr. portrayed Tony Stark / Iron Man across the MCU.',10),
(4,'Which film won the first Academy Award for Best Picture?','multiple_choice','hard',NULL,'Wings','Gone with the Wind','All Quiet on the Western Front','It Happened One Night',1,'Wings (1927) won the first Academy Award for Best Picture in 1929.',20),
(4,'In The Dark Knight, who played the Joker?','multiple_choice','easy',NULL,'Jack Nicholson','Jared Leto','Joaquin Phoenix','Heath Ledger',4,'Heath Ledger''s iconic Joker performance earned him a posthumous Oscar.',10),
(4,'What is the highest-grossing film of all time?','multiple_choice','medium',NULL,'Titanic','Avengers: Endgame','Avatar','The Lion King',3,'Avatar (2009) holds the record for highest worldwide box office gross.',15),
(4,'The phrase "I''ll be back" is from which movie?','multiple_choice','easy',NULL,'Predator','RoboCop','The Terminator','Commando',3,'Arnold Schwarzenegger''s famous line is from The Terminator (1984).',10),
(4,'Which movie features a character named Forrest Gump?','multiple_choice','easy',NULL,'Cast Away','Philadelphia','Big','Forrest Gump',4,'Tom Hanks plays Forrest Gump in the 1994 film of the same name.',10),
(4,'Who played Jack Sparrow in Pirates of the Caribbean?','multiple_choice','easy',NULL,'Orlando Bloom','Keira Knightley','Bill Nighy','Johnny Depp',4,'Johnny Depp portrayed the eccentric Captain Jack Sparrow.',10),
(4,'Which Pixar film features a rat who wants to cook?','multiple_choice','easy',NULL,'A Bug''s Life','Ratatouille','The Incredibles','Finding Nemo',2,'Ratatouille (2007) features Remy the rat who dreams of being a chef.',10),
(4,'In Inception, what does Cobb use as a totem?','multiple_choice','medium',NULL,'A coin','A chess piece','A spinning top','A wedding ring',3,'Cobb uses a spinning top to determine if he is in a dream.',15),
(4,'The Silence of the Lambs (1991) features which serial killer?','multiple_choice','medium',NULL,'Norman Bates','Hannibal Lecter','Patrick Bateman','John Doe',2,'Anthony Hopkins played the cannibalistic psychiatrist Hannibal Lecter.',15),
(4,'Which film is set entirely on a deserted island after a plane crash?','multiple_choice','medium',NULL,'Gravity','127 Hours','The Martian','Cast Away',4,'Cast Away stars Tom Hanks surviving alone after a plane crash.',15),
(4,'Who voices Woody in Toy Story?','multiple_choice','easy',NULL,'Tom Hanks','Jim Carrey','Robin Williams','Billy Crystal',1,'Tom Hanks has voiced Woody in all Toy Story films.',10),
(4,'Which 2019 Marvel film grossed over $2.7 billion?','multiple_choice','medium',NULL,'Spider-Man: Far From Home','Captain Marvel','Avengers: Infinity War','Avengers: Endgame',4,'Avengers: Endgame became the highest-grossing film ever in 2019.',15),
(4,'The Godfather is based on a novel by which author?','multiple_choice','hard',NULL,'Stephen King','Mario Puzo','Elmore Leonard','John Grisham',2,'Mario Puzo wrote the 1969 novel on which the film is based.',20);

-- ============================================================
-- MUSIC (cat 5)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(5,'Which artist is known as the "King of Pop"?','multiple_choice','easy',NULL,'Elvis Presley','Prince','Michael Jackson','Madonna',3,'Michael Jackson earned the title King of Pop for his revolutionary music and dance.',10),
(5,'Which band sang "Bohemian Rhapsody"?','multiple_choice','easy',NULL,'Led Zeppelin','The Beatles','Queen','ABBA',3,'Bohemian Rhapsody (1975) is by Queen, written by Freddie Mercury.',10),
(5,'How many strings does a standard guitar have?','multiple_choice','easy',NULL,'4','5','6','7',3,'A standard acoustic or electric guitar has 6 strings.',10),
(5,'Which female artist sang "Hello" in 2015?','multiple_choice','easy',NULL,'Beyoncé','Rihanna','Adele','Taylor Swift',3,'Adele''s Hello was released in 2015 and topped charts worldwide.',10),
(5,'What nationality is the band BTS?','multiple_choice','easy',NULL,'Japanese','Chinese','Thai','South Korean',4,'BTS is a South Korean K-pop group formed in 2013.',10),
(5,'Who wrote and performed "Thriller"?','multiple_choice','easy',NULL,'Prince','Janet Jackson','Michael Jackson','Stevie Wonder',3,'Thriller (1982) by Michael Jackson is the best-selling album of all time.',10),
(5,'What instrument does Yo-Yo Ma play?','multiple_choice','medium',NULL,'Violin','Piano','Cello','Flute',3,'Yo-Yo Ma is a world-renowned cellist.',15),
(5,'Which decade did Hip-Hop originate?','multiple_choice','medium',NULL,'1960s','1970s','1980s','1990s',2,'Hip-hop originated in the South Bronx, New York in the 1970s.',15),
(5,'The song "Imagine" was written and performed by?','multiple_choice','easy',NULL,'Paul McCartney','Mick Jagger','John Lennon','Elton John',3,'John Lennon released Imagine in 1971.',10),
(5,'Which streaming platform pays artists per-stream royalties?','multiple_choice','easy',NULL,'YouTube','SoundCloud','Spotify','Apple Music',3,'Spotify is the most widely known music streaming platform with per-stream royalties.',10),
(5,'Which artist has the most Grammy wins ever?','multiple_choice','hard',NULL,'Taylor Swift','Beyoncé','Michael Jackson','Paul Simon',2,'Beyoncé holds the record for most Grammy wins with 32 (as of 2024).',20),
(5,'What does "EDM" stand for?','multiple_choice','easy',NULL,'Electronic Dance Music','Extended Digital Mix','Extreme Dynamic Music','Electric Digital Melody',1,'EDM stands for Electronic Dance Music.',10),
(5,'"Shape of You" was a massive hit for which British artist?','multiple_choice','easy',NULL,'James Arthur','Harry Styles','Sam Smith','Ed Sheeran',4,'Shape of You by Ed Sheeran was released in 2017.',10),
(5,'Which music festival is held annually in Glastonbury, England?','multiple_choice','medium',NULL,'Coachella','Tomorrowland','Glastonbury Festival','Reading Festival',3,'Glastonbury Festival is one of the world''s most famous music events.',15),
(5,'Beethoven composed how many symphonies?','multiple_choice','medium',NULL,'5','7','9','12',3,'Ludwig van Beethoven composed 9 symphonies.',15);

-- ============================================================
-- GAMING (cat 6)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(6,'Which company created the Pokémon franchise?','multiple_choice','easy',NULL,'Sega','Nintendo','Bandai Namco','Square Enix',2,'The Pokémon franchise was created by Game Freak and published by Nintendo.',10),
(6,'What is the best-selling video game of all time?','multiple_choice','medium',NULL,'Tetris','Minecraft','GTA V','Wii Sports',2,'Minecraft is the best-selling video game with over 300 million copies sold.',15),
(6,'In the Legend of Zelda, what is the name of the main hero?','multiple_choice','easy',NULL,'Zelda','Ganon','Link','Epona',3,'The hero of the Legend of Zelda series is named Link, not Zelda.',10),
(6,'Which game features the characters Master Chief?','multiple_choice','easy',NULL,'Call of Duty','Gears of War','Halo','Doom',3,'Master Chief is the protagonist of the Halo franchise by Bungie/343 Industries.',10),
(6,'What is a "battle royale" game mode?','multiple_choice','medium',NULL,'Team objective mode','Co-op story mode','Last player standing wins','Racing mode',3,'Battle royale involves many players fighting until only one player or team remains.',15),
(6,'Which game popularized the battle royale genre massively in 2017?','multiple_choice','easy',NULL,'H1Z1','Fortnite','PUBG','Warzone',3,'Fortnite and PUBG both exploded in 2017, but Fortnite gained the most players.',10),
(6,'What does "NPC" stand for in gaming?','multiple_choice','easy',NULL,'New Player Character','Non-Playable Character','Next Power Core','Neutral Player Control',2,'NPC stands for Non-Playable Character — characters controlled by the game AI.',10),
(6,'In chess, which piece can only move diagonally?','multiple_choice','easy',NULL,'Rook','Knight','Bishop','Queen',3,'The Bishop moves only diagonally any number of squares.',10),
(6,'Sonic the Hedgehog is a mascot for which company?','multiple_choice','easy',NULL,'Nintendo','Atari','Sega','Sony',3,'Sonic was created by Sega in 1991 as their mascot.',10),
(6,'Which fighting game features Ryu and Ken as main characters?','multiple_choice','easy',NULL,'Tekken','Mortal Kombat','Street Fighter','King of Fighters',3,'Street Fighter by Capcom features Ryu and Ken as iconic characters.',10),
(6,'Grand Theft Auto V was released in which year?','multiple_choice','medium',NULL,'2010','2012','2013','2015',3,'GTA V was released by Rockstar Games in September 2013.',15),
(6,'Which game has the map locations: Tilted Towers and Loot Lake?','multiple_choice','medium',NULL,'PUBG','Apex Legends','Warzone','Fortnite',4,'Tilted Towers and Loot Lake are iconic locations in Fortnite.',15),
(6,'What is the currency called in the Pokémon games?','multiple_choice','easy',NULL,'Gold','Coins','PokéDollars','Credits',3,'The in-game currency in Pokémon games is called PokéDollars.',10),
(6,'The Elder Scrolls V is also known as?','multiple_choice','easy',NULL,'Oblivion','Morrowind','Skyrim','Arena',3,'The Elder Scrolls V: Skyrim was released in 2011 and became a cultural phenomenon.',10),
(6,'Which country developed the game "Among Us"?','multiple_choice','medium',NULL,'Japan','South Korea','USA','Canada',3,'Among Us was developed by InnerSloth, an American indie game studio.',15);

-- ============================================================
-- HISTORY (cat 7)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,image_path,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(7,'Who was the first President of the United States?','multiple_choice','easy',NULL,'John Adams','Thomas Jefferson','George Washington','Benjamin Franklin',3,'George Washington served as the 1st President from 1789 to 1797.',10),
(7,'In which year did World War II end?','multiple_choice','easy',NULL,'1943','1944','1945','1946',3,'World War II ended in 1945 with Germany surrendering in May and Japan in September.',10),
(7,'Which ancient wonder was located in Alexandria, Egypt?','multiple_choice','medium',NULL,'Colossus of Rhodes','Lighthouse of Alexandria','Temple of Artemis','Mausoleum at Halicarnassus',2,'The Lighthouse of Alexandria was one of the Seven Wonders of the Ancient World.',15),
(7,'Who was the Egyptian queen who had relationships with Julius Caesar and Mark Antony?','multiple_choice','easy',NULL,'Nefertiti','Isis','Cleopatra','Hatshepsut',3,'Cleopatra VII was the last pharaoh of ancient Egypt.',10),
(7,'The French Revolution began in which year?','multiple_choice','medium',NULL,'1776','1789','1800','1815',2,'The French Revolution began in 1789 with the storming of the Bastille.',15),
(7,'Who was Adolf Hitler''s political party?','multiple_choice','easy',NULL,'Communist Party','Liberal Party','Nazi Party','Socialist Party',3,'Hitler led the National Socialist German Workers'' Party (Nazi Party).',10),
(7,'The Berlin Wall fell in which year?','multiple_choice','easy',NULL,'1987','1988','1989','1991',3,'The Berlin Wall fell on November 9, 1989.',10),
(7,'Which empire was ruled by Genghis Khan?','multiple_choice','easy',NULL,'Ottoman Empire','Roman Empire','Mongol Empire','Byzantine Empire',3,'Genghis Khan founded and led the Mongol Empire, the largest contiguous empire in history.',10),
(7,'In which city was Archduke Franz Ferdinand assassinated, sparking WWI?','multiple_choice','medium',NULL,'Vienna','Belgrade','Sarajevo','Budapest',3,'The assassination took place in Sarajevo, Bosnia in 1914.',15),
(7,'What ship sank on its maiden voyage in 1912?','multiple_choice','easy',NULL,'Lusitania','Bismarck','Titanic','RMS Olympic',3,'The RMS Titanic sank on April 15, 1912 after hitting an iceberg.',10),
(7,'Martin Luther King Jr. gave his "I Have a Dream" speech in which year?','multiple_choice','medium',NULL,'1955','1960','1963','1968',3,'The speech was delivered on August 28, 1963 during the March on Washington.',15),
(7,'The ancient Great Wall of China was primarily built to defend against which group?','multiple_choice','medium',NULL,'Mongols','Persians','Japanese','Koreans',1,'The Great Wall was primarily built to protect China from Mongol invasions.',15),
(7,'Nelson Mandela became President of South Africa in which year?','multiple_choice','medium',NULL,'1990','1992','1994','1996',3,'Nelson Mandela was inaugurated as South Africa''s President on May 10, 1994.',15),
(7,'The atomic bomb was first used in warfare on which city?','multiple_choice','easy',NULL,'Tokyo','Hiroshima','Nagasaki','Osaka',2,'The first atomic bomb was dropped on Hiroshima on August 6, 1945.',10),
(7,'Who wrote the Magna Carta?','multiple_choice','hard',NULL,'King John','Thomas More','Simon de Montfort','The English Barons forced King John to sign it',4,'The Magna Carta was negotiated by rebel barons and signed by King John in 1215.',20);

-- ============================================================
-- SCIENCE (cat 8) — extends existing 10 questions
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(8,'What is the chemical formula for water?','easy','HO','H2O','H2O2','HO2',2,'Water is composed of 2 hydrogen atoms and 1 oxygen atom, hence H2O.',10),
(8,'What force keeps planets in orbit around the sun?','easy','Magnetism','Friction','Gravity','Nuclear force',3,'Gravity is the force that keeps planets in orbit around the sun.',10),
(8,'What is the most abundant gas in Earth''s atmosphere?','easy','Oxygen','Carbon Dioxide','Argon','Nitrogen',4,'Nitrogen makes up approximately 78% of Earth''s atmosphere.',10),
(8,'What is DNA an abbreviation for?','easy','Deoxyribonucleic Acid','Dynamic Nucleic Acid','Double Nucleic Array','Deoxyribose Nucleotide Acid',1,'DNA stands for Deoxyribonucleic Acid.',10),
(8,'How many elements are on the periodic table (as of 2024)?','medium','108','118','128','138',2,'There are 118 confirmed elements on the periodic table.',15),
(8,'Which scientist proposed the three laws of motion?','easy','Albert Einstein','Galileo Galilei','Isaac Newton','Nikola Tesla',3,'Isaac Newton''s three laws of motion form the foundation of classical mechanics.',10),
(8,'What particle carries a negative electric charge?','easy','Proton','Neutron','Electron','Positron',3,'Electrons carry a negative electric charge.',10),
(8,'The theory of evolution by natural selection was proposed by?','easy','Charles Darwin','Gregor Mendel','Louis Pasteur','Carl Linnaeus',1,'Charles Darwin published On the Origin of Species in 1859.',10),
(8,'What is the SI unit of electric current?','medium','Volt','Watt','Ampere','Ohm',3,'The SI unit of electric current is the Ampere (A).',15),
(8,'Which organ produces insulin in the human body?','medium','Liver','Kidney','Pancreas','Stomach',3,'The pancreas produces insulin to regulate blood sugar levels.',15),
(8,'Photosynthesis converts light energy into?','easy','Kinetic energy','Chemical energy','Thermal energy','Electrical energy',2,'Photosynthesis converts light energy into chemical energy stored in glucose.',10),
(8,'What is the hardest natural substance on Earth?','easy','Iron','Quartz','Diamond','Obsidian',3,'Diamond is the hardest natural substance, rating 10 on the Mohs scale.',10),
(8,'Which planet is known for its iconic ring system?','easy','Jupiter','Uranus','Neptune','Saturn',4,'Saturn has the most prominent ring system in our solar system.',10),
(8,'What is the unit of heredity?','medium','Cell','Chromosome','Gene','Protein',3,'A gene is the basic unit of heredity encoded in DNA.',15),
(8,'Sound travels fastest through which medium?','medium','Air','Water','Vacuum','Steel',4,'Sound travels fastest through solids like steel due to tightly packed particles.',15);

-- ============================================================
-- WORLD KNOWLEDGE (cat 9)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(9,'What is the most spoken language in the world by total speakers?','easy','Spanish','Hindi','English','Mandarin Chinese',4,'Mandarin Chinese has the most native speakers; English has the most total speakers.',10),
(9,'Which country has the largest population?','easy','India','USA','China','Indonesia',3,'China has the world''s largest population at over 1.4 billion people.',10),
(9,'What is the currency of Japan?','easy','Won','Yuan','Yen','Baht',3,'The currency of Japan is the Yen (¥).',10),
(9,'Which animal is the national symbol of Australia?','easy','Crocodile','Platypus','Koala','Kangaroo',4,'The kangaroo is Australia''s national symbol and appears on its coat of arms.',10),
(9,'How many continents are there on Earth?','easy','5','6','7','8',3,'There are 7 continents: Africa, Antarctica, Asia, Australia, Europe, North America, South America.',10),
(9,'What is the tallest mountain in the world?','easy','K2','Kangchenjunga','Lhotse','Mount Everest',4,'Mount Everest at 8,849m is the tallest mountain above sea level.',10),
(9,'In which country is the Eiffel Tower located?','easy','Italy','Germany','Spain','France',4,'The Eiffel Tower is in Paris, France, built in 1889.',10),
(9,'The Great Barrier Reef is located off the coast of which country?','easy','New Zealand','Fiji','Australia','Indonesia',3,'The Great Barrier Reef is off the northeast coast of Australia.',10),
(9,'Which is the longest river in Asia?','medium','Ganges','Indus','Mekong','Yangtze',4,'The Yangtze River in China is the longest river in Asia at 6,300 km.',15),
(9,'What is the official language of Brazil?','easy','Spanish','Portuguese','French','English',2,'Brazil was colonized by Portugal, so Portuguese is the official language.',10),
(9,'Which country has the most time zones?','hard','USA','Russia','China','France',4,'France has 12 time zones including overseas territories, more than any other country.',20),
(9,'The United Nations headquarters is in which city?','medium','Geneva','Washington D.C.','New York City','London',3,'The UN headquarters is located in New York City, USA.',15),
(9,'What percentage of Earth''s surface is covered by water?','medium','51%','61%','71%','81%',3,'Approximately 71% of Earth''s surface is covered by water.',15),
(9,'Which country is both a continent and a country?','easy','Greenland','New Zealand','Iceland','Australia',4,'Australia is uniquely both a continent and a country.',10),
(9,'What is the world''s smallest ocean?','medium','Indian','Southern','Arctic','Atlantic',3,'The Arctic Ocean is the smallest and shallowest of the world''s oceans.',15);

-- ============================================================
-- TECHNOLOGY (cat 10) — extends existing 10 questions
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(10,'What year was the first iPhone released?','easy','2005','2006','2007','2008',3,'Apple released the first iPhone on June 29, 2007.',10),
(10,'What does "URL" stand for?','easy','Universal Resource Locator','Uniform Resource Locator','Universal Reference Link','Unique Resource Location',2,'URL stands for Uniform Resource Locator.',10),
(10,'Which company developed the Java programming language?','medium','Microsoft','IBM','Sun Microsystems','Oracle',3,'Java was developed by Sun Microsystems in 1995, later acquired by Oracle.',15),
(10,'What does "Wi-Fi" stand for?','medium','Wireless Fidelity','Wide Frequency','Wireless Fiber','Wired Fidelity',1,'Wi-Fi stands for Wireless Fidelity.',15),
(10,'How many bits are in one byte?','easy','4','6','8','16',3,'One byte is made up of 8 bits.',10),
(10,'Which social media platform has a bird as its logo?','easy','Facebook','Instagram','Twitter/X','LinkedIn',3,'Twitter (now X) famously used a blue bird as its logo.',10),
(10,'Python is primarily what type of programming language?','easy','Compiled','Interpreted','Assembly','Machine code',2,'Python is an interpreted, high-level programming language.',10),
(10,'What does "SSD" stand for?','easy','Super Speed Drive','Solid State Drive','Static Storage Device','Secure Solid Disk',2,'SSD stands for Solid State Drive, which uses flash memory.',10),
(10,'Which company made the first commercially successful smartphone?','hard','Apple','Samsung','BlackBerry','Nokia',3,'BlackBerry popularized smartphones for business in the early 2000s.',20),
(10,'What does "HTTP" stand for?','easy','HyperText Transfer Protocol','High Tech Transfer Protocol','HyperText Type Protocol','High Transfer Text Protocol',1,'HTTP stands for HyperText Transfer Protocol.',10),
(10,'Blockchain technology was first implemented with which cryptocurrency?','medium','Ethereum','Litecoin','Ripple','Bitcoin',4,'Bitcoin was the first cryptocurrency to use blockchain technology, created in 2009.',15),
(10,'What type of device is a Raspberry Pi?','medium','Smartphone','Tablet','Single-board computer','Smart speaker',3,'Raspberry Pi is a small, affordable single-board computer.',15),
(10,'In programming, what does "API" stand for?','medium','Application Programming Interface','Advanced Programming Input','Applied Program Integration','Automated Program Interface',1,'API stands for Application Programming Interface.',15),
(10,'Who is the founder of Microsoft?','easy','Steve Jobs','Elon Musk','Bill Gates','Mark Zuckerberg',3,'Bill Gates co-founded Microsoft with Paul Allen in 1975.',10),
(10,'What is the most widely used operating system on servers?','hard','Windows Server','macOS','Linux','FreeBSD',3,'Linux powers the majority of the world''s web servers.',20);

-- ============================================================
-- CARS (cat 11)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(11,'Which company produces the 911 sports car?','easy','Ferrari','Porsche','Lamborghini','Aston Martin',2,'The Porsche 911 has been in production since 1963.',10),
(11,'What does "SUV" stand for?','easy','Sports Utility Vehicle','Super Urban Vehicle','Standard Utility Vehicle','Speed Utility Van',1,'SUV stands for Sports Utility Vehicle.',10),
(11,'Which country is Ferrari from?','easy','Germany','France','England','Italy',4,'Ferrari was founded in Maranello, Italy in 1939 by Enzo Ferrari.',10),
(11,'The Ford Mustang first appeared in which decade?','medium','1950s','1960s','1970s','1980s',2,'The Ford Mustang debuted on April 17, 1964.',15),
(11,'What does "RPM" stand for in cars?','easy','Rotations Per Minute','Revolutions Per Minute','Rapid Power Mode','Running Power Meter',2,'RPM stands for Revolutions Per Minute, measuring engine speed.',10),
(11,'Which car brand uses a prancing horse logo?','easy','Lamborghini','Porsche','Ferrari','Maserati',3,'Ferrari''s prancing horse (Cavallino Rampante) logo is iconic.',10),
(11,'What car manufacturer produces the Camry?','easy','Honda','Nissan','Toyota','Hyundai',3,'The Toyota Camry is one of the best-selling cars in the USA.',10),
(11,'Bugatti is owned by which conglomerate?','hard','BMW Group','Stellantis','Volkswagen Group','Renault Group',3,'Bugatti was part of the Volkswagen Group before being sold to Rimac in 2021.',20),
(11,'The Tesla Model S is powered by?','easy','Petrol','Diesel','Hybrid engine','Electric motor',4,'The Tesla Model S is a fully electric vehicle.',10),
(11,'Which car holds the record for fastest production car (top speed)?','hard','Bugatti Chiron','Hennessey Venom F5','Koenigsegg Jesko','SSC Tuatara',4,'The SSC Tuatara achieved a top speed of 282.9 mph in 2020.',20),
(11,'What is the purpose of a car radiator?','easy','Increase horsepower','Cool the engine','Filter air intake','Boost fuel efficiency',2,'The radiator cools the engine by dissipating heat from the coolant.',10),
(11,'Which German brand created the "Golf" model?','easy','BMW','Mercedes-Benz','Audi','Volkswagen',4,'The Volkswagen Golf is a German compact car launched in 1974.',10),
(11,'Formula 1 cars run on which type of fuel?','medium','Regular petrol','Aviation fuel','High-octane race fuel','Diesel',3,'F1 cars use specially blended high-octane fuel meeting FIA regulations.',15),
(11,'What is the purpose of ABS in a car?','medium','Automatically start the engine','Prevent wheel lockup during braking','Adjust brightness of lights','Aid in parking',2,'Anti-lock Braking System (ABS) prevents wheels from locking up during emergency braking.',15),
(11,'The McLaren F1 (1992) was groundbreaking because?','hard','First electric car','First hybrid','First car with central driving seat','First AWD sports car',3,'The McLaren F1 featured a central driving position with passenger seats on each side.',20);

-- ============================================================
-- GEOGRAPHY (cat 12) — extends existing 10 questions
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(12,'What is the capital of Brazil?','easy','São Paulo','Rio de Janeiro','Brasília','Salvador',3,'Brasília became Brazil''s capital in 1960, replacing Rio de Janeiro.',10),
(12,'Which desert is the largest hot desert in the world?','easy','Arabian Desert','Kalahari','Gobi','Sahara',4,'The Sahara Desert in Africa is the world''s largest hot desert.',10),
(12,'The Amazon rainforest is primarily in which country?','easy','Colombia','Venezuela','Peru','Brazil',4,'About 60% of the Amazon rainforest lies within Brazil.',10),
(12,'Which country has the longest coastline in the world?','medium','Russia','Australia','Norway','Canada',4,'Canada has the longest coastline in the world at over 202,000 km.',15),
(12,'The Nile River flows into which body of water?','easy','Mediterranean Sea','Red Sea','Indian Ocean','Persian Gulf',1,'The Nile flows northward and empties into the Mediterranean Sea.',10),
(12,'What is the capital of Canada?','easy','Toronto','Vancouver','Montreal','Ottawa',4,'Ottawa is the capital of Canada, not Toronto which is the largest city.',10),
(12,'Which European country has the most UNESCO World Heritage Sites?','hard','France','Germany','Spain','Italy',4,'Italy has the most UNESCO World Heritage Sites with 58.',20),
(12,'The Himalayas span across how many countries?','hard','3','4','5','6',3,'The Himalayas span across Nepal, India, Bhutan, China, and Pakistan — 5 countries.',20),
(12,'Lake Baikal in Russia is the world''s:','medium','Largest lake','Deepest lake','Coldest lake','Saltiest lake',2,'Lake Baikal is the world''s deepest lake at 1,642m.',15),
(12,'Which two continents does the country of Russia span?','easy','Asia and Africa','Europe and Asia','North America and Asia','Europe and North America',2,'Russia spans both Europe and Asia, making it the world''s largest country.',10),
(12,'What is the tallest volcano in the world?','hard','Mount Etna','Kilimanjaro','Mauna Kea','Ojos del Salado',4,'Ojos del Salado on the Chile-Argentina border is the world''s highest active volcano.',20),
(12,'The Grand Canyon is located in which US state?','easy','Nevada','Colorado','Utah','Arizona',4,'The Grand Canyon is in Arizona, carved by the Colorado River.',10),
(12,'Which is the smallest continent by land area?','easy','Europe','Antarctica','Australia','South America',3,'Australia is the smallest continent.',10),
(12,'Which river runs through London?','easy','Severn','Rhine','Seine','Thames',4,'The River Thames runs through London.',10),
(12,'Istanbul is the largest city in which country?','easy','Greece','Bulgaria','Armenia','Turkey',4,'Istanbul is Turkey''s largest city, straddling Europe and Asia.',10);

-- ============================================================
-- SPACE (cat 13) — extends existing 10 questions
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(13,'What is a black hole?','easy','A dead star','A region where gravity is so strong nothing escapes','An empty area of space','A type of nebula',2,'A black hole is a region where gravity is so strong that not even light can escape.',10),
(13,'The International Space Station orbits Earth at approximately what altitude?','medium','200 km','400 km','800 km','1000 km',2,'The ISS orbits at approximately 400 km above Earth.',15),
(13,'Which planet rotates on its side (axial tilt ~98°)?','medium','Neptune','Saturn','Uranus','Venus',3,'Uranus has an extreme axial tilt of 97.77°, causing it to rotate on its side.',15),
(13,'What causes the Northern Lights?','medium','Solar wind interacting with Earth''s magnetic field','Meteor showers','Volcanic activity in the Arctic','Reflected moonlight',1,'The Northern Lights (Aurora Borealis) are caused by solar particles interacting with Earth''s magnetosphere.',15),
(13,'How many moons does Mars have?','easy','0','1','2','4',3,'Mars has 2 moons: Phobos and Deimos.',10),
(13,'What is the Milky Way?','easy','A solar system','A star cluster','A galaxy','A nebula',3,'The Milky Way is the spiral galaxy that contains our solar system.',10),
(13,'The Voyager 1 spacecraft, launched in 1977, is now in?','hard','The Asteroid Belt','The Kuiper Belt','Interstellar space','The Oort Cloud',3,'Voyager 1 entered interstellar space in 2012, becoming the most distant human-made object.',20),
(13,'What is the name of the force believed to be accelerating the expansion of the universe?','hard','Dark Matter','Dark Energy','Antimatter','Quantum Gravity',2,'Dark Energy is theorized to be driving the accelerating expansion of the universe.',20),
(13,'Which planet is closest in size to Earth?','easy','Mars','Mercury','Venus','Saturn',3,'Venus is almost the same size as Earth — 95% of Earth''s diameter.',10),
(13,'What does NASA stand for?','easy','National Aerospace and Space Authority','National Aeronautics and Space Administration','North American Space Agency','National Astronomy and Space Association',2,'NASA stands for National Aeronautics and Space Administration.',10),
(13,'Which celestial body causes tides on Earth?','easy','The Sun','Other planets','The Moon','Jupiter',3,'The Moon''s gravitational pull primarily causes Earth''s ocean tides.',10),
(13,'The Hubble Space Telescope was launched in which year?','medium','1985','1988','1990','1993',3,'The Hubble Space Telescope was launched on April 24, 1990.',15),
(13,'What is a supernova?','medium','A new star being born','An exploding star at end of life','A type of black hole','A comet',2,'A supernova is a powerful stellar explosion marking the end of a star''s life.',15),
(13,'An astronomical unit (AU) is the average distance between?','medium','Earth and the Moon','The Sun and Pluto','Earth and Mars','Earth and the Sun',4,'One AU equals approximately 150 million kilometres (Earth-Sun distance).',15),
(13,'Which space mission first put humans on the Moon?','easy','Apollo 10','Apollo 11','Apollo 12','Gemini 4',2,'Apollo 11 (1969) was the first crewed mission to land on the Moon.',10);

-- ============================================================
-- INTERNET CULTURE (cat 14)
-- ============================================================
INSERT INTO questions (category_id,question_text,question_type,difficulty,option1,option2,option3,option4,correct_option,explanation,points) VALUES
(14,'What does "LOL" mean in internet slang?','easy','Lots of Love','Laugh Out Loud','Loads of Luck','Level of Life',2,'LOL stands for Laugh Out Loud.',10),
(14,'The "Rickroll" prank involves being linked to a music video by which artist?','easy','Michael Jackson','Carly Rae Jepsen','Rick Astley','Justin Bieber',3,'The Rickroll links to Rick Astley''s "Never Gonna Give You Up" (1987).',10),
(14,'What year did Facebook launch to the public?','medium','2003','2004','2005','2006',4,'Facebook opened to the general public in September 2006 (launched at Harvard in 2004).',15),
(14,'Which meme features a distracted boyfriend turning to look at another woman?','easy','Drake meme','Disaster Girl','Distracted Boyfriend','Woman Yelling at Cat',3,'The Distracted Boyfriend meme shows a man ignoring his girlfriend for another woman.',10),
(14,'What does "GOAT" stand for in internet culture?','easy','Greatest Of All Time','Get On A Train','Go Out And Try','Good Objective Achievement Target',1,'GOAT stands for Greatest Of All Time.',10),
(14,'Which platform introduced the concept of "Stories" that disappear after 24 hours?','medium','Facebook','Twitter','Snapchat','Instagram',3,'Snapchat pioneered the 24-hour Story format in 2013.',15),
(14,'What is "Spam" in the context of the internet?','easy','A type of computer virus','Unwanted bulk messages','A coding language','A type of cookie',2,'Spam refers to unsolicited and unwanted messages sent in bulk.',10),
(14,'The "Ice Bucket Challenge" viral trend raised money for which disease?','easy','Parkinson''s Disease','Multiple Sclerosis','Cancer','ALS (Amyotrophic Lateral Sclerosis)',4,'The ALS Ice Bucket Challenge went viral in 2014.',10),
(14,'What does "TBT" mean on social media?','easy','True Born Talent','Throwback Thursday','Take Back Time','Two By Two',2,'TBT stands for Throwback Thursday — sharing old photos.',10),
(14,'Who is the most subscribed individual YouTuber of all time?','medium','MrBeast','PewDiePie','T-Series','Dude Perfect',1,'MrBeast surpassed PewDiePie to become the most subscribed individual YouTuber.',15),
(14,'Which app is known for its short-form vertical videos with a powerful algorithm?','easy','Instagram','Snapchat','TikTok','YouTube Shorts',3,'TikTok is known for its powerful recommendation algorithm and short vertical videos.',10),
(14,'"404 Error" means what on a website?','easy','Server is down','Page not found','Connection timeout','Forbidden access',2,'HTTP 404 is the status code for "Not Found" when a page doesn''t exist.',10),
(14,'Which programming concept is behind the "@" symbol in email addresses?','medium','Protocol separator','Domain separator','Username identifier','Server flag',2,'The "@" symbol separates the username from the domain in an email address.',15),
(14,'The short video app "Vine" was shut down in which year?','hard','2014','2015','2016','2017',3,'Twitter shut down Vine in January 2016 to cut costs.',20),
(14,'What does "GIF" formally stand for?','easy','Graphical Image Format','Graphics Interchange Format','Global Image File','Generated Image Format',2,'GIF stands for Graphics Interchange Format, invented by CompuServe in 1987.',10);

-- ============================================================
-- UPDATE QUESTION COUNTS
-- ============================================================
UPDATE categories c SET question_count = (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id AND q.is_active = 1);
