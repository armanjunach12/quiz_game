<?php
// ajax/question.php — Get next question data for dynamic loading
require_once '../includes/functions.php';
startSecureSession();

header('Content-Type: application/json');

if (!isLoggedIn()) { echo json_encode(['error' => 'Not logged in']); exit(); }

$sessionId = (int)($_GET['session_id'] ?? 0);
$session   = getGameSession($sessionId, $_SESSION['user_id']);

if (!$session) { echo json_encode(['error' => 'Invalid session']); exit(); }

$question = getSessionQuestion($session);
if (!$question) { echo json_encode(['done' => true]); exit(); }

$questionIds  = json_decode($session['question_ids'], true);
$total        = count($questionIds);
$mode         = $session['game_mode'];
$timePerQ     = ($mode === 'time_attack') ? 60 : (($mode === 'survival') ? 20 : 30);

echo json_encode([
    'question'      => $question,
    'index'         => $session['current_index'],
    'total'         => $total,
    'timer_seconds' => $timePerQ,
    'lives'         => $session['lives'],
    'score'         => $session['score'],
]);
