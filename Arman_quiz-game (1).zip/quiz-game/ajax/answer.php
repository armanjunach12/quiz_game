<?php
// ajax/answer.php — Handles answer submission via AJAX
require_once '../includes/functions.php';
startSecureSession();

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

$body      = json_decode(file_get_contents('php://input'), true);
$sessionId = (int)($body['session_id'] ?? 0);
$option    = (int)($body['option'] ?? 0);
$isTimeout = (bool)($body['timeout'] ?? false);

if ($isTimeout) {
    // Treat as wrong answer (option 0 = none)
    $result = submitAnswer($sessionId, $_SESSION['user_id'], 0);
} else {
    if ($option < 1 || $option > 4) {
        echo json_encode(['error' => 'Invalid option']);
        exit();
    }
    $result = submitAnswer($sessionId, $_SESSION['user_id'], $option);
}

echo json_encode($result);
