<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>QuizVerse Diagnostic</title>
<style>
  body  { background:#060a18; color:#e8f4fd; font-family:sans-serif; padding:2rem; }
  h1   { color:#00f5ff; }
  h3   { color:#ffd700; margin-top:2rem; }
  .ok  { color:#00ff88; }
  .err { color:#ff00aa; background:rgba(255,0,170,0.1); padding:8px 14px; border-radius:6px; }
  .warn{ color:#ffd700; }
  code { background:rgba(255,255,255,0.06); padding:3px 8px; border-radius:4px; }
  a    { color:#00f5ff; }
  hr   { border-color:rgba(255,255,255,0.08); margin:2rem 0; }
</style>
</head>
<body>
<h1>🔧 QuizVerse Diagnostic</h1>

<h3>PHP Version</h3>
<?php
$ver = phpversion();
echo "<p class='ok'>✅ PHP $ver</p>";
if (version_compare($ver, '7.4', '<')) {
    echo "<p class='err'>⚠️ PHP 7.4+ recommended. You have $ver</p>";
}
?>

<h3>Step 1 — Loading db.php</h3>
<?php
try {
    require_once __DIR__ . '/includes/db.php';
    echo "<p class='ok'>✅ db.php loaded — BASE = <code>" . BASE . "</code></p>";
} catch (Throwable $e) {
    echo "<p class='err'>❌ db.php failed: " . $e->getMessage() . "</p>";
    die("</body></html>");
}
?>

<h3>Step 2 — MySQL Connection</h3>
<?php
try {
    // Try connecting without a specific DB first
    $testPdo = new PDO("mysql:host=localhost;charset=utf8mb4", DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    echo "<p class='ok'>✅ MySQL is running and accepting connections</p>";
} catch (Throwable $e) {
    echo "<p class='err'>❌ Cannot connect to MySQL: " . $e->getMessage() . "</p>";
    echo "<p class='warn'>👉 Open XAMPP Control Panel → Click <b>Start</b> next to <b>MySQL</b></p>";
    die("</body></html>");
}
?>

<h3>Step 3 — Database Exists</h3>
<?php
try {
    $testPdo->exec("USE " . DB_NAME);
    echo "<p class='ok'>✅ Database '" . DB_NAME . "' exists</p>";
} catch (Throwable $e) {
    echo "<p class='err'>❌ Database '" . DB_NAME . "' does not exist</p>";
    echo "<p class='warn'>👉 <a href='setup.php'>Click here to run setup.php</a> — it will create the database automatically</p>";
    die("</body></html>");
}
?>

<h3>Step 4 — Database Tables</h3>
<?php
$tables = ['users','categories','questions','scores','achievements','game_sessions','user_achievements'];
$allOk  = true;
foreach ($tables as $t) {
    try {
        $testPdo->query("SELECT 1 FROM $t LIMIT 1");
        echo "<p class='ok'>✅ Table <code>$t</code></p>";
    } catch (Throwable $e) {
        echo "<p class='err'>❌ Table <code>$t</code> is missing</p>";
        $allOk = false;
    }
}
if (!$allOk) {
    echo "<p class='warn'>👉 <a href='setup.php'>Run setup.php</a> to create all tables</p>";
}
?>

<h3>Step 5 — functions.php</h3>
<?php
try {
    require_once __DIR__ . '/includes/functions.php';
    echo "<p class='ok'>✅ functions.php loaded</p>";
} catch (Throwable $e) {
    echo "<p class='err'>❌ functions.php error: " . $e->getMessage() . "</p>";
    die("</body></html>");
}
?>

<h3>Step 6 — Categories in DB</h3>
<?php
try {
    $cats = getCategories();
    if (count($cats) > 0) {
        echo "<p class='ok'>✅ Found " . count($cats) . " categories</p>";
    } else {
        echo "<p class='warn'>⚠️ No categories found — <a href='setup.php'>run setup.php</a></p>";
    }
} catch (Throwable $e) {
    echo "<p class='err'>❌ " . $e->getMessage() . "</p>";
}
?>

<h3>Step 7 — Asset Files</h3>
<?php
$files = [
    'assets/css/style.css' => 'CSS stylesheet',
    'assets/js/main.js'    => 'JavaScript file',
    'admin/admin_dashboard.php' => 'Admin dashboard',
    'ajax/answer.php'      => 'AJAX answer handler',
    'ajax/question.php'    => 'AJAX question loader',
];
foreach ($files as $rel => $label) {
    $full = __DIR__ . '/' . $rel;
    if (file_exists($full)) {
        echo "<p class='ok'>✅ $label found</p>";
    } else {
        echo "<p class='err'>❌ $label NOT found at: <code>$full</code></p>";
    }
}
?>

<h3>Step 8 — Uploads Directory Writable</h3>
<?php
$uploadDirs = ['assets/uploads/images', 'assets/uploads/audio', 'assets/uploads/video'];
foreach ($uploadDirs as $dir) {
    $full = __DIR__ . '/' . $dir;
    if (!is_dir($full)) {
        mkdir($full, 0755, true);
    }
    if (is_writable($full)) {
        echo "<p class='ok'>✅ <code>$dir</code> is writable</p>";
    } else {
        echo "<p class='err'>❌ <code>$dir</code> is NOT writable — check folder permissions</p>";
    }
}
?>

<hr>
<h2 class='ok'>✅ Diagnostic Complete</h2>
<p>If everything above is green:</p>
<p>
  <a href='index.php' style='display:inline-block;padding:12px 28px;background:linear-gradient(135deg,#00f5ff,#0080ff);color:#000;border-radius:8px;font-weight:700;text-decoration:none;'>
    → Go to Homepage
  </a>
  &nbsp;&nbsp;
  <a href='login.php' style='display:inline-block;padding:12px 28px;border:1px solid #00f5ff;color:#00f5ff;border-radius:8px;font-weight:700;text-decoration:none;'>
    → Login Page
  </a>
</p>
<p style='color:#6b8aad;margin-top:1rem;font-size:0.85rem'>Delete test.php and hi.php when done.</p>
</body>
</html>
