<?php
// quiz.php — The actual quiz game screen
require_once 'includes/functions.php';
startSecureSession();
requireLogin();

$sessionId = (int)($_GET['session'] ?? 0);
$session   = getGameSession($sessionId, $_SESSION['user_id']);

if (!$session) {
    redirect(BASE.'/index.php?error=invalid_session');
}

$question = getSessionQuestion($session);
if (!$question) {
    redirect(BASE.'/result.php?session=' . $sessionId);
}

$category     = getCategoryById($session['category_id']);
$questionIds  = json_decode($session['question_ids'], true);
$total        = count($questionIds);
$currentIndex = $session['current_index'];
$progressPct  = $total > 0 ? round(($currentIndex / $total) * 100) : 0;
$mode         = $session['game_mode'];
$timeLimit    = ($mode === 'time_attack') ? 60 : (($mode === 'survival') ? 20 : (($mode === 'quick') ? 30 : 25));

$difficultyColors = ['easy' => 'var(--neon-green)', 'medium' => 'var(--neon-gold)', 'hard' => 'var(--neon-pink)'];
$diffColor = $difficultyColors[$question['difficulty']] ?? 'var(--neon-cyan)';

$typeLabels = [
    'multiple_choice' => ['label' => 'Multiple Choice', 'color' => 'var(--neon-cyan)'],
    'true_false'      => ['label' => 'True / False',    'color' => 'var(--neon-gold)'],
    'image_guess'     => ['label' => 'Image Guess',     'color' => 'var(--neon-purple)'],
    'audio_guess'     => ['label' => 'Audio Guess',     'color' => 'var(--neon-pink)'],
    'video_scene'     => ['label' => 'Video Scene',     'color' => 'var(--neon-green)'],
];
$typeInfo = $typeLabels[$question['question_type']] ?? $typeLabels['multiple_choice'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= h($category['name']) ?> Quiz — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body class="theme-<?= $category['slug'] ?>">
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>

  <!-- Navbar -->
  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span></a>
    <div class="nav-user" style="gap:1.5rem">
      <!-- Category -->
      <span style="display:flex;align-items:center;gap:0.5rem;font-weight:700">
        <?= $category['icon'] ?> <?= h($category['name']) ?>
      </span>
      <!-- Mode badge -->
      <span style="padding:4px 14px;border-radius:20px;font-size:0.8rem;font-weight:700;font-family:'Orbitron',monospace;
                   background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.15)">
        <?= strtoupper(str_replace('_',' ', $mode)) ?>
      </span>
      <!-- Live Score -->
      <span class="score-badge">⭐ <span id="live-score"><?= $session['score'] ?></span></span>
      <!-- Lives for survival -->
      <?php if ($mode === 'survival'): ?>
      <div class="lives-display">
        <?php for ($i = 0; $i < 3; $i++): ?>
          <span class="life-icon <?= $i >= $session['lives'] ? 'lost' : '' ?>">❤️</span>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    </div>
  </nav>

  <!-- Quiz Container -->
  <div class="quiz-container">

    <!-- Progress Bar -->
    <div class="progress-container">
      <div class="progress-label">
        <span id="q-number">Q<?= $currentIndex + 1 ?> / <?= $total ?></span>
        <span><?= $progressPct ?>% Complete</span>
      </div>
      <div class="progress-bar-outer">
        <div class="progress-bar-inner" id="progress-bar" style="width:<?= $progressPct ?>%"></div>
      </div>
    </div>

    <!-- Quiz Header (timer + info) -->
    <div class="quiz-header">
      <div class="quiz-info">
        <!-- Difficulty badge -->
        <span style="padding:6px 16px;border-radius:20px;font-family:'Orbitron',monospace;font-size:0.7rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;border:1px solid <?= $diffColor ?>;color:<?= $diffColor ?>">
          <?= strtoupper($question['difficulty']) ?>
        </span>
        <!-- Points -->
        <span class="mono" style="color:var(--neon-gold);font-size:0.95rem">+<?= $question['points'] ?> pts</span>
      </div>

      <!-- Timer Circle -->
      <div class="timer-circle">
        <svg class="timer-svg" viewBox="0 0 80 80" width="80" height="80">
          <circle class="timer-track" cx="40" cy="40" r="32"/>
          <circle class="timer-fill" cx="40" cy="40" r="32"/>
        </svg>
        <div class="timer-text"><?= $timeLimit ?></div>
      </div>
    </div>

    <!-- Question Card -->
    <div class="question-card">
      <!-- Question type badge -->
      <span class="question-type-badge" style="color:<?= $typeInfo['color'] ?>;border-color:<?= $typeInfo['color'] ?>;background:<?= $typeInfo['color'] ?>15">
        <?= $typeInfo['label'] ?>
      </span>

      <!-- Question Text -->
      <div class="question-text" id="q-text">
        <?= h($question['question_text']) ?>
      </div>

      <!-- Media -->
      <div class="question-media" id="q-media">
        <?php if ($question['image_path']): ?>
          <img src="<?= h($question['image_path']) ?>" alt="Question image" loading="lazy">
        <?php elseif ($question['audio_path']): ?>
          <audio controls src="<?= h($question['audio_path']) ?>" style="width:100%;margin:10px 0">
            Your browser does not support audio.
          </audio>
        <?php elseif ($question['video_path']): ?>
          <?php
            $vp = $question['video_path'];
            $isYT = strpos($vp,'youtube.com') !== false || strpos($vp,'youtu.be') !== false;
          ?>
          <?php if ($isYT): ?>
            <iframe width="100%" height="240"
              src="<?= h($vp) ?>?autoplay=0"
              frameborder="0" allowfullscreen
              style="border-radius:12px;display:block"></iframe>
          <?php else: ?>
            <video controls src="<?= h($vp) ?>" style="width:100%;max-height:280px;border-radius:12px"></video>
          <?php endif; ?>
        <?php endif; ?>
      </div>

      <!-- Options -->
      <div class="options-grid" id="q-options">
        <?php
        $opts    = [$question['option1'], $question['option2'], $question['option3'], $question['option4']];
        $letters = ['A','B','C','D'];
        foreach ($opts as $i => $opt):
            if (!$opt) continue;
        ?>
        <button class="option-btn" data-option="<?= $i+1 ?>"
                onclick="QuizGame.answer(this, <?= $i+1 ?>)">
          <span class="option-letter"><?= $letters[$i] ?></span>
          <span><?= h($opt) ?></span>
        </button>
        <?php endforeach; ?>
      </div>
    </div>

  </div><!-- end quiz-container -->

  <!-- Music player built by JS -->
  <script>
    // Apply category theme
    document.body.classList.add('theme-<?= $category["slug"] ?>');
  </script>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
  <script>
    QuizGame.init(<?= $sessionId ?>, <?= $total ?>, <?= $timeLimit ?>);
  </script>
</body>
</html>
