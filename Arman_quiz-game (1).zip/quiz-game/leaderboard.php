<?php
// leaderboard.php
require_once 'includes/functions.php';
startSecureSession();

$categories = getCategories();
$categoryId = (int)($_GET['category'] ?? 0);
$leaders    = getLeaderboard(50, $categoryId ?: null);
$user       = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Leaderboard — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>
  <canvas id="particles-canvas"></canvas>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span></a>
    <ul class="nav-links">
      <li><a href="<?=BASE?>/index.php">Home</a></li>
      <?php if ($user): ?>
        <li><a href="<?=BASE?>/dashboard.php">Dashboard</a></li>
      <?php endif; ?>
    </ul>
    <div class="nav-user">
      <?php if ($user): ?>
        <span class="score-badge">⭐ <?= number_format($user['total_score']) ?></span>
      <?php else: ?>
        <a href="<?=BASE?>/login.php" class="btn btn-primary btn-sm">Login</a>
      <?php endif; ?>
    </div>
  </nav>

  <div style="min-height:100vh;padding:100px 2rem 4rem;position:relative;z-index:1">

    <div class="section-header" style="margin-bottom:3rem">
      <h1 class="section-title glow-gold">🏆 Leaderboard</h1>
      <p class="section-sub">The greatest minds on QuizVerse</p>
    </div>

    <!-- Category Filter -->
    <div style="display:flex;gap:0.75rem;flex-wrap:wrap;justify-content:center;margin-bottom:3rem">
      <a href="<?=BASE?>/leaderboard.php"
         class="diff-btn <?= !$categoryId ? 'selected' : '' ?>"
         style="color:var(--neon-cyan);border-color:var(--neon-cyan);<?= !$categoryId ? 'background:var(--neon-cyan);color:#000' : '' ?>">
        All Categories
      </a>
      <?php foreach ($categories as $cat): ?>
      <a href="<?=BASE?>/leaderboard.php?category=<?= $cat['id'] ?>"
         class="diff-btn <?= $categoryId === (int)$cat['id'] ? 'selected' : '' ?>"
         style="color:<?= h($cat['color']) ?>;border-color:<?= h($cat['color']) ?>;
                <?= $categoryId === (int)$cat['id'] ? "background:{$cat['color']};color:#000" : '' ?>">
        <?= $cat['icon'] ?> <?= h($cat['name']) ?>
      </a>
      <?php endforeach; ?>
    </div>

    <!-- Top 3 Podium -->
    <?php if (count($leaders) >= 3): ?>
    <div style="display:flex;align-items:flex-end;justify-content:center;gap:1.5rem;margin-bottom:3rem">
      <!-- 2nd Place -->
      <div style="text-align:center;flex:0 0 180px">
        <div class="player-avatar" style="width:60px;height:60px;margin:0 auto 0.75rem;font-family:'Orbitron',monospace;font-size:1.5rem">
          <?= strtoupper(substr($leaders[1]['username'], 0, 1)) ?>
        </div>
        <div style="font-weight:700;margin-bottom:0.25rem"><?= h($leaders[1]['username']) ?></div>
        <div style="font-family:'Orbitron',monospace;font-size:1.2rem;color:#c0c0c0"><?= number_format($leaders[1]['total_score'] ?? $leaders[1]['total']) ?></div>
        <div style="background:linear-gradient(135deg,#c0c0c0,#808080);height:80px;border-radius:8px 8px 0 0;margin-top:1rem;display:flex;align-items:center;justify-content:center;font-family:'Orbitron',monospace;font-size:1.5rem;font-weight:900;color:#000">2</div>
      </div>
      <!-- 1st Place -->
      <div style="text-align:center;flex:0 0 200px">
        <div style="font-size:2rem;margin-bottom:0.5rem">👑</div>
        <div class="player-avatar" style="width:70px;height:70px;margin:0 auto 0.75rem;font-family:'Orbitron',monospace;font-size:1.8rem;background:linear-gradient(135deg,var(--neon-gold),#ff8c00)">
          <?= strtoupper(substr($leaders[0]['username'], 0, 1)) ?>
        </div>
        <div style="font-weight:700;margin-bottom:0.25rem;font-size:1.1rem"><?= h($leaders[0]['username']) ?></div>
        <div style="font-family:'Orbitron',monospace;font-size:1.5rem;color:var(--neon-gold);text-shadow:0 0 15px var(--neon-gold)"><?= number_format($leaders[0]['total_score'] ?? $leaders[0]['total']) ?></div>
        <div style="background:linear-gradient(135deg,#ffd700,#ff8c00);height:110px;border-radius:8px 8px 0 0;margin-top:1rem;display:flex;align-items:center;justify-content:center;font-family:'Orbitron',monospace;font-size:2rem;font-weight:900;color:#000;box-shadow:0 0 30px rgba(255,215,0,0.5)">1</div>
      </div>
      <!-- 3rd Place -->
      <div style="text-align:center;flex:0 0 180px">
        <div class="player-avatar" style="width:60px;height:60px;margin:0 auto 0.75rem;font-family:'Orbitron',monospace;font-size:1.5rem">
          <?= strtoupper(substr($leaders[2]['username'], 0, 1)) ?>
        </div>
        <div style="font-weight:700;margin-bottom:0.25rem"><?= h($leaders[2]['username']) ?></div>
        <div style="font-family:'Orbitron',monospace;font-size:1.2rem;color:#cd7f32"><?= number_format($leaders[2]['total_score'] ?? $leaders[2]['total']) ?></div>
        <div style="background:linear-gradient(135deg,#cd7f32,#8b4513);height:60px;border-radius:8px 8px 0 0;margin-top:1rem;display:flex;align-items:center;justify-content:center;font-family:'Orbitron',monospace;font-size:1.5rem;font-weight:900;color:#fff">3</div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Full Table -->
    <?php if (!empty($leaders)): ?>
    <div style="max-width:900px;margin:0 auto">
      <table class="leaderboard-table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Player</th>
            <th><?= $categoryId ? 'Category Score' : 'Total Score' ?></th>
            <th><?= $categoryId ? 'Games' : 'Quizzes' ?></th>
            <?php if (!$categoryId): ?><th>Accuracy</th><?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($leaders as $i => $leader): ?>
          <tr <?= ($user && $leader['username'] === $user['username']) ? 'style="background:rgba(0,245,255,0.05)"' : '' ?>>
            <td>
              <div class="rank-badge rank-<?= $i < 3 ? $i+1 : 'other' ?>">
                <?= $i+1 ?>
              </div>
            </td>
            <td>
              <div style="display:flex;align-items:center;gap:0.75rem">
                <div class="player-avatar" style="width:36px;height:36px;font-size:1rem">
                  <?= strtoupper(substr($leader['username'], 0, 1)) ?>
                </div>
                <span style="font-weight:700"><?= h($leader['username']) ?></span>
                <?php if ($user && $leader['username'] === $user['username']): ?>
                  <span style="font-size:0.7rem;padding:2px 8px;border-radius:10px;background:rgba(0,245,255,0.15);color:var(--neon-cyan);font-weight:700">YOU</span>
                <?php endif; ?>
              </div>
            </td>
            <td style="font-family:'Orbitron',monospace;color:var(--neon-gold);font-weight:700">
              <?= number_format($leader['total_score'] ?? $leader['total']) ?>
            </td>
            <td style="color:var(--text-dim)"><?= $leader['quizzes_played'] ?? $leader['games'] ?? '-' ?></td>
            <?php if (!$categoryId): ?>
            <td>
              <span style="color:<?= ($leader['accuracy'] ?? 0) >= 75 ? 'var(--neon-green)' : (($leader['accuracy'] ?? 0) >= 50 ? 'var(--neon-gold)' : 'var(--neon-pink)') ?>">
                <?= $leader['accuracy'] ?? 0 ?>%
              </span>
            </td>
            <?php endif; ?>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:4rem;color:var(--text-dim)">
      <div style="font-size:3rem;margin-bottom:1rem">🏆</div>
      <p>No scores yet. Be the first to play!</p>
      <a href="<?=BASE?>/index.php#categories" class="btn btn-primary" style="margin-top:1.5rem">Play Now</a>
    </div>
    <?php endif; ?>

  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
