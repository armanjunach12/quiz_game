<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// index.php - Homepage
require_once 'includes/functions.php';
startSecureSession();
$categories = getCategories();
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ultimate Multimedia Quiz Game</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
  <style>
    /* Per-category card colors injected via PHP */
    <?php foreach ($categories as $i => $cat): ?>
    .category-card[data-id="<?= $cat['id'] ?>"] {
      --card-gradient: linear-gradient(135deg, <?= h($cat['color']) ?>, <?= h($cat['color2']) ?>);
      --card-glow: 0 0 40px <?= h($cat['color']) ?>33;
      --card-glow-small: 0 0 10px <?= h($cat['color']) ?>;
    }
    <?php endforeach; ?>
  </style>
</head>
<body>
  <!-- Animated Background -->
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>
  <canvas id="particles-canvas"></canvas>

  <!-- Navbar -->
  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span></a>
    <ul class="nav-links">
      <li><a href="#categories">Categories</a></li>
      <li><a href="#modes">Game Modes</a></li>
      <li><a href="<?=BASE?>/leaderboard.php">Leaderboard</a></li>
      <?php if ($user && $user['is_admin']): ?>
      <li><a href="<?=BASE?>/admin/admin_dashboard.php">Admin</a></li>
      <?php endif; ?>
    </ul>
    <div class="nav-user">
      <?php if ($user): ?>
        <span class="score-badge">⭐ <?= number_format($user['total_score']) ?></span>
        <a href="<?=BASE?>/dashboard.php" class="btn btn-ghost btn-sm"><?= h($user['username']) ?></a>
        <a href="<?=BASE?>/logout.php" class="btn btn-sm" style="color:var(--neon-pink);border:1px solid var(--neon-pink);background:transparent">Logout</a>
      <?php else: ?>
        <a href="<?=BASE?>/login.php" class="btn btn-ghost btn-sm">Login</a>
        <a href="<?=BASE?>/register.php" class="btn btn-primary btn-sm">Register</a>
      <?php endif; ?>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="hero">
    <span class="hero-badge">🎮 The Ultimate Quiz Experience</span>
    <h1 class="hero-title">
      <span class="line1">CHALLENGE YOUR</span>
      <span class="line2">KNOWLEDGE</span>
    </h1>
    <p class="hero-subtitle">
      14 categories · 4 game modes · Real-time scoring · Achievements &amp; leaderboards
    </p>
    <div class="hero-cta">
      <?php if ($user): ?>
        <a href="#categories" class="btn btn-primary btn-lg btn-start">▶ Start Quiz</a>
        <a href="<?=BASE?>/dashboard.php" class="btn btn-ghost btn-lg">My Dashboard</a>
      <?php else: ?>
        <a href="<?=BASE?>/register.php" class="btn btn-primary btn-lg btn-start">▶ Play Now — Free</a>
        <a href="<?=BASE?>/login.php" class="btn btn-ghost btn-lg">Login</a>
      <?php endif; ?>
    </div>

    <!-- Stats bar -->
    <div class="stats-bar">
      <div class="stat-item">
        <span class="stat-number glow-cyan" data-count="<?= array_sum(array_column($categories, 'question_count')) ?>">0</span>
        <span class="stat-label">Questions</span>
      </div>
      <div class="stat-item">
        <span class="stat-number glow-pink" data-count="<?= count($categories) ?>">0</span>
        <span class="stat-label">Categories</span>
      </div>
      <div class="stat-item">
        <span class="stat-number glow-gold" data-count="4">0</span>
        <span class="stat-label">Game Modes</span>
      </div>
      <div class="stat-item">
        <span class="stat-number glow-green" data-count="10">0</span>
        <span class="stat-label">Achievements</span>
      </div>
    </div>
  </section>

  <hr class="neon-divider">

  <!-- Game Modes -->
  <section class="section" id="modes">
    <div class="section-header">
      <h2 class="section-title glow-cyan">Game Modes</h2>
      <p class="section-sub">Choose your challenge — every mode is a different experience</p>
    </div>
    <div class="modes-grid">
      <div class="mode-card" style="--mode-color: var(--neon-cyan)" data-mode="quick">
        <span class="mode-badge" style="background:rgba(0,245,255,0.15);color:var(--neon-cyan);border:1px solid var(--neon-cyan)">Classic</span>
        <span class="mode-icon">⚡</span>
        <div class="mode-name">Quick Quiz</div>
        <div class="mode-desc">10 random questions. Perfect for a fast knowledge check. No time pressure.</div>
      </div>
      <div class="mode-card" style="--mode-color: var(--neon-gold)" data-mode="time_attack">
        <span class="mode-badge" style="background:rgba(255,215,0,0.15);color:var(--neon-gold);border:1px solid var(--neon-gold)">Hot</span>
        <span class="mode-icon">⏱</span>
        <div class="mode-name">Time Attack</div>
        <div class="mode-desc">Answer as many questions as you can in 60 seconds. Speed is everything!</div>
      </div>
      <div class="mode-card" style="--mode-color: var(--neon-pink)" data-mode="survival">
        <span class="mode-badge" style="background:rgba(255,0,170,0.15);color:var(--neon-pink);border:1px solid var(--neon-pink)">Hard</span>
        <span class="mode-icon">💀</span>
        <div class="mode-name">Survival Mode</div>
        <div class="mode-desc">3 lives. One wrong answer costs you a life. Lose them all — game over!</div>
      </div>
      <div class="mode-card" style="--mode-color: var(--neon-green)" data-mode="endless">
        <span class="mode-badge" style="background:rgba(0,255,136,0.15);color:var(--neon-green);border:1px solid var(--neon-green)">∞</span>
        <span class="mode-icon">🔁</span>
        <div class="mode-name">Endless Mode</div>
        <div class="mode-desc">No limits. Keep going forever and climb the leaderboard with every answer.</div>
      </div>
    </div>
  </section>

  <hr class="neon-divider">

  <!-- Categories -->
  <section class="section" id="categories">
    <div class="section-header">
      <h2 class="section-title glow-pink">Choose Category</h2>
      <p class="section-sub">Pick a topic you love and start your quiz adventure</p>
    </div>
    <div class="categories-grid">
      <?php foreach ($categories as $cat): ?>
      <a class="category-card" href="<?=BASE?>/play.php?category=<?= $cat['id'] ?>" data-id="<?= $cat['id'] ?>">
        <span class="category-icon"><?= $cat['icon'] ?></span>
        <div class="category-name"><?= h($cat['name']) ?></div>
        <div class="category-count"><?= $cat['question_count'] ?> questions</div>
      </a>
      <?php endforeach; ?>
    </div>
  </section>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
