<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// register.php
require_once 'includes/functions.php';
startSecureSession();

if (isLoggedIn()) { redirect(BASE.'/index.php'); }

$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['password'] !== $_POST['confirm']) {
        $error = 'Passwords do not match';
    } else {
        $result = registerUser(
            trim($_POST['username'] ?? ''),
            trim($_POST['email'] ?? ''),
            $_POST['password'] ?? ''
        );
        if (isset($result['error'])) {
            $error = $result['error'];
        } else {
            redirect(BASE.'/index.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>
  <canvas id="particles-canvas"></canvas>

  <div class="auth-container">
    <div class="auth-card">
      <div class="auth-logo">
        <h1>QUIZ<span style="color:var(--neon-pink)">VERSE</span></h1>
        <p>Create your account &amp; start your journey</p>
      </div>

      <?php if ($error): ?>
        <div class="form-error">⚠ <?= h($error) ?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input class="form-control" type="text" name="username"
                 placeholder="Choose a unique username"
                 value="<?= h($_POST['username'] ?? '') ?>"
                 minlength="3" maxlength="50" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <input class="form-control" type="email" name="email"
                 placeholder="your@email.com"
                 value="<?= h($_POST['email'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input class="form-control" type="password" name="password"
                 placeholder="Min. 6 characters" minlength="6" required>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm Password</label>
          <input class="form-control" type="password" name="confirm"
                 placeholder="Repeat your password" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;margin-top:0.5rem">
          🚀 CREATE ACCOUNT
        </button>
      </form>

      <div class="auth-footer">
        <p>Already have an account? <a href="<?=BASE?>/login.php">Login</a></p>
        <p style="margin-top:0.5rem"><a href="<?=BASE?>/index.php" style="color:var(--text-dim)">← Back to Home</a></p>
      </div>
    </div>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
