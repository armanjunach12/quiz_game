/* ============================================================
   QuizVerse — Main JavaScript
   Includes: Particles, Sound Engine, Music Player (10 tracks),
             Category Animations, Quiz Game Engine, Confetti
   ============================================================ */

// ── PARTICLES SYSTEM ─────────────────────────────────────
class ParticleSystem {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.particles = [];
    this.resize();
    this.init();
    window.addEventListener('resize', () => this.resize());
    this.animate();
  }
  resize() {
    if (!this.canvas) return;
    this.canvas.width  = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }
  init() {
    const count = Math.floor((window.innerWidth * window.innerHeight) / 12000);
    for (let i = 0; i < count; i++) this.particles.push(this.createParticle());
  }
  createParticle() {
    const colors = ['#00f5ff','#ff00aa','#ffd700','#bf00ff','#00ff88'];
    return {
      x: Math.random() * (this.canvas?.width || 800),
      y: Math.random() * (this.canvas?.height || 600),
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      r: Math.random() * 2 + 0.5,
      color: colors[Math.floor(Math.random() * colors.length)],
      alpha: Math.random() * 0.5 + 0.1,
      pulse: Math.random() * Math.PI * 2,
    };
  }
  animate() {
    if (!this.canvas) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.particles.forEach((p, i) => {
      p.x += p.vx; p.y += p.vy; p.pulse += 0.02;
      const a = p.alpha * (0.7 + 0.3 * Math.sin(p.pulse));
      if (p.x < 0) p.x = this.canvas.width;
      if (p.x > this.canvas.width) p.x = 0;
      if (p.y < 0) p.y = this.canvas.height;
      if (p.y > this.canvas.height) p.y = 0;
      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      this.ctx.fillStyle = p.color + Math.round(a * 255).toString(16).padStart(2,'0');
      this.ctx.fill();
      for (let j = i+1; j < this.particles.length; j++) {
        const q = this.particles[j];
        const dx = p.x - q.x, dy = p.y - q.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 100) {
          this.ctx.beginPath();
          this.ctx.moveTo(p.x, p.y);
          this.ctx.lineTo(q.x, q.y);
          this.ctx.strokeStyle = p.color + Math.round((1-dist/100)*0.2*255).toString(16).padStart(2,'0');
          this.ctx.lineWidth = 0.5;
          this.ctx.stroke();
        }
      }
    });
    requestAnimationFrame(() => this.animate());
  }
}

// ── CONFETTI ──────────────────────────────────────────────
class Confetti {
  static fire() {
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:fixed;inset:0;z-index:9999;pointer-events:none;';
    document.body.appendChild(canvas);
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const ctx = canvas.getContext('2d');
    const pieces = [];
    const colors = ['#00f5ff','#ff00aa','#ffd700','#00ff88','#bf00ff','#ff5500'];
    for (let i = 0; i < 200; i++) {
      pieces.push({
        x: Math.random() * canvas.width, y: -10 - Math.random() * canvas.height,
        w: Math.random()*12+4, h: Math.random()*8+3,
        vy: Math.random()*4+2, vx: (Math.random()-0.5)*3,
        rot: Math.random()*360, rSpeed: (Math.random()-0.5)*8,
        color: colors[Math.floor(Math.random()*colors.length)], alpha: 1
      });
    }
    let frame = 0;
    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      frame++; let alive = false;
      pieces.forEach(p => {
        p.y += p.vy; p.x += p.vx; p.rot += p.rSpeed;
        if (frame > 120) p.alpha -= 0.015;
        if (p.y < canvas.height + 20 && p.alpha > 0) alive = true;
        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot * Math.PI / 180);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w/2, -p.h/2, p.w, p.h);
        ctx.restore();
      });
      if (alive) requestAnimationFrame(draw); else canvas.remove();
    }
    draw();
  }
}

// ── QUIZ TIMER ────────────────────────────────────────────
class QuizTimer {
  constructor(totalSeconds, onTick, onEnd) {
    this.total = totalSeconds; this.remaining = totalSeconds;
    this.onTick = onTick; this.onEnd = onEnd;
    this.interval = null; this.paused = false;
  }
  start() {
    this.interval = setInterval(() => {
      if (this.paused) return;
      this.remaining--;
      this.onTick(this.remaining, this.total);
      if (this.remaining <= 0) { clearInterval(this.interval); this.onEnd(); }
    }, 1000);
  }
  pause()  { this.paused = true; }
  resume() { this.paused = false; }
  stop()   { clearInterval(this.interval); }
  reset(s) { this.remaining = s || this.total; }
}

function updateTimerCircle(remaining, total) {
  const fill = document.querySelector('.timer-fill');
  const text = document.querySelector('.timer-text');
  if (!fill || !text) return;
  const pct = remaining / total;
  const dash = 201;
  fill.style.strokeDashoffset = dash - (dash * pct);
  fill.classList.remove('warning','danger');
  if (pct <= 0.25) fill.classList.add('danger');
  else if (pct <= 0.5) fill.classList.add('warning');
  text.textContent = remaining;
  if (remaining <= 5 && remaining > 0) MusicPlayer.sfx('tick');
}

// ── TOAST NOTIFICATIONS ───────────────────────────────────
function showToast(message, type = 'info') {
  const container = document.querySelector('.toast-container') || (() => {
    const c = document.createElement('div');
    c.className = 'toast-container';
    document.body.appendChild(c);
    return c;
  })();
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'toastIn 0.3s ease-out reverse';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── COUNTER ANIMATION ─────────────────────────────────────
function animateCounter(el, target, duration = 1500) {
  const start = performance.now();
  const from = parseInt(el.textContent) || 0;
  function step(now) {
    const p = Math.min((now - start) / duration, 1);
    const e = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(from + (target - from) * e);
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function animateOption(btn, isCorrect, correctIndex) {
  const options = document.querySelectorAll('.option-btn');
  options.forEach(o => { o.disabled = true; o.style.pointerEvents = 'none'; });
  btn.classList.add(isCorrect ? 'correct' : 'wrong');
  if (!isCorrect) {
    options.forEach(o => {
      if (parseInt(o.dataset.option) === correctIndex) o.classList.add('correct');
    });
  }
}

// ── MUSIC PLAYER — 10 synthesized tracks ─────────────────
const MusicPlayer = (() => {
  let audioCtx = null;
  let masterGain = null;
  let currentTrackNodes = [];
  let currentTrackIndex = parseInt(localStorage.getItem('qv_track') || '0');
  let muted = localStorage.getItem('qv_muted') === 'true';
  let volume = parseFloat(localStorage.getItem('qv_vol') || '0.25');
  let isPlaying = false;
  let trackTimeout = null;

  const TRACKS = [
    { name: 'Cyber Quiz Beat',       tempo: 130, style: 'electronic' },
    { name: 'Retro 8-Bit Adventure', tempo: 160, style: 'chiptune'   },
    { name: 'Epic Quest Fanfare',     tempo: 100, style: 'orchestral' },
    { name: 'Lo-Fi Chill Zone',      tempo: 80,  style: 'lofi'       },
    { name: 'Dance Pop Quiz',        tempo: 120, style: 'pop'        },
    { name: 'Mysterious Ambient',    tempo: 70,  style: 'ambient'    },
    { name: 'Rock Quiz Jam',         tempo: 140, style: 'rock'       },
    { name: 'Jazz Café Vibes',       tempo: 100, style: 'jazz'       },
    { name: 'Tropical Bounce',       tempo: 110, style: 'tropical'   },
    { name: 'Synthwave Night Drive', tempo: 90,  style: 'synthwave'  },
    { name: 'Cinematic Victory',     tempo: 95,  style: 'cinematic'  },
  ];

  function initAudio() {
    if (audioCtx) return;
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    masterGain = audioCtx.createGain();
    masterGain.gain.value = muted ? 0 : volume;
    masterGain.connect(audioCtx.destination);
  }

  function note(freq, start, dur, type = 'sine', amp = 0.15, attack = 0.01, decay = 0.1) {
    if (!audioCtx) return null;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain); gain.connect(masterGain);
    osc.type = type;
    osc.frequency.setValueAtTime(freq, start);
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(amp, start + attack);
    gain.gain.exponentialRampToValueAtTime(0.001, start + dur - 0.01);
    osc.start(start);
    osc.stop(start + dur);
    currentTrackNodes.push(osc);
    return osc;
  }

  function drum(type, start, dur = 0.1) {
    if (!audioCtx) return;
    const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * dur, audioCtx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    }
    const src = audioCtx.createBufferSource();
    src.buffer = buf;
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();
    if (type === 'kick') { filter.type = 'lowpass'; filter.frequency.value = 200; gain.gain.value = 0.6; }
    else if (type === 'snare') { filter.type = 'highpass'; filter.frequency.value = 500; gain.gain.value = 0.4; }
    else { filter.type = 'highpass'; filter.frequency.value = 3000; gain.gain.value = 0.2; }
    src.connect(filter); filter.connect(gain); gain.connect(masterGain);
    src.start(start);
    currentTrackNodes.push(src);
  }

  // Pentatonic scale helpers
  const penta  = [261.63,293.66,329.63,392,440,523.25,587.33,659.26,783.99,880];
  const minor  = [261.63,293.66,311.13,349.23,392,415.3,466.16,523.25];
  const major  = [261.63,293.66,329.63,349.23,392,440,493.88,523.25];
  const blues  = [261.63,311.13,349.23,369.99,392,466.16,523.25];

  function playElectronic(t, beats, beat) {
    // Bass line
    const bassFreqs = [65.41,73.42,82.41,87.31];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      note(bassFreqs[b % bassFreqs.length], bt, beat * 0.9, 'sawtooth', 0.2);
      // lead melody
      if (b % 2 === 0) {
        const f = penta[Math.floor(Math.random() * penta.length)];
        note(f, bt + beat*0.25, beat * 0.4, 'square', 0.08);
        note(f*2, bt + beat*0.5, beat * 0.3, 'sine', 0.05);
      }
      // drums
      drum('kick', bt, 0.12);
      if (b % 2 === 1) drum('snare', bt, 0.1);
      drum('hat', bt + beat*0.5, 0.05);
    }
  }

  function playChiptune(t, beats, beat) {
    const melody = [523.25,587.33,659.26,698.46,783.99,698.46,659.26,587.33];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      const f = melody[b % melody.length];
      note(f, bt, beat*0.5, 'square', 0.1);
      note(f/2, bt, beat*0.9, 'square', 0.15);
      if (b % 4 === 0) drum('kick', bt, 0.08);
      if (b % 4 === 2) drum('snare', bt, 0.08);
      drum('hat', bt + beat*0.5, 0.04);
    }
  }

  function playOrchestral(t, beats, beat) {
    const melody = [329.63,392,440,392,349.23,329.63,293.66,261.63];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      const f = melody[b % melody.length];
      note(f,   bt, beat*0.85, 'sine',     0.12);
      note(f*2, bt, beat*0.7,  'triangle', 0.06);
      note(f/2, bt, beat*0.9,  'sine',     0.1);
    }
  }

  function playLofi(t, beats, beat) {
    const chords = [[261.63,329.63,392],[293.66,369.99,440],[246.94,311.13,369.99],[220,277.18,329.63]];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      const chord = chords[Math.floor(b/2) % chords.length];
      chord.forEach(f => note(f, bt, beat*0.8, 'triangle', 0.06));
      if (b % 4 === 0) drum('kick', bt, 0.15);
      if (b % 4 === 2) drum('snare', bt, 0.12);
      drum('hat', bt + beat * (b%2===0 ? 0.5 : 0.25), 0.06);
    }
  }

  function playPop(t, beats, beat) {
    const mel = [523.25,659.26,783.99,659.26,523.25,440,392,440];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      note(mel[b % mel.length], bt, beat*0.7, 'sine', 0.12);
      note(mel[b % mel.length]/2, bt, beat*0.9, 'sawtooth', 0.08);
      drum('kick', bt, 0.1);
      if (b % 2 === 1) drum('snare', bt, 0.1);
      drum('hat', bt + beat/3, 0.05);
      drum('hat', bt + beat*2/3, 0.05);
    }
  }

  function playAmbient(t, beats, beat) {
    const freqs = [174.61,207.65,246.94,261.63,293.66,329.63];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      const f = freqs[b % freqs.length];
      note(f,   bt, beat*2,   'sine',     0.07, 0.3, 1.5);
      note(f*3, bt, beat*1.5, 'triangle', 0.03, 0.2, 1.0);
    }
  }

  function playRock(t, beats, beat) {
    const riff = [196,220,196,246.94,196,174.61,196,220];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      note(riff[b % riff.length], bt, beat*0.6, 'sawtooth', 0.18);
      note(riff[b % riff.length]/2, bt, beat*0.9, 'sawtooth', 0.15);
      drum('kick', bt, 0.12);
      if (b % 4 === 2) drum('snare', bt, 0.15);
      drum('hat', bt + beat*0.5, 0.07);
    }
  }

  function playJazz(t, beats, beat) {
    const jz = [261.63,329.63,392.00,493.88,523.25,493.88,415.30,349.23];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      note(jz[b % jz.length], bt, beat*0.6, 'triangle', 0.1);
      note(jz[b % jz.length]/2, bt, beat*0.8, 'sine', 0.08);
      if (b % 3 === 0) drum('kick', bt, 0.1);
      if (b % 3 === 1) drum('hat', bt + beat*0.33, 0.06);
      if (b % 3 === 2) drum('hat', bt + beat*0.67, 0.06);
    }
  }

  function playTropical(t, beats, beat) {
    const trop = [329.63,392,440,392,349.23,329.63,392,440];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      note(trop[b % trop.length], bt, beat*0.5, 'sine', 0.1);
      note(trop[b % trop.length]*1.5, bt+beat*0.25, beat*0.3, 'triangle', 0.05);
      drum('kick', bt, 0.1);
      drum('hat', bt + beat*0.5, 0.07);
      drum('hat', bt + beat*0.75, 0.05);
    }
  }

  function playSynthwave(t, beats, beat) {
    const sw = [130.81,146.83,164.81,174.61,196,220,246.94,261.63];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      note(sw[b % sw.length], bt, beat*0.9, 'sawtooth', 0.12);
      note(sw[b % sw.length]*2, bt+beat*0.1, beat*0.5, 'square', 0.05);
      drum('kick', bt, 0.1);
      if (b % 2 === 1) { drum('snare', bt, 0.1); }
      drum('hat', bt + beat*0.5, 0.06);
    }
  }

  function playCinematic(t, beats, beat) {
    const cin = [261.63,311.13,392,466.16,523.25,466.16,392,349.23];
    for (let b = 0; b < beats; b++) {
      const bt = t + b * beat;
      const f = cin[b % cin.length];
      note(f,   bt, beat*1.2, 'sine',     0.15, 0.05, 0.6);
      note(f*2, bt, beat*0.8, 'triangle', 0.07, 0.02, 0.4);
      note(f/2, bt, beat*1.5, 'sine',     0.12, 0.1,  0.8);
    }
  }

  const RENDERERS = [
    playElectronic, playChiptune, playOrchestral, playLofi, playPop,
    playAmbient, playRock, playJazz, playTropical, playSynthwave, playCinematic
  ];

  function stopCurrent() {
    clearTimeout(trackTimeout);
    currentTrackNodes.forEach(n => { try { n.stop(); } catch(e) {} });
    currentTrackNodes = [];
    isPlaying = false;
  }

  function playTrack(index) {
    stopCurrent();
    if (muted) return;
    initAudio();
    if (audioCtx.state === 'suspended') audioCtx.resume();

    const track = TRACKS[index];
    const renderer = RENDERERS[index];
    const beat = 60 / track.tempo;
    const beatsPerBar = 8;
    const t0 = audioCtx.currentTime + 0.05;
    isPlaying = true;
    currentTrackIndex = index;
    localStorage.setItem('qv_track', index);
    updateNowPlaying();

    // Play 4 bars then loop
    function playBar(barStart) {
      if (!isPlaying) return;
      try {
        renderer(barStart, beatsPerBar, beat);
      } catch(e) {}
      const barDur = beatsPerBar * beat * 1000;
      trackTimeout = setTimeout(() => {
        if (isPlaying) playBar(audioCtx.currentTime + 0.05);
      }, barDur - 50);
    }
    playBar(t0);
  }

  function updateNowPlaying() {
    const el = document.getElementById('now-playing-text');
    if (el) el.textContent = TRACKS[currentTrackIndex].name;
  }

  function nextTrack() {
    currentTrackIndex = (currentTrackIndex + 1) % TRACKS.length;
    if (!muted) playTrack(currentTrackIndex);
    else { localStorage.setItem('qv_track', currentTrackIndex); updateNowPlaying(); }
  }

  function prevTrack() {
    currentTrackIndex = (currentTrackIndex - 1 + TRACKS.length) % TRACKS.length;
    if (!muted) playTrack(currentTrackIndex);
    else { localStorage.setItem('qv_track', currentTrackIndex); updateNowPlaying(); }
  }

  function toggleMute() {
    muted = !muted;
    localStorage.setItem('qv_muted', muted);
    if (audioCtx) masterGain.gain.value = muted ? 0 : volume;
    if (!muted) playTrack(currentTrackIndex);
    else stopCurrent();
    updateUI();
  }

  function setVolume(v) {
    volume = Math.max(0, Math.min(1, v));
    localStorage.setItem('qv_vol', volume);
    if (audioCtx && !muted) masterGain.gain.value = volume;
  }

  function updateUI() {
    const btn = document.getElementById('music-toggle');
    const icon = document.getElementById('music-icon');
    if (btn) btn.classList.toggle('playing', !muted);
    if (icon) icon.textContent = muted ? '🔇' : '🎵';
    updateNowPlaying();
  }

  // SFX
  function sfx(type) {
    if (muted) return;
    initAudio();
    const t = audioCtx.currentTime;
    if (type === 'correct') {
      note(523, t, 0.1, 'sine', 0.3);
      note(659, t+0.1, 0.1, 'sine', 0.3);
      note(784, t+0.2, 0.2, 'sine', 0.3);
    } else if (type === 'wrong') {
      note(200, t, 0.1, 'sawtooth', 0.3);
      note(150, t+0.1, 0.3, 'sawtooth', 0.2);
    } else if (type === 'tick') {
      note(880, t, 0.05, 'square', 0.1);
    } else if (type === 'win') {
      [523,659,784,1047].forEach((n,i) => note(n, t+i*0.15, 0.3, 'sine', 0.4));
    }
  }

  function autoStart() {
    initAudio();
    if (!muted) {
      setTimeout(() => playTrack(currentTrackIndex), 300);
    }
    updateUI();
  }

  return { playTrack, nextTrack, prevTrack, toggleMute, setVolume, sfx, updateUI, autoStart, get muted() { return muted; }, get trackName() { return TRACKS[currentTrackIndex].name; } };
})();

// ── CATEGORY ANIMATIONS ───────────────────────────────────
const CategoryTheme = {
  themes: {
    1:  { cls: 'theme-football',   name: 'Football'         },
    2:  { cls: 'theme-cricket',    name: 'Cricket'          },
    3:  { cls: 'theme-anime',      name: 'Anime'            },
    4:  { cls: 'theme-movies',     name: 'Movies'           },
    5:  { cls: 'theme-music',      name: 'Music'            },
    6:  { cls: 'theme-gaming',     name: 'Gaming'           },
    7:  { cls: 'theme-history',    name: 'History'          },
    8:  { cls: 'theme-science',    name: 'Science'          },
    9:  { cls: 'theme-world',      name: 'World Knowledge'  },
    10: { cls: 'theme-tech',       name: 'Technology'       },
    11: { cls: 'theme-cars',       name: 'Cars'             },
    12: { cls: 'theme-geography',  name: 'Geography'        },
    13: { cls: 'theme-space',      name: 'Space'            },
    14: { cls: 'theme-internet',   name: 'Internet Culture' },
    15: { cls: 'theme-multimedia', name: 'Multimedia Mix'   },
  },
  apply(categoryId) {
    const theme = this.themes[categoryId];
    if (!theme) return;
    document.body.classList.add(theme.cls);
  }
};

// ── DIFFICULTY SELECTOR ───────────────────────────────────
document.querySelectorAll('.diff-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.diff-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    const hidden = document.getElementById('selected_difficulty');
    if (hidden) hidden.value = btn.dataset.diff;
  });
});

// ── STAGGERED ENTRANCE ────────────────────────────────────
function staggerEntrance(selector, delay = 80) {
  document.querySelectorAll(selector).forEach((el, i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    setTimeout(() => {
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    }, i * delay + 100);
  });
}

// ── CATEGORY CARD TILT ────────────────────────────────────
document.querySelectorAll('.category-card').forEach(card => {
  card.addEventListener('mousemove', e => {
    const rect = card.getBoundingClientRect();
    const dx = (e.clientX - rect.left - rect.width/2) / (rect.width/2);
    const dy = (e.clientY - rect.top - rect.height/2) / (rect.height/2);
    card.style.transform = `translateY(-8px) scale(1.02) perspective(600px) rotateX(${-dy*6}deg) rotateY(${dx*6}deg)`;
  });
  card.addEventListener('mouseleave', () => { card.style.transform = ''; });
});

// ── MUSIC PLAYER UI BUILDER ───────────────────────────────
function buildMusicPlayerUI() {
  const existing = document.getElementById('music-player-ui');
  if (existing) return;

  const ui = document.createElement('div');
  ui.id = 'music-player-ui';
  ui.innerHTML = `
    <button id="music-prev" title="Previous Track" aria-label="Previous">⏮</button>
    <button id="music-toggle" class="${MusicPlayer.muted ? '' : 'playing'}" title="Play/Pause" aria-label="Toggle Music">
      <span id="music-icon">${MusicPlayer.muted ? '🔇' : '🎵'}</span>
    </button>
    <button id="music-next" title="Next Track" aria-label="Next">⏭</button>
    <div id="now-playing-text" title="Now Playing">♪ ${MusicPlayer.trackName}</div>
    <input type="range" id="vol-slider" min="0" max="1" step="0.05" value="${localStorage.getItem('qv_vol')||'0.25'}" title="Volume" style="width:70px;accent-color:var(--neon-cyan)">
  `;
  document.body.appendChild(ui);

  document.getElementById('music-toggle').addEventListener('click', () => {
    MusicPlayer.toggleMute();
    document.getElementById('music-icon').textContent = MusicPlayer.muted ? '🔇' : '🎵';
    document.getElementById('music-toggle').classList.toggle('playing', !MusicPlayer.muted);
    document.getElementById('now-playing-text').textContent = '♪ ' + MusicPlayer.trackName;
  });
  document.getElementById('music-prev').addEventListener('click', () => {
    MusicPlayer.prevTrack();
    document.getElementById('now-playing-text').textContent = '♪ ' + MusicPlayer.trackName;
  });
  document.getElementById('music-next').addEventListener('click', () => {
    MusicPlayer.nextTrack();
    document.getElementById('now-playing-text').textContent = '♪ ' + MusicPlayer.trackName;
  });
  document.getElementById('vol-slider').addEventListener('input', e => {
    MusicPlayer.setVolume(parseFloat(e.target.value));
  });
}

// ── MODE CARD SELECTION ───────────────────────────────────
let selectedMode = 'quick';
document.querySelectorAll('.mode-card').forEach(card => {
  card.addEventListener('click', () => {
    selectedMode = card.dataset.mode;
    document.querySelectorAll('.mode-card').forEach(c => c.style.opacity = '0.5');
    card.style.opacity = '1';
    card.style.transform = 'translateY(-6px) scale(1.04)';
    showToast('Mode: ' + card.querySelector('.mode-name')?.textContent, 'info');
  });
});

document.querySelectorAll('.category-card').forEach(a => {
  a.addEventListener('click', e => {
    if (a.href && a.href.includes('play.php')) {
      e.preventDefault();
      const url = a.href + (a.href.includes('?') ? '&' : '?') + 'mode=' + selectedMode;
      window.location.href = url;
    }
  });
});

// ── DOMContentLoaded ──────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  new ParticleSystem('particles-canvas');
  staggerEntrance('.category-card', 60);
  staggerEntrance('.mode-card', 100);
  staggerEntrance('.achievement-card', 80);

  document.querySelectorAll('[data-count]').forEach(el => {
    animateCounter(el, parseInt(el.dataset.count), 2000);
  });

  buildMusicPlayerUI();

  // Remove old single music-toggle if present (replaced by player UI)
  const oldBtn = document.querySelector('.music-control');
  if (oldBtn && !oldBtn.closest('#music-player-ui')) oldBtn.remove();
});

// First user interaction — start music
document.addEventListener('click', () => {
  MusicPlayer.autoStart();
}, { once: true });

// ── QUIZ PAGE LOGIC ───────────────────────────────────────
window.QuizGame = {
  sessionId: null, total: 0, score: 0, timer: null, answered: false,

  init(sessionId, total, timeLimit) {
    this.sessionId = sessionId;
    this.total = total;
    this.answered = false;

    // Apply category theme coloring from body class if set
    if (timeLimit > 0) {
      this.timer = new QuizTimer(timeLimit, (rem, tot) => {
        updateTimerCircle(rem, tot);
      }, () => {
        if (!this.answered) this.autoTimeout();
      });
      this.timer.start();
    }
  },

  answer(btn, selectedOption) {
    if (this.answered) return;
    this.answered = true;
    if (this.timer) this.timer.pause();

    fetch((window.QUIZ_BASE||'') + '/ajax/answer.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: this.sessionId, option: selectedOption })
    })
    .then(r => r.json())
    .then(data => {
      if (data.error) { showToast(data.error, 'error'); return; }
      animateOption(btn, data.correct, data.correct_option);
      if (data.correct) {
        MusicPlayer.sfx('correct');
        showToast('+' + data.points + ' pts ✓', 'success');
      } else {
        MusicPlayer.sfx('wrong');
        if (data.explanation) showToast('💡 ' + data.explanation, 'info');
      }
      const scoreEl = document.getElementById('live-score');
      if (scoreEl) animateCounter(scoreEl, data.session_score);
      if (data.lives !== undefined) {
        document.querySelectorAll('.life-icon').forEach((el, i) => {
          el.classList.toggle('lost', i >= data.lives);
        });
      }
      setTimeout(() => {
        if (data.is_complete) {
          if (data.session_score > 0) { MusicPlayer.sfx('win'); Confetti.fire(); }
          window.location.href = (window.QUIZ_BASE||'') + '/result.php?session=' + this.sessionId;
        } else {
          this.loadNext(data.next_index, data.total);
        }
      }, 1800);
    })
    .catch(() => showToast('Connection error. Please retry.', 'error'));
  },

  autoTimeout() {
    this.answered = true;
    showToast('⏱ Time\'s up!', 'error');
    setTimeout(() => {
      fetch((window.QUIZ_BASE||'') + '/ajax/answer.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: this.sessionId, option: 0, timeout: true })
      })
      .then(r => r.json())
      .then(data => {
        if (data.is_complete) {
          window.location.href = (window.QUIZ_BASE||'') + '/result.php?session=' + this.sessionId;
        } else {
          this.loadNext(data.next_index, data.total);
        }
      });
    }, 1000);
  },

  loadNext(index, total) {
    const progressBar = document.getElementById('progress-bar');
    if (progressBar) {
      progressBar.style.width = ((index / total) * 100) + '%';
    }
    fetch((window.QUIZ_BASE||'') + '/ajax/question.php?session_id=' + this.sessionId)
      .then(r => r.json())
      .then(data => {
        if (data.error || !data.question) {
          window.location.href = (window.QUIZ_BASE||'') + '/result.php?session=' + this.sessionId;
          return;
        }
        this.renderQuestion(data.question, data.index, data.total, data.timer_seconds);
      });
  },

  renderQuestion(q, index, total, timerSec) {
    this.answered = false;
    const qNum  = document.getElementById('q-number');
    const qText = document.getElementById('q-text');
    const qOpts = document.getElementById('q-options');
    const qMedia= document.getElementById('q-media');
    const qCard = document.querySelector('.question-card');

    if (qNum)  qNum.textContent = `Q${index + 1} / ${total}`;
    if (qText) qText.textContent = q.question_text;

    if (qMedia) {
      qMedia.innerHTML = '';
      if (q.image_path) {
        qMedia.innerHTML = `<img src="${q.image_path}" alt="Question image" loading="lazy" style="max-height:280px;border-radius:12px;object-fit:cover;">`;
      } else if (q.audio_path) {
        qMedia.innerHTML = `<audio controls src="${q.audio_path}" style="width:100%"></audio>`;
      } else if (q.video_path) {
        if (q.video_path.includes('youtube.com') || q.video_path.includes('youtu.be')) {
          const vid = q.video_path.includes('v=') ? q.video_path.split('v=')[1].split('&')[0] : q.video_path.split('/').pop();
          qMedia.innerHTML = `<iframe width="100%" height="240" src="https://www.youtube.com/embed/${vid}?autoplay=1&mute=1" frameborder="0" allowfullscreen style="border-radius:12px"></iframe>`;
        } else {
          qMedia.innerHTML = `<video controls src="${q.video_path}" style="width:100%;max-height:280px;border-radius:12px"></video>`;
        }
      }
    }

    if (qOpts) {
      const letters = ['A','B','C','D'];
      const options = [q.option1, q.option2, q.option3, q.option4].filter(Boolean);
      qOpts.innerHTML = options.map((opt, i) => `
        <button class="option-btn" data-option="${i+1}" onclick="QuizGame.answer(this,${i+1})">
          <span class="option-letter">${letters[i]}</span>
          <span>${opt}</span>
        </button>
      `).join('');
    }

    if (qCard) {
      qCard.style.animation = 'none';
      void qCard.offsetWidth;
      qCard.style.animation = 'slideIn 0.4s cubic-bezier(0.4,0,0.2,1)';
    }

    const qProgress = document.getElementById('q-number');
    const pBar = document.getElementById('progress-bar');
    if (pBar) pBar.style.width = ((index / total) * 100) + '%';
    const pLabel = document.querySelector('.progress-label span:last-child');
    if (pLabel) pLabel.textContent = Math.round((index / total) * 100) + '% Complete';

    if (this.timer && timerSec > 0) {
      this.timer.stop();
      this.timer = new QuizTimer(timerSec, (rem, tot) => updateTimerCircle(rem, tot), () => {
        if (!this.answered) this.autoTimeout();
      });
      updateTimerCircle(timerSec, timerSec);
      this.timer.start();
    }
  }
};
