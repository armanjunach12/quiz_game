<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// login.php
require_once 'includes/functions.php';
startSecureSession();

if (isLoggedIn()) { redirect(BASE.'/index.php'); }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = loginUser(trim($_POST['login'] ?? ''), $_POST['password'] ?? '');
    if (isset($result['error'])) {
        $error = $result['error'];
    } else {
        $redirect = $_GET['redirect'] ?? BASE.'/index.php';
        redirect($redirect);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>
  <canvas id="particles-canvas"></canvas>

  <div class="auth-container">
    <div class="auth-card">
      <div class="auth-logo">
        <h1>QUIZ<span style="color:var(--neon-pink)">VERSE</span></h1>
        <p>Welcome back, challenger</p>
      </div>

      <?php if ($error): ?>
        <div class="form-error">⚠ <?= h($error) ?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="form-group">
          <label class="form-label">Username or Email</label>
          <input class="form-control" type="text" name="login"
                 placeholder="Enter your username or email"
                 value="<?= h($_POST['login'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input class="form-control" type="password" name="password"
                 placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;margin-top:0.5rem">
          ▶ LOGIN
        </button>
      </form>

      <div class="auth-footer">
        <p>No account? <a href="<?=BASE?>/register.php">Register here</a></p>
        <p style="margin-top:0.5rem"><a href="<?=BASE?>/index.php" style="color:var(--text-dim)">← Back to Home</a></p>
      </div>
    </div>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
