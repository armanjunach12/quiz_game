<?php
// admin/manage_questions.php
require_once '../includes/functions.php';
startSecureSession();
requireAdmin();

$db         = getDB();
$categories = getCategories(false);
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 20;
$offset     = ($page - 1) * $perPage;
$filterCat  = (int)($_GET['cat'] ?? 0);
$filterDiff = $_GET['diff'] ?? '';
$search     = trim($_GET['q'] ?? '');

// Delete action
if ($_GET['action'] ?? '' === 'delete' && isset($_GET['id'])) {
    $db->prepare("UPDATE questions SET is_active = 0 WHERE id = ?")->execute([(int)$_GET['id']]);
    header('Location: '.BASE.'/admin/manage_questions.php?deleted=1');
    exit();
}

// Build query
$where   = ["q.is_active = 1"];
$params  = [];
if ($filterCat)  { $where[] = "q.category_id = ?"; $params[] = $filterCat; }
if ($filterDiff) { $where[] = "q.difficulty = ?";  $params[] = $filterDiff; }
if ($search)     { $where[] = "q.question_text LIKE ?"; $params[] = "%$search%"; }

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";
$total    = $db->prepare("SELECT COUNT(*) FROM questions q $whereSQL");
$total->execute($params);
$totalQ   = $total->fetchColumn();
$pages    = ceil($totalQ / $perPage);

$stmt = $db->prepare("SELECT q.*, c.name as cat_name, c.icon as cat_icon 
                      FROM questions q 
                      JOIN categories c ON c.id = q.category_id 
                      $whereSQL 
                      ORDER BY q.created_at DESC 
                      LIMIT ? OFFSET ?");
$stmt->execute([...$params, $perPage, $offset]);
$questions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Questions — Admin</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span> <span style="font-size:0.7rem;color:var(--neon-pink);vertical-align:middle"> ADMIN</span></a>
    <div class="nav-user">
      <a href="<?=BASE?>/admin/add_question.php" class="btn btn-primary btn-sm">➕ Add Question</a>
    </div>
  </nav>

  <div class="admin-layout">
    <aside class="admin-sidebar">
      <ul class="sidebar-nav">
        <li><a href="<?=BASE?>/admin/admin_dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?=BASE?>/admin/manage_questions.php" class="active">❓ Questions</a></li>
        <li><a href="<?=BASE?>/admin/add_question.php">➕ Add Question</a></li>
        <li><a href="<?=BASE?>/admin/manage_categories.php">🗂 Categories</a></li>
        <li><a href="<?=BASE?>/admin/manage_users.php">👥 Users</a></li>
        <li><a href="<?=BASE?>/admin/manage_scores.php">📈 Scores</a></li>
      </ul>
    </aside>

    <main class="admin-main">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:2rem">
        <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;color:var(--neon-cyan)">
          ❓ Questions <span style="font-size:1rem;color:var(--text-dim)">(<?= $totalQ ?> total)</span>
        </h1>
        <a href="<?=BASE?>/admin/add_question.php" class="btn btn-primary btn-sm">➕ Add New</a>
      </div>

      <?php if (!empty($_GET['deleted'])): ?>
        <div class="form-error" style="margin-bottom:1.5rem">Question deleted successfully.</div>
      <?php endif; ?>

      <!-- Filters -->
      <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:2rem">
        <input class="form-control" type="text" name="q" value="<?= h($search) ?>"
               placeholder="Search questions..." style="max-width:280px">
        <select class="form-control" name="cat" style="max-width:200px">
          <option value="">All Categories</option>
          <?php foreach ($categories as $cat): ?>
          <option value="<?= $cat['id'] ?>" <?= $filterCat === $cat['id'] ? 'selected' : '' ?>>
            <?= $cat['icon'] ?> <?= h($cat['name']) ?>
          </option>
          <?php endforeach; ?>
        </select>
        <select class="form-control" name="diff" style="max-width:160px">
          <option value="">All Difficulties</option>
          <option value="easy"   <?= $filterDiff === 'easy'   ? 'selected' : '' ?>>Easy</option>
          <option value="medium" <?= $filterDiff === 'medium' ? 'selected' : '' ?>>Medium</option>
          <option value="hard"   <?= $filterDiff === 'hard'   ? 'selected' : '' ?>>Hard</option>
        </select>
        <button type="submit" class="btn btn-ghost btn-sm">🔍 Filter</button>
        <a href="<?=BASE?>/admin/manage_questions.php" class="btn btn-sm" style="color:var(--text-dim);border:1px solid rgba(255,255,255,0.1);background:transparent">Clear</a>
      </form>

      <!-- Table -->
      <div style="overflow-x:auto">
        <table class="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Category</th>
              <th>Question</th>
              <th>Type</th>
              <th>Difficulty</th>
              <th>Points</th>
              <th>Plays</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($questions)): ?>
            <tr><td colspan="8" style="text-align:center;padding:3rem;color:var(--text-dim)">No questions found.</td></tr>
            <?php else: foreach ($questions as $q): ?>
            <tr>
              <td class="mono" style="color:var(--text-dim)">#<?= $q['id'] ?></td>
              <td><?= $q['cat_icon'] ?> <span style="font-size:0.85rem"><?= h($q['cat_name']) ?></span></td>
              <td style="max-width:300px">
                <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:300px" title="<?= h($q['question_text']) ?>">
                  <?= h(mb_substr($q['question_text'], 0, 70)) ?><?= mb_strlen($q['question_text']) > 70 ? '…' : '' ?>
                </div>
                <?php if ($q['image_path'] || $q['audio_path'] || $q['video_path']): ?>
                  <div style="font-size:0.75rem;color:var(--neon-purple);margin-top:3px">
                    <?= $q['image_path'] ? '🖼' : '' ?><?= $q['audio_path'] ? '🎵' : '' ?><?= $q['video_path'] ? '🎥' : '' ?> media attached
                  </div>
                <?php endif; ?>
              </td>
              <td style="font-size:0.8rem;color:var(--text-dim)"><?= str_replace('_',' ', $q['question_type']) ?></td>
              <td>
                <?php
                $dc = ['easy'=>'var(--neon-green)','medium'=>'var(--neon-gold)','hard'=>'var(--neon-pink)'];
                $c  = $dc[$q['difficulty']] ?? 'var(--text-dim)';
                ?>
                <span style="color:<?= $c ?>;font-weight:700;font-size:0.85rem"><?= ucfirst($q['difficulty']) ?></span>
              </td>
              <td class="mono" style="color:var(--neon-gold)"><?= $q['points'] ?></td>
              <td class="mono" style="color:var(--text-dim)"><?= $q['times_played'] ?></td>
              <td>
                <div style="display:flex;gap:0.5rem">
                  <a href="<?=BASE?>/admin/edit_question.php?id=<?= $q['id'] ?>"
                     class="btn btn-ghost btn-sm">Edit</a>
                  <a href="<?=BASE?>/admin/manage_questions.php?action=delete&id=<?= $q['id'] ?>&page=<?= $page ?>&cat=<?= $filterCat ?>&diff=<?= $filterDiff ?>&q=<?= urlencode($search) ?>"
                     class="btn btn-danger btn-sm"
                     onclick="return confirm('Delete this question?')">Del</a>
                </div>
              </td>
            </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <?php if ($pages > 1): ?>
      <div style="display:flex;gap:0.5rem;justify-content:center;margin-top:2rem;flex-wrap:wrap">
        <?php for ($p = 1; $p <= $pages; $p++): ?>
        <a href="?page=<?= $p ?>&cat=<?= $filterCat ?>&diff=<?= $filterDiff ?>&q=<?= urlencode($search) ?>"
           class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-ghost' ?>"
           style="min-width:40px"><?= $p ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>

    </main>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
