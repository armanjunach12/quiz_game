<?php
// admin/edit_question.php
require_once '../includes/functions.php';
startSecureSession();
requireAdmin();

$db         = getDB();
$id         = (int)($_GET['id'] ?? 0);
$categories = getCategories(false);
$error = $success = '';

$stmt = $db->prepare("SELECT * FROM questions WHERE id = ?");
$stmt->execute([$id]);
$question = $stmt->fetch();
if (!$question) { redirect(BASE.'/admin/manage_questions.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'category_id'   => (int)$_POST['category_id'],
        'question_text' => trim($_POST['question_text'] ?? ''),
        'question_type' => $_POST['question_type'] ?? 'multiple_choice',
        'difficulty'    => $_POST['difficulty'] ?? 'medium',
        'option1'       => trim($_POST['option1'] ?? ''),
        'option2'       => trim($_POST['option2'] ?? ''),
        'option3'       => trim($_POST['option3'] ?? ''),
        'option4'       => trim($_POST['option4'] ?? ''),
        'correct_option'=> (int)($_POST['correct_option'] ?? 1),
        'explanation'   => trim($_POST['explanation'] ?? ''),
        'points'        => (int)($_POST['points'] ?? 10),
        'image_path'    => $question['image_path'],
        'audio_path'    => $question['audio_path'],
        'video_path'    => $question['video_path'],
    ];

    foreach (['image' => 'images', 'audio' => 'audio', 'video' => 'video'] as $field => $type) {
        if (!empty($_FILES[$field]['name'])) {
            $result = handleFileUpload($_FILES[$field], $type);
            if (isset($result['error'])) { $error = $result['error']; break; }
            $data[$field . '_path'] = $result['path'];
        }
    }

    if (!$error) {
        $db->prepare("UPDATE questions SET category_id=?, question_text=?, question_type=?, difficulty=?,
            image_path=?, audio_path=?, video_path=?,
            option1=?, option2=?, option3=?, option4=?,
            correct_option=?, explanation=?, points=?
            WHERE id=?")->execute([
                $data['category_id'], $data['question_text'], $data['question_type'], $data['difficulty'],
                $data['image_path'], $data['audio_path'], $data['video_path'],
                $data['option1'], $data['option2'], $data['option3'], $data['option4'],
                $data['correct_option'], $data['explanation'], $data['points'], $id
            ]);
        $success = 'Question updated!';
        // Refresh
        $stmt->execute([$id]);
        $question = $stmt->fetch();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Question — Admin</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span> <span style="font-size:0.7rem;color:var(--neon-pink);vertical-align:middle"> ADMIN</span></a>
    <div class="nav-user">
      <a href="<?=BASE?>/admin/manage_questions.php" class="btn btn-ghost btn-sm">← Questions</a>
    </div>
  </nav>

  <div class="admin-layout">
    <aside class="admin-sidebar">
      <ul class="sidebar-nav">
        <li><a href="<?=BASE?>/admin/admin_dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?=BASE?>/admin/manage_questions.php" class="active">❓ Questions</a></li>
        <li><a href="<?=BASE?>/admin/add_question.php">➕ Add Question</a></li>
        <li><a href="<?=BASE?>/admin/manage_categories.php">🗂 Categories</a></li>
        <li><a href="<?=BASE?>/admin/manage_users.php">👥 Users</a></li>
        <li><a href="<?=BASE?>/admin/manage_scores.php">📈 Scores</a></li>
      </ul>
    </aside>

    <main class="admin-main">
      <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;margin-bottom:2rem;color:var(--neon-cyan)">
        ✏️ Edit Question #<?= $id ?>
      </h1>

      <?php if ($error):   ?><div class="form-error">⚠ <?= h($error) ?></div><?php endif; ?>
      <?php if ($success): ?><div class="form-success">✓ <?= h($success) ?></div><?php endif; ?>

      <div class="card" style="padding:2.5rem;max-width:900px">
        <form method="POST" enctype="multipart/form-data">

          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <div class="form-group" style="margin:0">
              <label class="form-label">Category *</label>
              <select class="form-control" name="category_id" required>
                <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>" <?= $question['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                  <?= $cat['icon'] ?> <?= h($cat['name']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Question Type</label>
              <select class="form-control" name="question_type">
                <?php foreach (['multiple_choice'=>'Multiple Choice','true_false'=>'True/False','image_guess'=>'Image Guess','audio_guess'=>'Audio Guess','video_scene'=>'Video Scene'] as $val=>$label): ?>
                <option value="<?= $val ?>" <?= $question['question_type'] === $val ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Difficulty</label>
              <select class="form-control" name="difficulty">
                <?php foreach (['easy','medium','hard'] as $d): ?>
                <option value="<?= $d ?>" <?= $question['difficulty'] === $d ? 'selected' : '' ?>><?= ucfirst($d) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Question Text *</label>
            <textarea class="form-control" name="question_text" rows="3" required><?= h($question['question_text']) ?></textarea>
          </div>

          <!-- Current Media Preview -->
          <?php if ($question['image_path'] || $question['audio_path'] || $question['video_path']): ?>
          <div style="margin-bottom:1.5rem;padding:1rem;background:rgba(255,255,255,0.03);border-radius:8px;border:1px solid rgba(255,255,255,0.08)">
            <div style="font-size:0.8rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:0.75rem">Current Media</div>
            <?php if ($question['image_path']): ?>
              <img src="<?= h($question['image_path']) ?>" style="max-height:120px;border-radius:6px;margin-right:1rem">
            <?php endif; ?>
            <?php if ($question['audio_path']): ?>
              <audio controls src="<?= h($question['audio_path']) ?>" style="width:100%;max-width:300px"></audio>
            <?php endif; ?>
            <?php if ($question['video_path']): ?>
              <video controls src="<?= h($question['video_path']) ?>" style="max-height:120px;border-radius:6px"></video>
            <?php endif; ?>
          </div>
          <?php endif; ?>

          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <div class="form-group" style="margin:0">
              <label class="form-label">Replace Image</label>
              <input class="form-control" type="file" name="image" accept="image/*">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Replace Audio</label>
              <input class="form-control" type="file" name="audio" accept="audio/*">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Replace Video</label>
              <input class="form-control" type="file" name="video" accept="video/*">
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <?php for ($i = 1; $i <= 4; $i++): ?>
            <div class="form-group" style="margin:0">
              <label class="form-label">
                Option <?= $i ?> <?= $i <= 2 ? '*' : '' ?>
                <input type="radio" name="correct_option" value="<?= $i ?>"
                       <?= $question['correct_option'] == $i ? 'checked' : '' ?>
                       style="margin-left:0.5rem">
                <span style="color:var(--neon-green);font-size:0.75rem">= Correct?</span>
              </label>
              <input class="form-control" type="text" name="option<?= $i ?>"
                     value="<?= h($question['option'.$i] ?? '') ?>"
                     placeholder="Option <?= $i ?><?= $i > 2 ? ' (optional)' : '' ?>"
                     <?= $i <= 2 ? 'required' : '' ?>>
            </div>
            <?php endfor; ?>
          </div>

          <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <div class="form-group" style="margin:0">
              <label class="form-label">Explanation</label>
              <input class="form-control" type="text" name="explanation" value="<?= h($question['explanation'] ?? '') ?>">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Points</label>
              <input class="form-control" type="number" name="points" min="5" max="100" step="5" value="<?= $question['points'] ?>">
            </div>
          </div>

          <div style="display:flex;gap:1rem">
            <button type="submit" class="btn btn-primary">💾 Save Changes</button>
            <a href="<?=BASE?>/admin/manage_questions.php" class="btn btn-ghost">Cancel</a>
          </div>
        </form>
      </div>
    </main>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
