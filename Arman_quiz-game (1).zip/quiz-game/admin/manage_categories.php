<?php
// admin/manage_categories.php
require_once '../includes/functions.php';
startSecureSession();
requireAdmin();

$db    = getDB();
$error = $success = '';

// Handle add
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'add') {
    $name  = trim($_POST['name'] ?? '');
    $icon  = trim($_POST['icon'] ?? '🎯');
    $color = $_POST['color'] ?? '#6c63ff';
    $color2= $_POST['color2'] ?? '#48cfad';
    $desc  = trim($_POST['description'] ?? '');

    if (!$name) { $error = 'Name is required'; }
    else {
        addCategory($name, $icon, $color, $color2, $desc);
        $success = "Category \"$name\" added!";
    }
}

// Handle toggle active
if (isset($_GET['toggle']) && isset($_GET['id'])) {
    $db->prepare("UPDATE categories SET is_active = 1 - is_active WHERE id = ?")->execute([(int)$_GET['id']]);
    header('Location: '.BASE.'/admin/manage_categories.php');
    exit();
}

// Handle delete
if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM categories WHERE id = ?")->execute([(int)$_GET['delete']]);
    header('Location: '.BASE.'/admin/manage_categories.php?deleted=1');
    exit();
}

$categories = $db->query("SELECT c.*, (SELECT COUNT(*) FROM questions q WHERE q.category_id = c.id AND q.is_active = 1) as q_count FROM categories c ORDER BY c.name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Categories — Admin</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span> <span style="font-size:0.7rem;color:var(--neon-pink);vertical-align:middle"> ADMIN</span></a>
  </nav>

  <div class="admin-layout">
    <aside class="admin-sidebar">
      <ul class="sidebar-nav">
        <li><a href="<?=BASE?>/admin/admin_dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?=BASE?>/admin/manage_questions.php">❓ Questions</a></li>
        <li><a href="<?=BASE?>/admin/add_question.php">➕ Add Question</a></li>
        <li><a href="<?=BASE?>/admin/manage_categories.php" class="active">🗂 Categories</a></li>
        <li><a href="<?=BASE?>/admin/manage_users.php">👥 Users</a></li>
        <li><a href="<?=BASE?>/admin/manage_scores.php">📈 Scores</a></li>
      </ul>
    </aside>

    <main class="admin-main">
      <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;margin-bottom:2rem;color:var(--neon-cyan)">🗂 Categories</h1>

      <?php if (!empty($_GET['deleted'])): ?><div class="form-error" style="margin-bottom:1.5rem">Category deleted.</div><?php endif; ?>
      <?php if ($error):   ?><div class="form-error" style="margin-bottom:1.5rem">⚠ <?= h($error) ?></div><?php endif; ?>
      <?php if ($success): ?><div class="form-success" style="margin-bottom:1.5rem">✓ <?= h($success) ?></div><?php endif; ?>

      <!-- Add Category Form -->
      <div class="card" style="padding:2rem;margin-bottom:2.5rem;max-width:800px">
        <h2 style="font-family:'Orbitron',monospace;font-size:1.1rem;margin-bottom:1.5rem;color:var(--neon-pink)">➕ Add New Category</h2>
        <form method="POST">
          <input type="hidden" name="action" value="add">
          <div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:1rem;margin-bottom:1rem">
            <div class="form-group" style="margin:0">
              <label class="form-label">Name *</label>
              <input class="form-control" type="text" name="name" placeholder="e.g. Football" required>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Icon (emoji)</label>
              <input class="form-control" type="text" name="icon" value="🎯" maxlength="5">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Color 1</label>
              <input class="form-control" type="color" name="color" value="#6c63ff" style="padding:6px">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Color 2</label>
              <input class="form-control" type="color" name="color2" value="#48cfad" style="padding:6px">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Description</label>
            <input class="form-control" type="text" name="description" placeholder="Short category description">
          </div>
          <button type="submit" class="btn btn-primary btn-sm">➕ Add Category</button>
        </form>
      </div>

      <!-- Categories Table -->
      <table class="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Category</th>
            <th>Questions</th>
            <th>Colors</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($categories as $cat): ?>
          <tr>
            <td class="mono" style="color:var(--text-dim)">#<?= $cat['id'] ?></td>
            <td>
              <div style="display:flex;align-items:center;gap:0.75rem">
                <span style="font-size:1.5rem"><?= $cat['icon'] ?></span>
                <div>
                  <div style="font-weight:700"><?= h($cat['name']) ?></div>
                  <div style="font-size:0.8rem;color:var(--text-dim)"><?= h($cat['description'] ?? '') ?></div>
                </div>
              </div>
            </td>
            <td>
              <span style="font-family:'Orbitron',monospace;color:var(--neon-cyan)"><?= $cat['q_count'] ?></span>
            </td>
            <td>
              <div style="display:flex;gap:6px;align-items:center">
                <div style="width:24px;height:24px;border-radius:50%;background:<?= h($cat['color']) ?>;border:2px solid rgba(255,255,255,0.1)"></div>
                <div style="width:24px;height:24px;border-radius:50%;background:<?= h($cat['color2']) ?>;border:2px solid rgba(255,255,255,0.1)"></div>
              </div>
            </td>
            <td>
              <span style="padding:4px 12px;border-radius:12px;font-size:0.8rem;font-weight:700;
                           background:<?= $cat['is_active'] ? 'rgba(0,255,136,0.15)' : 'rgba(255,0,170,0.15)' ?>;
                           color:<?= $cat['is_active'] ? 'var(--neon-green)' : 'var(--neon-pink)' ?>;
                           border:1px solid <?= $cat['is_active'] ? 'var(--neon-green)' : 'var(--neon-pink)' ?>">
                <?= $cat['is_active'] ? 'Active' : 'Hidden' ?>
              </span>
            </td>
            <td>
              <div style="display:flex;gap:0.5rem">
                <a href="?toggle=1&id=<?= $cat['id'] ?>" class="btn btn-ghost btn-sm">
                  <?= $cat['is_active'] ? 'Hide' : 'Show' ?>
                </a>
                <?php if ($cat['q_count'] == 0): ?>
                <a href="?delete=<?= $cat['id'] ?>" class="btn btn-danger btn-sm"
                   onclick="return confirm('Delete category?')">Del</a>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </main>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
