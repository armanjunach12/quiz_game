<?php
// admin/add_question.php
require_once '../includes/functions.php';
startSecureSession();
requireAdmin();

$categories = getCategories(false);
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'category_id'   => (int)$_POST['category_id'],
        'question_text' => trim($_POST['question_text'] ?? ''),
        'question_type' => $_POST['question_type'] ?? 'multiple_choice',
        'difficulty'    => $_POST['difficulty'] ?? 'medium',
        'option1'       => trim($_POST['option1'] ?? ''),
        'option2'       => trim($_POST['option2'] ?? ''),
        'option3'       => trim($_POST['option3'] ?? ''),
        'option4'       => trim($_POST['option4'] ?? ''),
        'correct_option'=> (int)($_POST['correct_option'] ?? 1),
        'explanation'   => trim($_POST['explanation'] ?? ''),
        'points'        => (int)($_POST['points'] ?? 10),
        'image_path'    => null,
        'audio_path'    => null,
        'video_path'    => null,
    ];

    // Handle file uploads
    foreach (['image' => 'images', 'audio' => 'audio', 'video' => 'video'] as $field => $type) {
        if (!empty($_FILES[$field]['name'])) {
            $result = handleFileUpload($_FILES[$field], $type);
            if (isset($result['error'])) {
                $error = 'File upload error: ' . $result['error'];
                break;
            }
            $data[$field . '_path'] = $result['path'];
        }
    }

    if (!$error) {
        if (!$data['category_id'] || !$data['question_text'] || !$data['option1'] || !$data['option2']) {
            $error = 'Category, question, and at least 2 options are required.';
        } else {
            addQuestion($data);
            $success = 'Question added successfully!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Question — Admin</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span> <span style="font-size:0.7rem;color:var(--neon-pink);vertical-align:middle"> ADMIN</span></a>
    <div class="nav-user">
      <a href="<?=BASE?>/admin/admin_dashboard.php" class="btn btn-ghost btn-sm">← Dashboard</a>
    </div>
  </nav>

  <div class="admin-layout">
    <aside class="admin-sidebar">
      <ul class="sidebar-nav">
        <li><a href="<?=BASE?>/admin/admin_dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?=BASE?>/admin/manage_questions.php">❓ Questions</a></li>
        <li><a href="<?=BASE?>/admin/add_question.php" class="active">➕ Add Question</a></li>
        <li><a href="<?=BASE?>/admin/manage_categories.php">🗂 Categories</a></li>
        <li><a href="<?=BASE?>/admin/manage_users.php">👥 Users</a></li>
        <li><a href="<?=BASE?>/admin/manage_scores.php">📈 Scores</a></li>
      </ul>
    </aside>

    <main class="admin-main">
      <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;margin-bottom:2rem;color:var(--neon-cyan)">
        ➕ Add New Question
      </h1>

      <?php if ($error):   ?><div class="form-error">⚠ <?= h($error) ?></div><?php endif; ?>
      <?php if ($success): ?><div class="form-success">✓ <?= h($success) ?></div><?php endif; ?>

      <div class="card" style="padding:2.5rem;max-width:900px">
        <form method="POST" enctype="multipart/form-data">

          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <div class="form-group" style="margin:0">
              <label class="form-label">Category *</label>
              <select class="form-control" name="category_id" required>
                <option value="">Select category</option>
                <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>" <?= ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                  <?= $cat['icon'] ?> <?= h($cat['name']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Question Type *</label>
              <select class="form-control" name="question_type">
                <option value="multiple_choice">Multiple Choice</option>
                <option value="true_false">True / False</option>
                <option value="image_guess">Image Guess</option>
                <option value="audio_guess">Audio Guess</option>
                <option value="video_scene">Video Scene</option>
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Difficulty *</label>
              <select class="form-control" name="difficulty">
                <option value="easy">Easy (10 pts)</option>
                <option value="medium" selected>Medium (15 pts)</option>
                <option value="hard">Hard (20 pts)</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Question Text *</label>
            <textarea class="form-control" name="question_text" rows="3" required
                      placeholder="Enter the question text..."><?= h($_POST['question_text'] ?? '') ?></textarea>
          </div>

          <!-- Media Upload -->
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <div class="form-group" style="margin:0">
              <label class="form-label">Image (optional)</label>
              <input class="form-control" type="file" name="image" accept="image/*">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Audio (optional)</label>
              <input class="form-control" type="file" name="audio" accept="audio/*">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Video (optional)</label>
              <input class="form-control" type="file" name="video" accept="video/*">
            </div>
          </div>

          <!-- Options -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <?php for ($i = 1; $i <= 4; $i++): ?>
            <div class="form-group" style="margin:0">
              <label class="form-label">
                Option <?= $i ?> <?= $i <= 2 ? '*' : '' ?>
                <input type="radio" name="correct_option" value="<?= $i ?>"
                       <?= ($_POST['correct_option'] ?? 1) == $i ? 'checked' : ($i == 1 ? 'checked' : '') ?>
                       style="margin-left:0.5rem">
                <span style="color:var(--neon-green);font-size:0.75rem">= Correct?</span>
              </label>
              <input class="form-control" type="text" name="option<?= $i ?>"
                     placeholder="Option <?= $i ?><?= $i > 2 ? ' (optional)' : '' ?>"
                     value="<?= h($_POST['option'.$i] ?? '') ?>"
                     <?= $i <= 2 ? 'required' : '' ?>>
            </div>
            <?php endfor; ?>
          </div>

          <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <div class="form-group" style="margin:0">
              <label class="form-label">Explanation (shown after answer)</label>
              <input class="form-control" type="text" name="explanation"
                     placeholder="Why is this the correct answer?"
                     value="<?= h($_POST['explanation'] ?? '') ?>">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Points</label>
              <input class="form-control" type="number" name="points" min="5" max="100" step="5"
                     value="<?= h($_POST['points'] ?? 10) ?>">
            </div>
          </div>

          <div style="display:flex;gap:1rem">
            <button type="submit" class="btn btn-primary">➕ Add Question</button>
            <a href="<?=BASE?>/admin/manage_questions.php" class="btn btn-ghost">View All Questions</a>
          </div>

        </form>
      </div>
    </main>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
