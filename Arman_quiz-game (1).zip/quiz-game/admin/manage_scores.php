<?php
// admin/manage_scores.php
require_once '../includes/functions.php';
startSecureSession();
requireAdmin();

$db     = getDB();
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset  = ($page - 1) * $perPage;

$total = $db->query("SELECT COUNT(*) FROM scores")->fetchColumn();
$pages = ceil($total / $perPage);

$stmt = $db->prepare("SELECT s.*, u.username, c.name as cat_name, c.icon 
    FROM scores s 
    JOIN users u ON u.id = s.user_id 
    JOIN categories c ON c.id = s.category_id 
    ORDER BY s.date_played DESC 
    LIMIT ? OFFSET ?");
$stmt->execute([$perPage, $offset]);
$scores = $stmt->fetchAll();

// Summary stats
$avgScore  = $db->query("SELECT ROUND(AVG(score)) FROM scores")->fetchColumn();
$topScore  = $db->query("SELECT MAX(score) FROM scores")->fetchColumn();
$todayGames = $db->query("SELECT COUNT(*) FROM scores WHERE DATE(date_played) = CURDATE()")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Scores — Admin</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span> <span style="font-size:0.7rem;color:var(--neon-pink);vertical-align:middle"> ADMIN</span></a>
  </nav>

  <div class="admin-layout">
    <aside class="admin-sidebar">
      <ul class="sidebar-nav">
        <li><a href="<?=BASE?>/admin/admin_dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?=BASE?>/admin/manage_questions.php">❓ Questions</a></li>
        <li><a href="<?=BASE?>/admin/add_question.php">➕ Add Question</a></li>
        <li><a href="<?=BASE?>/admin/manage_categories.php">🗂 Categories</a></li>
        <li><a href="<?=BASE?>/admin/manage_users.php">👥 Users</a></li>
        <li><a href="<?=BASE?>/admin/manage_scores.php" class="active">📈 Scores</a></li>
      </ul>
    </aside>

    <main class="admin-main">
      <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;margin-bottom:2rem;color:var(--neon-cyan)">
        📈 Score History <span style="font-size:1rem;color:var(--text-dim)">(<?= $total ?> games)</span>
      </h1>

      <!-- Quick Stats -->
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;margin-bottom:2.5rem;max-width:700px">
        <div class="card" style="padding:1.25rem;text-align:center">
          <div style="font-size:1.8rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-gold)"><?= $topScore ?></div>
          <div style="color:var(--text-dim);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">Top Score</div>
        </div>
        <div class="card" style="padding:1.25rem;text-align:center">
          <div style="font-size:1.8rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-cyan)"><?= $avgScore ?></div>
          <div style="color:var(--text-dim);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">Avg Score</div>
        </div>
        <div class="card" style="padding:1.25rem;text-align:center">
          <div style="font-size:1.8rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-green)"><?= $todayGames ?></div>
          <div style="color:var(--text-dim);font-size:0.8rem;text-transform:uppercase;letter-spacing:1px">Games Today</div>
        </div>
      </div>

      <div style="overflow-x:auto">
        <table class="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Player</th>
              <th>Category</th>
              <th>Mode</th>
              <th>Difficulty</th>
              <th>Score</th>
              <th>Accuracy</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($scores as $s): ?>
            <?php $acc = $s['total_questions'] > 0 ? round(($s['correct_answers']/$s['total_questions'])*100) : 0; ?>
            <tr>
              <td class="mono" style="color:var(--text-dim)">#<?= $s['id'] ?></td>
              <td style="font-weight:700"><?= h($s['username']) ?></td>
              <td><?= $s['icon'] ?> <?= h($s['cat_name']) ?></td>
              <td style="font-size:0.85rem;color:var(--neon-purple)"><?= strtoupper(str_replace('_',' ', $s['game_mode'])) ?></td>
              <td style="font-size:0.85rem">
                <?php $dc = ['easy'=>'var(--neon-green)','medium'=>'var(--neon-gold)','hard'=>'var(--neon-pink)']; ?>
                <span style="color:<?= $dc[$s['difficulty']] ?? 'var(--text-dim)' ?>"><?= ucfirst($s['difficulty']) ?></span>
              </td>
              <td class="mono" style="color:var(--neon-gold);font-weight:700"><?= $s['score'] ?></td>
              <td>
                <span style="color:<?= $acc >= 75 ? 'var(--neon-green)' : ($acc >= 50 ? 'var(--neon-gold)' : 'var(--neon-pink)') ?>">
                  <?= $s['correct_answers'] ?>/<?= $s['total_questions'] ?> (<?= $acc ?>%)
                </span>
              </td>
              <td style="color:var(--text-dim);font-size:0.85rem"><?= date('M d, Y H:i', strtotime($s['date_played'])) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <?php if ($pages > 1): ?>
      <div style="display:flex;gap:0.5rem;justify-content:center;margin-top:2rem;flex-wrap:wrap">
        <?php for ($p = 1; $p <= min($pages, 10); $p++): ?>
        <a href="?page=<?= $p ?>"
           class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-ghost' ?>"
           style="min-width:40px"><?= $p ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    </main>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
