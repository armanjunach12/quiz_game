<?php
// admin/admin_dashboard.php
require_once '../includes/functions.php';
startSecureSession();
requireAdmin();

$db = getDB();
$totalUsers     = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalQ         = $db->query("SELECT COUNT(*) FROM questions WHERE is_active=1")->fetchColumn();
$totalScores    = $db->query("SELECT COUNT(*) FROM scores")->fetchColumn();
$totalCats      = $db->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$recentUsers    = $db->query("SELECT username, email, total_score, created_at FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();
$topCategories  = $db->query("SELECT c.name, c.icon, COUNT(s.id) as plays FROM categories c LEFT JOIN scores s ON s.category_id = c.id GROUP BY c.id ORDER BY plays DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span> <span style="font-size:0.7rem;color:var(--neon-pink);vertical-align:middle"> ADMIN</span></a>
    <div class="nav-user">
      <a href="<?=BASE?>/index.php" class="btn btn-ghost btn-sm">← Site</a>
      <a href="<?=BASE?>/logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
  </nav>

  <div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar">
      <ul class="sidebar-nav">
        <li><a href="<?=BASE?>/admin/admin_dashboard.php" class="active">📊 Dashboard</a></li>
        <li><a href="<?=BASE?>/admin/manage_questions.php">❓ Questions</a></li>
        <li><a href="<?=BASE?>/admin/add_question.php">➕ Add Question</a></li>
        <li><a href="<?=BASE?>/admin/manage_categories.php">🗂 Categories</a></li>
        <li><a href="<?=BASE?>/admin/manage_users.php">👥 Users</a></li>
        <li><a href="<?=BASE?>/admin/manage_scores.php">📈 Scores</a></li>
      </ul>
    </aside>

    <!-- Main Content -->
    <main class="admin-main">
      <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;margin-bottom:2rem;color:var(--neon-cyan)">
        Admin Dashboard
      </h1>

      <!-- Stats Cards -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1.5rem;margin-bottom:3rem">
        <div class="card" style="padding:1.5rem;text-align:center">
          <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-cyan)"><?= $totalUsers ?></div>
          <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Users</div>
        </div>
        <div class="card" style="padding:1.5rem;text-align:center">
          <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-pink)"><?= $totalQ ?></div>
          <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Questions</div>
        </div>
        <div class="card" style="padding:1.5rem;text-align:center">
          <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-gold)"><?= $totalScores ?></div>
          <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Games Played</div>
        </div>
        <div class="card" style="padding:1.5rem;text-align:center">
          <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-green)"><?= $totalCats ?></div>
          <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Categories</div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:2rem">

        <!-- Recent Users -->
        <div>
          <h2 style="font-family:'Orbitron',monospace;font-size:1rem;margin-bottom:1.5rem;color:var(--neon-cyan)">
            Recent Users
          </h2>
          <table class="admin-table">
            <thead><tr><th>Username</th><th>Score</th><th>Joined</th></tr></thead>
            <tbody>
              <?php foreach ($recentUsers as $u): ?>
              <tr>
                <td style="font-weight:700"><?= h($u['username']) ?></td>
                <td style="color:var(--neon-gold);font-family:'Orbitron',monospace"><?= $u['total_score'] ?></td>
                <td style="color:var(--text-dim);font-size:0.85rem"><?= date('M d', strtotime($u['created_at'])) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Top Categories -->
        <div>
          <h2 style="font-family:'Orbitron',monospace;font-size:1rem;margin-bottom:1.5rem;color:var(--neon-pink)">
            Popular Categories
          </h2>
          <table class="admin-table">
            <thead><tr><th>Category</th><th>Games</th></tr></thead>
            <tbody>
              <?php foreach ($topCategories as $cat): ?>
              <tr>
                <td><?= $cat['icon'] ?> <strong><?= h($cat['name']) ?></strong></td>
                <td style="color:var(--neon-cyan)"><?= $cat['plays'] ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Quick Actions -->
      <div style="margin-top:2rem;display:flex;gap:1rem;flex-wrap:wrap">
        <a href="<?=BASE?>/admin/add_question.php" class="btn btn-primary">➕ Add Question</a>
        <a href="<?=BASE?>/admin/manage_categories.php" class="btn btn-ghost">🗂 Manage Categories</a>
        <a href="<?=BASE?>/admin/manage_users.php" class="btn btn-ghost">👥 Manage Users</a>
      </div>
    </main>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
