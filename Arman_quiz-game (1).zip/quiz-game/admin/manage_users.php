<?php
// admin/manage_users.php
require_once '../includes/functions.php';
startSecureSession();
requireAdmin();

$db     = getDB();
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset  = ($page - 1) * $perPage;
$search  = trim($_GET['q'] ?? '');

// Toggle admin
if (isset($_GET['toggle_admin']) && isset($_GET['id'])) {
    $userId = (int)$_GET['id'];
    if ($userId !== $_SESSION['user_id']) { // can't demote yourself
        $db->prepare("UPDATE users SET is_admin = 1 - is_admin WHERE id = ?")->execute([$userId]);
    }
    header('Location: '.BASE.'/admin/manage_users.php');
    exit();
}

// Reset score
if (isset($_GET['reset_score']) && isset($_GET['id'])) {
    $db->prepare("UPDATE users SET total_score = 0, quizzes_played = 0, correct_answers = 0, total_answers = 0 WHERE id = ?")->execute([(int)$_GET['id']]);
    header('Location: '.BASE.'/admin/manage_users.php?reset=1');
    exit();
}

$whereSQL = $search ? "WHERE username LIKE ? OR email LIKE ?" : "";
$params   = $search ? ["%$search%", "%$search%"] : [];

$totalUsers = $db->prepare("SELECT COUNT(*) FROM users $whereSQL");
$totalUsers->execute($params);
$total = $totalUsers->fetchColumn();
$pages = ceil($total / $perPage);

$stmt = $db->prepare("SELECT * FROM users $whereSQL ORDER BY total_score DESC LIMIT ? OFFSET ?");
$stmt->execute([...$params, $perPage, $offset]);
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Users — Admin</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span> <span style="font-size:0.7rem;color:var(--neon-pink);vertical-align:middle"> ADMIN</span></a>
  </nav>

  <div class="admin-layout">
    <aside class="admin-sidebar">
      <ul class="sidebar-nav">
        <li><a href="<?=BASE?>/admin/admin_dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?=BASE?>/admin/manage_questions.php">❓ Questions</a></li>
        <li><a href="<?=BASE?>/admin/add_question.php">➕ Add Question</a></li>
        <li><a href="<?=BASE?>/admin/manage_categories.php">🗂 Categories</a></li>
        <li><a href="<?=BASE?>/admin/manage_users.php" class="active">👥 Users</a></li>
        <li><a href="<?=BASE?>/admin/manage_scores.php">📈 Scores</a></li>
      </ul>
    </aside>

    <main class="admin-main">
      <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;margin-bottom:2rem;color:var(--neon-cyan)">
        👥 Users <span style="font-size:1rem;color:var(--text-dim)">(<?= $total ?> total)</span>
      </h1>

      <?php if (!empty($_GET['reset'])): ?><div class="form-success" style="margin-bottom:1.5rem">✓ Score reset.</div><?php endif; ?>

      <form method="GET" style="margin-bottom:2rem;display:flex;gap:1rem">
        <input class="form-control" type="text" name="q" value="<?= h($search) ?>"
               placeholder="Search by username or email..." style="max-width:320px">
        <button type="submit" class="btn btn-ghost btn-sm">🔍 Search</button>
        <?php if ($search): ?><a href="<?=BASE?>/admin/manage_users.php" class="btn btn-sm" style="color:var(--text-dim);border:1px solid rgba(255,255,255,0.1);background:transparent">Clear</a><?php endif; ?>
      </form>

      <div style="overflow-x:auto">
        <table class="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Score</th>
              <th>Quizzes</th>
              <th>Accuracy</th>
              <th>Role</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $user): ?>
            <?php $acc = $user['total_answers'] > 0 ? round(($user['correct_answers']/$user['total_answers'])*100) : 0; ?>
            <tr <?= $user['id'] === (int)$_SESSION['user_id'] ? 'style="background:rgba(0,245,255,0.04)"' : '' ?>>
              <td class="mono" style="color:var(--text-dim)">#<?= $user['id'] ?></td>
              <td>
                <div style="display:flex;align-items:center;gap:0.75rem">
                  <div class="player-avatar" style="width:32px;height:32px;font-size:0.9rem">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                  </div>
                  <strong><?= h($user['username']) ?></strong>
                  <?php if ($user['id'] === (int)$_SESSION['user_id']): ?>
                    <span style="font-size:0.7rem;color:var(--neon-cyan)">YOU</span>
                  <?php endif; ?>
                </div>
              </td>
              <td style="color:var(--text-dim);font-size:0.9rem"><?= h($user['email']) ?></td>
              <td class="mono" style="color:var(--neon-gold);font-weight:700"><?= number_format($user['total_score']) ?></td>
              <td class="mono"><?= $user['quizzes_played'] ?></td>
              <td>
                <span style="color:<?= $acc >= 75 ? 'var(--neon-green)' : ($acc >= 50 ? 'var(--neon-gold)' : 'var(--neon-pink)') ?>">
                  <?= $acc ?>%
                </span>
              </td>
              <td>
                <span style="padding:3px 10px;border-radius:10px;font-size:0.75rem;font-weight:700;
                             background:<?= $user['is_admin'] ? 'rgba(255,0,170,0.15)' : 'rgba(0,245,255,0.1)' ?>;
                             color:<?= $user['is_admin'] ? 'var(--neon-pink)' : 'var(--neon-cyan)' ?>;
                             border:1px solid <?= $user['is_admin'] ? 'var(--neon-pink)' : 'var(--neon-cyan)' ?>">
                  <?= $user['is_admin'] ? 'Admin' : 'User' ?>
                </span>
              </td>
              <td style="color:var(--text-dim);font-size:0.85rem"><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
              <td>
                <div style="display:flex;gap:0.5rem">
                  <?php if ($user['id'] !== (int)$_SESSION['user_id']): ?>
                  <a href="?toggle_admin=1&id=<?= $user['id'] ?>" class="btn btn-ghost btn-sm"
                     onclick="return confirm('Toggle admin status?')">
                    <?= $user['is_admin'] ? '👤' : '🔑' ?>
                  </a>
                  <a href="?reset_score=1&id=<?= $user['id'] ?>" class="btn btn-danger btn-sm"
                     onclick="return confirm('Reset this user\'s score?')">Reset</a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <?php if ($pages > 1): ?>
      <div style="display:flex;gap:0.5rem;justify-content:center;margin-top:2rem;flex-wrap:wrap">
        <?php for ($p = 1; $p <= $pages; $p++): ?>
        <a href="?page=<?= $p ?>&q=<?= urlencode($search) ?>"
           class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-ghost' ?>"
           style="min-width:40px"><?= $p ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>

    </main>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
