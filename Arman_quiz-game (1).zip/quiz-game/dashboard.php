<?php
// dashboard.php — User Profile & Stats
require_once 'includes/functions.php';
startSecureSession();
requireLogin();

$user        = getCurrentUser();
$stats       = getUserStats($_SESSION['user_id']);
$history     = getUserScoreHistory($_SESSION['user_id'], 10);
$achievements = getUserAchievements($_SESSION['user_id']);
$accuracy    = $stats['accuracy'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — QuizVerse</title>
  <link rel="stylesheet" href="<?=BASE?>/assets/css/style.css">
</head>
<body>
  <div class="bg-animated"></div>
  <div class="grid-overlay"></div>
  <canvas id="particles-canvas"></canvas>

  <nav class="navbar">
    <a href="<?=BASE?>/index.php" class="nav-logo">QUIZ<span>VERSE</span></a>
    <ul class="nav-links">
      <li><a href="<?=BASE?>/index.php">Home</a></li>
      <li><a href="<?=BASE?>/leaderboard.php">Leaderboard</a></li>
    </ul>
    <div class="nav-user">
      <span class="score-badge">⭐ <?= number_format($stats['total_score'] ?? 0) ?></span>
      <a href="<?=BASE?>/logout.php" class="btn btn-ghost btn-sm">Logout</a>
    </div>
  </nav>

  <div style="min-height:100vh;padding:100px 2rem 4rem;max-width:1200px;margin:0 auto;position:relative;z-index:1">

    <!-- Profile Header -->
    <div class="card" style="padding:2.5rem;margin-bottom:2rem;display:flex;align-items:center;gap:2rem;flex-wrap:wrap">
      <div class="player-avatar" style="width:80px;height:80px;font-size:2.5rem;font-family:'Orbitron',monospace">
        <?= strtoupper(substr($user['username'], 0, 1)) ?>
      </div>
      <div style="flex:1">
        <h1 style="font-family:'Orbitron',monospace;font-size:1.8rem;color:var(--neon-cyan);margin-bottom:0.25rem">
          <?= h($user['username']) ?>
        </h1>
        <p style="color:var(--text-dim)"><?= h($user['email']) ?></p>
        <p style="color:var(--text-dim);font-size:0.85rem;margin-top:0.25rem">
          Member since <?= date('F Y', strtotime($user['created_at'])) ?>
        </p>
      </div>
      <a href="<?=BASE?>/index.php#categories" class="btn btn-primary">▶ Play Now</a>
    </div>

    <!-- Stats Grid -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1.5rem;margin-bottom:2rem">
      <div class="card" style="padding:1.5rem;text-align:center">
        <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-gold)" data-count="<?= $stats['total_score'] ?? 0 ?>">0</div>
        <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Total Score</div>
      </div>
      <div class="card" style="padding:1.5rem;text-align:center">
        <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-cyan)" data-count="<?= $stats['quizzes_played'] ?? 0 ?>">0</div>
        <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Quizzes Played</div>
      </div>
      <div class="card" style="padding:1.5rem;text-align:center">
        <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-green)" data-count="<?= $accuracy ?>">0</div>
        <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Accuracy %</div>
      </div>
      <div class="card" style="padding:1.5rem;text-align:center">
        <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-pink)" data-count="<?= $stats['best_score'] ?? 0 ?>">0</div>
        <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Best Score</div>
      </div>
      <?php if ($stats['fav_category']): ?>
      <div class="card" style="padding:1.5rem;text-align:center">
        <div style="font-size:2rem;margin-bottom:0.25rem">🎯</div>
        <div style="font-family:'Orbitron',monospace;font-weight:700;font-size:1rem;color:var(--neon-purple)"><?= h($stats['fav_category']) ?></div>
        <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Fav Category</div>
      </div>
      <?php endif; ?>
      <div class="card" style="padding:1.5rem;text-align:center">
        <div style="font-size:2.5rem;font-family:'Orbitron',monospace;font-weight:900;color:var(--neon-gold)" data-count="<?= count($achievements) ?>">0</div>
        <div style="color:var(--text-dim);font-size:0.85rem;text-transform:uppercase;letter-spacing:2px;margin-top:0.25rem">Achievements</div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:2rem;flex-wrap:wrap">

      <!-- Recent Games -->
      <div>
        <h2 style="font-family:'Orbitron',monospace;font-size:1.1rem;margin-bottom:1.5rem;color:var(--neon-cyan)">
          📋 Recent Games
        </h2>
        <div style="display:flex;flex-direction:column;gap:0.75rem">
          <?php if (empty($history)): ?>
            <div class="card" style="padding:2rem;text-align:center;color:var(--text-dim)">
              No games yet — <a href="<?=BASE?>/index.php#categories" style="color:var(--neon-cyan)">Play your first quiz!</a>
            </div>
          <?php else: foreach ($history as $h): ?>
            <div class="card" style="padding:1.25rem;display:flex;align-items:center;gap:1rem">
              <span style="font-size:1.5rem"><?= $h['icon'] ?></span>
              <div style="flex:1;min-width:0">
                <div style="font-weight:700;font-size:0.95rem"><?= htmlspecialchars($h['category_name']) ?></div>
                <div style="color:var(--text-dim);font-size:0.8rem">
                  <?= strtoupper(str_replace('_',' ', $h['game_mode'])) ?>
                  · <?= date('M d', strtotime($h['date_played'])) ?>
                  · <?= $h['correct_answers'] ?>/<?= $h['total_questions'] ?> correct
                </div>
              </div>
              <div style="font-family:'Orbitron',monospace;font-weight:700;color:var(--neon-gold)">
                +<?= $h['score'] ?>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>

      <!-- Achievements -->
      <div>
        <h2 style="font-family:'Orbitron',monospace;font-size:1.1rem;margin-bottom:1.5rem;color:var(--neon-gold)">
          🏅 Achievements (<?= count($achievements) ?>)
        </h2>
        <div style="display:flex;flex-direction:column;gap:0.75rem">
          <?php if (empty($achievements)): ?>
            <div class="card" style="padding:2rem;text-align:center;color:var(--text-dim)">
              Complete quizzes to earn achievements!
            </div>
          <?php else: foreach ($achievements as $ach): ?>
            <div class="achievement-card">
              <span class="achievement-icon"><?= $ach['badge_icon'] ?></span>
              <div>
                <div class="achievement-name"><?= htmlspecialchars($ach['name']) ?></div>
                <div class="achievement-desc"><?= htmlspecialchars($ach['description']) ?></div>
                <div style="font-size:0.75rem;color:var(--text-dim);margin-top:2px">
                  <?= date('M d, Y', strtotime($ach['earned_at'])) ?>
                </div>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>

    </div>
  </div>

  <script>window.QUIZ_BASE="<?=BASE?>";</script>
  <script src="<?=BASE?>/assets/js/main.js"></script>
</body>
</html>
